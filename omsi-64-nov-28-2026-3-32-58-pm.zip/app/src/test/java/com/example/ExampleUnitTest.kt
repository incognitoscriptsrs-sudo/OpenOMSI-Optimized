package com.example

import com.example.data.hardware.ProgressiveControlMath
import com.example.data.parser.OmsiConfigParser
import com.example.domain.model.GpuBackend
import com.example.domain.model.OptimizationConfig
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class ExampleUnitTest {

  @Test
  fun `parseGlobalCfg extracts friendly name description and tile count`() {
    val sample =
      """
      [friendlyname]
      Berlin-Spandau Modern

      [description]
      Classic West Berlin bus routes.
      [end]

      [map]
      0
      0
      tile_0_0.map

      [map]
      1
      0
      tile_1_0.map
      """.trimIndent()

    val parsed = OmsiConfigParser.parseGlobalCfg(sample, "Spandau")
    assertEquals("Berlin-Spandau Modern", parsed.friendlyName)
    assertEquals("Classic West Berlin bus routes.", parsed.description)
    assertEquals(2, parsed.tileCount)
  }

  @Test
  fun `parseBusCfg extracts manufacturer model and cfg flags`() {
    val sample =
      """
      [friendlyname]
      MAN
      Lion's City DD
      0

      [model]
      model\MAN_DL05.cfg

      [sound]
      sound\sound.cfg
      """.trimIndent()

    val parsed = OmsiConfigParser.parseBusCfg(sample, "MAN_DL05.bus")
    assertEquals("MAN Lion's City DD", parsed.friendlyName)
    assertEquals("MAN", parsed.manufacturer)
    assertTrue(parsed.hasModelCfg)
    assertTrue(parsed.hasSoundCfg)
  }

  @Test
  fun `patchOptionsCfg updates existing keys and injects 64-bit heap keys`() {
    val original =
      """
      [perf_max_texmem]
      512
      [perf_num_tiles]
      1
      """.trimIndent()
    val config =
      OptimizationConfig(
        unlock64BitHeap = true,
        memoryPoolMb = 6144,
        textureCapMb = 2048,
        tileLoadRadius = 3,
        workerThreads = 6,
        gpuBackend = GpuBackend.VULKAN_TURNIP,
      )

    val (patched, applied) = OmsiConfigParser.patchOptionsCfg(original, config)
    assertTrue(applied >= 10)
    assertTrue(patched.contains("2048"))
    assertTrue(patched.contains("[omsi64_memory_pool_mb]\n6144"))
    assertTrue(patched.contains("[omsi64_gpu_backend]\nvulkan_turnip"))
  }

  @Test
  fun `progressive acceleration respects deadzone and monotonic curve`() {
    assertEquals(0f, ProgressiveControlMath.applyProgressiveCurve(0.04f, 0.05f, 1.8f), 0.0001f)
    val low = ProgressiveControlMath.applyProgressiveCurve(0.25f, 0.05f, 1.8f)
    val mid = ProgressiveControlMath.applyProgressiveCurve(0.6f, 0.05f, 1.8f)
    val full = ProgressiveControlMath.applyProgressiveCurve(1.0f, 0.05f, 1.8f)
    assertTrue(low in 0.01f..0.25f)
    assertTrue(mid > low)
    assertEquals(1.0f, full, 0.0001f)
  }
}
