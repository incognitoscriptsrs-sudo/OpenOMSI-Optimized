package com.example.data.hardware

import android.app.ActivityManager
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.opengl.EGL14
import android.opengl.EGLConfig
import android.opengl.GLES20
import android.os.BatteryManager
import android.os.Build
import android.os.Debug
import android.os.PowerManager
import com.example.domain.model.DeviceTelemetrySnapshot
import com.example.domain.model.ExternalRuntimeInfo
import java.io.File
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

class DeviceTelemetryProbe(private val context: Context) {

  private data class GlDetails(val renderer: String, val vendor: String, val version: String)

  @Volatile private var cachedGlDetails: GlDetails? = null

  suspend fun captureSnapshot(): DeviceTelemetrySnapshot =
    withContext(Dispatchers.Default) {
      val abis = Build.SUPPORTED_ABIS.toList()
      val isArm64 = abis.any { it.equals("arm64-v8a", ignoreCase = true) }

      val socModel =
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
          Build.SOC_MODEL.takeIf { it.isNotBlank() && it != Build.UNKNOWN } ?: Build.HARDWARE
        } else {
          Build.HARDWARE
        }

      val gl = cachedGlDetails ?: probeEglInfo().also { cachedGlDetails = it }

      val pm = context.packageManager
      val vulkanFeature =
        pm.systemAvailableFeatures.firstOrNull {
          it.name == PackageManager.FEATURE_VULKAN_HARDWARE_VERSION
        }
      val vulkanSupported = vulkanFeature != null
      val vulkanVersionLabel =
        if (vulkanFeature != null && Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
          val v = vulkanFeature.version
          val major = (v ushr 22) and 0x3FF
          val minor = (v ushr 12) and 0x3FF
          val patch = v and 0xFFF
          "Vulkan $major.$minor.$patch"
        } else {
          "GLES Fallback"
        }

      val activityManager = context.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
      val memInfo = ActivityManager.MemoryInfo()
      activityManager.getMemoryInfo(memInfo)

      val totalRamMb = memInfo.totalMem / (1024L * 1024L)
      val availRamMb = memInfo.availMem / (1024L * 1024L)
      val nativeHeapMb = Debug.getNativeHeapAllocatedSize() / (1024L * 1024L)
      val jvmMaxMb = Runtime.getRuntime().maxMemory() / (1024L * 1024L)

      val (thermalCode, thermalLabel) = readThermalStatus()
      val batteryTemp = readBatteryTempCelsius()
      val coreCount = Runtime.getRuntime().availableProcessors()
      val coreFreqs = readCpuFrequenciesMhz(coreCount)

      val externalRuntimes =
        listOf(
            "org.openomsi.android" to "openOMSI Native Runtime",
            "com.winlator" to "Winlator Container Bridge",
            "app.winlator.ludashi" to "Winlator Ludashi Mod",
          )
          .map { (pkg, label) ->
            ExternalRuntimeInfo(
              packageName = pkg,
              label = label,
              installed = isPackageInstalled(pm, pkg),
            )
          }

      DeviceTelemetrySnapshot(
        abiList = abis,
        isArm64 = isArm64,
        socModel = socModel,
        deviceModel = "${Build.MANUFACTURER} ${Build.MODEL}",
        hardwareName = Build.HARDWARE,
        gpuRenderer = gl.renderer,
        gpuVendor = gl.vendor,
        glVersion = gl.version,
        vulkanSupported = vulkanSupported,
        vulkanVersionLabel = vulkanVersionLabel,
        cpuCores = coreCount,
        cpuCoreFreqsMhz = coreFreqs,
        totalRamMb = totalRamMb,
        availableRamMb = availRamMb,
        appNativeHeapMb = nativeHeapMb,
        appJvmMaxMb = jvmMaxMb,
        thermalStatusCode = thermalCode,
        thermalLabel = thermalLabel,
        batteryTempCelsius = batteryTemp,
        externalRuntimes = externalRuntimes,
      )
    }

  private fun readThermalStatus(): Pair<Int, String> {
    if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) return 0 to "Nominal"
    val powerManager = context.getSystemService(Context.POWER_SERVICE) as? PowerManager
    val status = runCatching { powerManager?.currentThermalStatus ?: 0 }.getOrDefault(0)
    val label =
      when (status) {
        PowerManager.THERMAL_STATUS_NONE -> "Nominal"
        PowerManager.THERMAL_STATUS_LIGHT -> "Warm (Light)"
        PowerManager.THERMAL_STATUS_MODERATE -> "Moderate Load"
        PowerManager.THERMAL_STATUS_SEVERE -> "Throttling (Severe)"
        PowerManager.THERMAL_STATUS_CRITICAL,
        PowerManager.THERMAL_STATUS_EMERGENCY,
        PowerManager.THERMAL_STATUS_SHUTDOWN -> "Critical Heat"
        else -> "Nominal"
      }
    return status to label
  }

  private fun readBatteryTempCelsius(): Float {
    val intent =
      runCatching {
          context.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        }
        .getOrNull()
    val tenths = intent?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0) ?: 0
    return if (tenths > 0) tenths / 10f else 0f
  }

  private fun readCpuFrequenciesMhz(cores: Int): List<Int> {
    val out = mutableListOf<Int>()
    for (idx in 0 until cores.coerceAtMost(12)) {
      val khz =
        runCatching {
            File("/sys/devices/system/cpu/cpu$idx/cpufreq/scaling_cur_freq")
              .takeIf { it.canRead() }
              ?.readText()
              ?.trim()
              ?.toIntOrNull()
          }
          .getOrNull()
      if (khz != null && khz > 0) {
        out.add(khz / 1000)
      }
    }
    return out
  }

  private fun isPackageInstalled(pm: PackageManager, packageName: String): Boolean =
    runCatching {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
          pm.getPackageInfo(packageName, PackageManager.PackageInfoFlags.of(0))
        } else {
          @Suppress("DEPRECATION") pm.getPackageInfo(packageName, 0)
        }
        true
      }
      .getOrDefault(false)

  private fun probeEglInfo(): GlDetails {
    return runCatching {
        val display = EGL14.eglGetDisplay(EGL14.EGL_DEFAULT_DISPLAY)
        if (display == EGL14.EGL_NO_DISPLAY) return GlDetails("Adreno / EGL", "Qualcomm", "GLES 3.x")
        val version = IntArray(2)
        if (!EGL14.eglInitialize(display, version, 0, version, 1)) {
          return GlDetails("Hardware GLES", Build.HARDWARE, "GLES 3.x")
        }
        val configAttribs =
          intArrayOf(
            EGL14.EGL_RENDERABLE_TYPE,
            EGL14.EGL_OPENGL_ES2_BIT,
            EGL14.EGL_SURFACE_TYPE,
            EGL14.EGL_PBUFFER_BIT,
            EGL14.EGL_NONE,
          )
        val configs = arrayOfNulls<EGLConfig>(1)
        val numConfigs = IntArray(1)
        EGL14.eglChooseConfig(display, configAttribs, 0, configs, 0, 1, numConfigs, 0)
        val config = configs[0] ?: return GlDetails("Hardware GLES", Build.HARDWARE, "GLES 3.x")
        val ctxAttribs = intArrayOf(EGL14.EGL_CONTEXT_CLIENT_VERSION, 3, EGL14.EGL_NONE)
        val eglCtx = EGL14.eglCreateContext(display, config, EGL14.EGL_NO_CONTEXT, ctxAttribs, 0)
        val surfAttribs = intArrayOf(EGL14.EGL_WIDTH, 1, EGL14.EGL_HEIGHT, 1, EGL14.EGL_NONE)
        val surface = EGL14.eglCreatePbufferSurface(display, config, surfAttribs, 0)
        EGL14.eglMakeCurrent(display, surface, surface, eglCtx)
        val renderer = GLES20.glGetString(GLES20.GL_RENDERER).orEmpty().ifBlank { "Hardware GPU" }
        val vendor = GLES20.glGetString(GLES20.GL_VENDOR).orEmpty().ifBlank { Build.MANUFACTURER }
        val glVer = GLES20.glGetString(GLES20.GL_VERSION).orEmpty().ifBlank { "OpenGL ES 3.0" }
        EGL14.eglMakeCurrent(display, EGL14.EGL_NO_SURFACE, EGL14.EGL_NO_SURFACE, EGL14.EGL_NO_CONTEXT)
        EGL14.eglDestroySurface(display, surface)
        EGL14.eglDestroyContext(display, eglCtx)
        EGL14.eglTerminate(display)
        GlDetails(renderer, vendor, glVer)
      }
      .getOrElse { GlDetails("Hardware GLES", Build.HARDWARE, "OpenGL ES 3.0") }
  }
}
