package com.example.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(
  entities = [OmsiMapEntity::class, OmsiBusEntity::class, OmsiModEntity::class],
  version = 1,
  exportSchema = false,
)
abstract class OmsiDatabase : RoomDatabase() {
  abstract fun omsiDao(): OmsiDao

  companion object {
    @Volatile private var instance: OmsiDatabase? = null

    fun getInstance(context: Context): OmsiDatabase =
      instance
        ?: synchronized(this) {
          instance
            ?: Room.databaseBuilder(
                context.applicationContext,
                OmsiDatabase::class.java,
                "omsi64_cache.db",
              )
              .fallbackToDestructiveMigration(dropAllTables = true)
              .build()
              .also { instance = it }
        }
  }
}
