package com.example.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Transaction
import kotlinx.coroutines.flow.Flow

@Dao
interface OmsiDao {
  @Query("SELECT * FROM omsi_maps ORDER BY friendlyName ASC")
  fun observeMaps(): Flow<List<OmsiMapEntity>>

  @Query("SELECT * FROM omsi_buses ORDER BY isFavorite DESC, friendlyName ASC")
  fun observeBuses(): Flow<List<OmsiBusEntity>>

  @Query("SELECT * FROM omsi_mods ORDER BY category ASC, name ASC")
  fun observeMods(): Flow<List<OmsiModEntity>>

  @Query("DELETE FROM omsi_maps")
  suspend fun clearMaps()

  @Query("DELETE FROM omsi_buses")
  suspend fun clearBuses()

  @Query("DELETE FROM omsi_mods")
  suspend fun clearMods()

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertMaps(maps: List<OmsiMapEntity>)

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertBuses(buses: List<OmsiBusEntity>)

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertMods(mods: List<OmsiModEntity>)

  @Query("UPDATE omsi_buses SET isFavorite = :favorite WHERE id = :busId")
  suspend fun setBusFavorite(busId: String, favorite: Boolean)

  @Query("UPDATE omsi_mods SET enabled = :enabled WHERE id = :modId")
  suspend fun setModEnabled(modId: String, enabled: Boolean)

  @Transaction
  suspend fun replaceLibrary(
    maps: List<OmsiMapEntity>,
    buses: List<OmsiBusEntity>,
    mods: List<OmsiModEntity>,
  ) {
    clearMaps()
    clearBuses()
    clearMods()
    insertMaps(maps)
    insertBuses(buses)
    insertMods(mods)
  }
}
