package com.example.data.parser

import com.example.domain.model.OptimizationConfig

data class ParsedMapMetadata(
  val friendlyName: String,
  val description: String,
  val tileCount: Int,
  val referencedAssets: List<String>,
)

data class ParsedBusMetadata(
  val friendlyName: String,
  val description: String,
  val manufacturer: String,
  val hasModelCfg: Boolean,
  val hasSoundCfg: Boolean,
)

object OmsiConfigParser {

  fun parseGlobalCfg(content: String, fallbackName: String): ParsedMapMetadata {
    val lines = content.lines()
    var friendlyName = ""
    var description = ""
    var tileCount = 0
    val refs = LinkedHashSet<String>()

    var i = 0
    while (i < lines.size) {
      val trimmed = lines[i].trim()
      when {
        trimmed.equals("[friendlyname]", ignoreCase = true) -> {
          friendlyName = nextNonEmptyLine(lines, i + 1) ?: friendlyName
        }
        trimmed.equals("[name]", ignoreCase = true) && friendlyName.isBlank() -> {
          friendlyName = nextNonEmptyLine(lines, i + 1) ?: friendlyName
        }
        trimmed.equals("[description]", ignoreCase = true) -> {
          val descBuilder = StringBuilder()
          var j = i + 1
          while (j < lines.size && !lines[j].trim().startsWith("[")) {
            val l = lines[j].trim()
            if (l.isNotEmpty() && !l.equals("[end]", ignoreCase = true)) {
              if (descBuilder.isNotEmpty()) descBuilder.append(' ')
              descBuilder.append(l)
            }
            if (l.equals("[end]", ignoreCase = true)) break
            j++
          }
          description = descBuilder.toString().take(240)
        }
        trimmed.equals("[map]", ignoreCase = true) -> {
          tileCount++
        }
        trimmed.contains("Sceneryobjects\\", ignoreCase = true) ||
          trimmed.contains("Splines\\", ignoreCase = true) -> {
          refs.add(trimmed.replace('\\', '/'))
        }
      }
      i++
    }

    return ParsedMapMetadata(
      friendlyName = friendlyName.ifBlank { fallbackName },
      description = description.ifBlank { "OMSI 2 route map package ($fallbackName)" },
      tileCount = tileCount,
      referencedAssets = refs.toList(),
    )
  }

  fun parseBusCfg(content: String, fallbackFileName: String): ParsedBusMetadata {
    val lines = content.lines()
    var manufacturer = ""
    var modelName = ""
    var friendlyName = ""
    var description = ""
    var hasModelCfg = false
    var hasSoundCfg = false

    for (i in lines.indices) {
      val trimmed = lines[i].trim()
      when {
        trimmed.equals("[friendlyname]", ignoreCase = true) -> {
          val line1 = lines.getOrNull(i + 1)?.trim().orEmpty()
          val line2 = lines.getOrNull(i + 2)?.trim().orEmpty()
          if (line1.isNotEmpty() && !line1.startsWith("[")) manufacturer = line1
          if (line2.isNotEmpty() && !line2.startsWith("[")) modelName = line2
          friendlyName = listOf(manufacturer, modelName).filter { it.isNotBlank() }.joinToString(" ")
        }
        trimmed.equals("[description]", ignoreCase = true) -> {
          val descLines = mutableListOf<String>()
          var j = i + 1
          while (j < lines.size && !lines[j].trim().startsWith("[")) {
            val l = lines[j].trim()
            if (l.equals("[end]", ignoreCase = true)) break
            if (l.isNotEmpty()) descLines.add(l)
            j++
          }
          description = descLines.joinToString(" ").take(220)
        }
        trimmed.equals("[model]", ignoreCase = true) -> hasModelCfg = true
        trimmed.equals("[sound]", ignoreCase = true) ||
          trimmed.equals("[sound_ai]", ignoreCase = true) -> hasSoundCfg = true
      }
    }

    val cleanFallback = fallbackFileName.removeSuffix(".bus")
    return ParsedBusMetadata(
      friendlyName = friendlyName.ifBlank { cleanFallback },
      description = description.ifBlank { "OMSI 2 bus configuration ($fallbackFileName)" },
      manufacturer = manufacturer.ifBlank { "Transit" },
      hasModelCfg = hasModelCfg,
      hasSoundCfg = hasSoundCfg,
    )
  }

  fun extractMapAssetReferences(mapTileContent: String): List<String> {
    val refs = LinkedHashSet<String>()
    mapTileContent.lineSequence().forEach { line ->
      val t = line.trim()
      if (
        t.startsWith("Sceneryobjects\\", ignoreCase = true) ||
          t.startsWith("Splines\\", ignoreCase = true)
      ) {
        refs.add(t.replace('\\', '/'))
      }
    }
    return refs.toList()
  }

  fun patchOptionsCfg(existingContent: String, config: OptimizationConfig): Pair<String, Int> {
    val lines =
      if (existingContent.isBlank()) mutableListOf()
      else existingContent.replace("\r\n", "\n").lines().toMutableList()

    val updates =
      linkedMapOf(
        "[perf_max_obj_dist]" to (if (config.tileLoadRadius >= 3) "1000" else "650"),
        "[perf_min_obj_size]" to (if (config.tileLoadRadius <= 1) "0.025" else "0.012"),
        "[perf_max_texmem]" to config.textureCapMb.toString(),
        "[perf_num_tiles]" to config.tileLoadRadius.toString(),
        "[perf_ai_cars]" to config.aiTrafficDensity.toString(),
        "[perf_ai_humans]" to config.aiPedestrianDensity.toString(),
        "[perf_target_fps]" to config.targetFps.toString(),
        "[perf_reduce_multithreading]" to "0",
        "[omsi64_unlock_heap]" to (if (config.unlock64BitHeap) "1" else "0"),
        "[omsi64_memory_pool_mb]" to config.memoryPoolMb.toString(),
        "[omsi64_worker_threads]" to config.workerThreads.toString(),
        "[omsi64_gpu_backend]" to config.gpuBackend.configValue,
        "[omsi64_dxvk_async]" to (if (config.dxvkAsyncShaders) "1" else "0"),
        "[omsi64_turnip_low_latency]" to (if (config.turnipLowLatency) "1" else "0"),
        "[omsi64_anisotropic]" to config.anisotropicLevel.toString(),
        "[omsi64_reduce_tile_stutter]" to (if (config.reduceTileStutter) "1" else "0"),
      )

    var appliedCount = 0
    val seenKeys = HashSet<String>()

    var i = 0
    while (i < lines.size) {
      val key = lines[i].trim()
      val matchedEntry = updates.entries.firstOrNull { it.key.equals(key, ignoreCase = true) }
      if (matchedEntry != null) {
        seenKeys.add(matchedEntry.key)
        if (i + 1 < lines.size && !lines[i + 1].trim().startsWith("[")) {
          lines[i + 1] = matchedEntry.value
        } else {
          lines.add(i + 1, matchedEntry.value)
        }
        appliedCount++
      }
      i++
    }

    val missingEntries = updates.entries.filter { it.key !in seenKeys }
    if (missingEntries.isNotEmpty()) {
      if (lines.isNotEmpty() && lines.last().isNotBlank()) {
        lines.add("")
      }
      lines.add("// OMSI 64 ARM64 Hardware Acceleration & Memory Tuning")
      for ((key, value) in missingEntries) {
        lines.add(key)
        lines.add(value)
        appliedCount++
      }
    }

    return lines.joinToString("\n") + "\n" to appliedCount
  }

  private fun nextNonEmptyLine(lines: List<String>, startIndex: Int): String? {
    for (idx in startIndex until lines.size) {
      val trimmed = lines[idx].trim()
      if (trimmed.startsWith("[")) return null
      if (trimmed.isNotEmpty()) return trimmed
    }
    return null
  }
}
