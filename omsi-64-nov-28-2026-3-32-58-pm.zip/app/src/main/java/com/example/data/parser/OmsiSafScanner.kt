package com.example.data.parser

import android.content.ContentResolver
import android.content.Context
import android.net.Uri
import android.provider.DocumentsContract
import com.example.data.local.OmsiBusEntity
import com.example.data.local.OmsiMapEntity
import com.example.data.local.OmsiModEntity
import com.example.domain.model.MobileControlConfig
import com.example.domain.model.OmsiChecklistItem
import com.example.domain.model.OmsiInstallStatus
import com.example.domain.model.OptimizationConfig
import com.example.domain.model.OptionsPatchResult
import java.io.BufferedReader
import java.io.InputStreamReader
import java.nio.charset.Charset
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

data class SafEntry(
  val documentId: String,
  val name: String,
  val isDirectory: Boolean,
  val sizeBytes: Long,
)

data class OmsiScanOutput(
  val status: OmsiInstallStatus,
  val maps: List<OmsiMapEntity>,
  val buses: List<OmsiBusEntity>,
  val mods: List<OmsiModEntity>,
)

class OmsiSafScanner(private val context: Context) {

  private val resolver: ContentResolver = context.contentResolver

  suspend fun scanDirectory(
    treeUri: Uri,
    onProgress: (stage: String, progress: Float) -> Unit,
  ): OmsiScanOutput =
    withContext(Dispatchers.IO) {
      val rootDocId = DocumentsContract.getTreeDocumentId(treeUri)
      val displayFolderName = rootDocId.substringAfterLast(':').substringAfterLast('/').ifBlank {
        "OMSI 2"
      }

      onProgress("Inspecting OMSI 2 root structure…", 0.1f)
      val rootChildren = queryChildren(treeUri, rootDocId)
      val byLowerName = rootChildren.associateBy { it.name.lowercase() }

      val exeEntry = byLowerName["omsi.exe"]
      val mapsDir = byLowerName["maps"]?.takeIf { it.isDirectory }
      val vehiclesDir = byLowerName["vehicles"]?.takeIf { it.isDirectory }
      val sceneryDir = byLowerName["sceneryobjects"]?.takeIf { it.isDirectory }
      val splinesDir = byLowerName["splines"]?.takeIf { it.isDirectory }
      val fontsDir = byLowerName["fonts"]?.takeIf { it.isDirectory }
      val textureDir = byLowerName["texture"]?.takeIf { it.isDirectory }
      val optionsEntry = byLowerName["options.cfg"]?.takeIf { !it.isDirectory }

      val checklist =
        listOf(
          OmsiChecklistItem(
            label = "Omsi.exe Binary",
            expectedRelativePath = "Omsi.exe",
            required = true,
            present = exeEntry != null && !exeEntry.isDirectory && exeEntry.sizeBytes > 0L,
            detail =
              exeEntry?.let { "%.1f MB verified".format(it.sizeBytes / (1024f * 1024f)) }
                ?: "Missing PC executable",
          ),
          OmsiChecklistItem(
            label = "Maps Directory",
            expectedRelativePath = "Maps/",
            required = true,
            present = mapsDir != null,
            detail = if (mapsDir != null) "Directory located" else "Missing Maps folder",
          ),
          OmsiChecklistItem(
            label = "Vehicles Directory",
            expectedRelativePath = "Vehicles/",
            required = true,
            present = vehiclesDir != null,
            detail = if (vehiclesDir != null) "Directory located" else "Missing Vehicles folder",
          ),
          OmsiChecklistItem(
            label = "Sceneryobjects",
            expectedRelativePath = "Sceneryobjects/",
            required = false,
            present = sceneryDir != null,
            detail = if (sceneryDir != null) "Present" else "Optional scenery pack missing",
          ),
          OmsiChecklistItem(
            label = "Splines",
            expectedRelativePath = "Splines/",
            required = false,
            present = splinesDir != null,
            detail = if (splinesDir != null) "Present" else "Optional splines folder missing",
          ),
          OmsiChecklistItem(
            label = "Fonts & Texture",
            expectedRelativePath = "Fonts/ + Texture/",
            required = false,
            present = fontsDir != null && textureDir != null,
            detail =
              if (fontsDir != null && textureDir != null) "Core assets found"
              else "Partial core assets",
          ),
          OmsiChecklistItem(
            label = "options.cfg",
            expectedRelativePath = "options.cfg",
            required = false,
            present = optionsEntry != null,
            detail =
              if (optionsEntry != null) "Ready for 64-bit patching"
              else "Will be created on apply",
          ),
        )

      val missingRequired = checklist.filter { it.required && !it.present }.map { it.label }
      if (missingRequired.isNotEmpty()) {
        return@withContext OmsiScanOutput(
          status =
            OmsiInstallStatus.Invalid(
              treeUriString = treeUri.toString(),
              displayFolderName = displayFolderName,
              missingRequired = missingRequired,
              checklist = checklist,
            ),
          maps = emptyList(),
          buses = emptyList(),
          mods = emptyList(),
        )
      }

      onProgress("Indexing Sceneryobjects & Splines…", 0.25f)
      val sceneryEntries = sceneryDir?.let { queryChildren(treeUri, it.documentId) }.orEmpty()
      val splineEntries = splinesDir?.let { queryChildren(treeUri, it.documentId) }.orEmpty()
      val installedSceneryLower = sceneryEntries.map { it.name.lowercase() }.toHashSet()
      val installedSplinesLower = splineEntries.map { it.name.lowercase() }.toHashSet()

      onProgress("Parsing Maps/*/global.cfg…", 0.45f)
      val scannedMaps =
        mapsDir?.let { dir ->
          val mapFolders = queryChildren(treeUri, dir.documentId).filter { it.isDirectory }
          mapFolders.mapNotNull { folder ->
            val children = queryChildren(treeUri, folder.documentId)
            val globalCfg = children.firstOrNull { it.name.equals("global.cfg", ignoreCase = true) }
            val tileFiles = children.filter { it.name.endsWith(".map", ignoreCase = true) }
            val globalText = globalCfg?.let { readTextSafely(treeUri, it.documentId, 65_536) }.orEmpty()
            val parsed = OmsiConfigParser.parseGlobalCfg(globalText, folder.name)

            val allRefs = LinkedHashSet(parsed.referencedAssets)
            tileFiles.take(6).forEach { tile ->
              val tileText = readTextSafely(treeUri, tile.documentId, 48_000)
              allRefs.addAll(OmsiConfigParser.extractMapAssetReferences(tileText))
            }

            val missingList =
              allRefs.filter { ref ->
                val parts = ref.split('/')
                val topFolder = parts.getOrNull(1)?.lowercase()
                when {
                  ref.startsWith("sceneryobjects/", ignoreCase = true) && topFolder != null ->
                    topFolder !in installedSceneryLower
                  ref.startsWith("splines/", ignoreCase = true) && topFolder != null ->
                    topFolder !in installedSplinesLower
                  else -> false
                }
              }

            if (globalCfg == null && tileFiles.isEmpty()) {
              null
            } else {
              OmsiMapEntity(
                id = folder.name.lowercase(),
                folderName = folder.name,
                friendlyName = parsed.friendlyName,
                description = parsed.description,
                tileCount = maxOf(parsed.tileCount, tileFiles.size),
                referencedSceneryCount = allRefs.size,
                missingDependenciesCount = missingList.size,
                missingDependenciesPreview = missingList.take(5).joinToString(" • "),
                hasGlobalCfg = globalCfg != null,
                lastScannedAt = System.currentTimeMillis(),
              )
            }
          }
        }.orEmpty()

      onProgress("Parsing Vehicles/*/*.bus…", 0.72f)
      val scannedBuses =
        vehiclesDir?.let { dir ->
          val vehicleFolders = queryChildren(treeUri, dir.documentId).filter { it.isDirectory }
          val busesOut = mutableListOf<OmsiBusEntity>()
          for (folder in vehicleFolders) {
            val children = queryChildren(treeUri, folder.documentId)
            val busFiles = children.filter { !it.isDirectory && it.name.endsWith(".bus", ignoreCase = true) }
            if (busFiles.isEmpty()) continue

            val textureSub = children.firstOrNull { it.isDirectory && it.name.equals("Texture", true) }
            val repaints = discoverRepaints(treeUri, textureSub)

            for (busFile in busFiles) {
              val content = readTextSafely(treeUri, busFile.documentId, 48_000)
              val parsed = OmsiConfigParser.parseBusCfg(content, busFile.name)
              busesOut.add(
                OmsiBusEntity(
                  id = "${folder.name}/${busFile.name}".lowercase(),
                  folderName = folder.name,
                  busFileName = busFile.name,
                  friendlyName = parsed.friendlyName,
                  description = parsed.description,
                  manufacturer = parsed.manufacturer,
                  repaintCount = repaints.size,
                  repaintsCsv = repaints.joinToString("|"),
                  hasSoundCfg = parsed.hasSoundCfg,
                  hasModelCfg = parsed.hasModelCfg,
                )
              )
            }
          }
          busesOut
        }.orEmpty()

      onProgress("Cataloging Scenery & Mod Packages…", 0.9f)
      val scannedMods = buildList {
        sceneryEntries.forEach { entry ->
          add(
            OmsiModEntity(
              id = "scenery_${entry.name.lowercase()}",
              name = entry.name,
              category = "SCENERY",
              relativePath = "Sceneryobjects/${entry.name}",
              itemCount = if (entry.isDirectory) 1 else 0,
              sizeBytes = entry.sizeBytes,
              enabled = true,
            )
          )
        }
        splineEntries.forEach { entry ->
          add(
            OmsiModEntity(
              id = "spline_${entry.name.lowercase()}",
              name = entry.name,
              category = "SPLINE",
              relativePath = "Splines/${entry.name}",
              itemCount = if (entry.isDirectory) 1 else 0,
              sizeBytes = entry.sizeBytes,
              enabled = true,
            )
          )
        }
        rootChildren
          .filter {
            !it.isDirectory &&
              (it.name.endsWith(".zip", true) ||
                it.name.endsWith(".7z", true) ||
                it.name.endsWith(".ams", true))
          }
          .forEach { archive ->
            add(
              OmsiModEntity(
                id = "archive_${archive.name.lowercase()}",
                name = archive.name,
                category = "ARCHIVE",
                relativePath = archive.name,
                itemCount = 1,
                sizeBytes = archive.sizeBytes,
                enabled = true,
              )
            )
          }
      }

      onProgress("Verification complete", 1.0f)

      OmsiScanOutput(
        status =
          OmsiInstallStatus.Verified(
            treeUriString = treeUri.toString(),
            displayFolderName = displayFolderName,
            exeSizeMb = (exeEntry?.sizeBytes ?: 0L) / (1024f * 1024f),
            mapCount = scannedMaps.size,
            busCount = scannedBuses.size,
            sceneryCount = sceneryEntries.size,
            splineCount = splineEntries.size,
            hasOptionsCfg = optionsEntry != null,
            checklist = checklist,
            lastScannedAt = System.currentTimeMillis(),
          ),
        maps = scannedMaps,
        buses = scannedBuses,
        mods = scannedMods,
      )
    }

  suspend fun applyOptimizationToOptionsCfg(
    treeUri: Uri,
    config: OptimizationConfig,
  ): OptionsPatchResult =
    withContext(Dispatchers.IO) {
      runCatching {
          val rootDocId = DocumentsContract.getTreeDocumentId(treeUri)
          val rootChildren = queryChildren(treeUri, rootDocId)
          val existing = rootChildren.firstOrNull { !it.isDirectory && it.name.equals("options.cfg", true) }
          val existingBackup =
            rootChildren.firstOrNull { !it.isDirectory && it.name.equals("options.cfg.bak", true) }

          val existingText =
            existing?.let { readTextSafely(treeUri, it.documentId, 512_000) }.orEmpty()

          var backupCreated = false
          if (existing != null && existingBackup == null && existingText.isNotBlank()) {
            val backupUri = createDocumentInTree(treeUri, rootDocId, "text/plain", "options.cfg.bak")
            if (backupUri != null) {
              writeTextToUri(backupUri, existingText)
              backupCreated = true
            }
          }

          val (patchedText, appliedKeysCount) = OmsiConfigParser.patchOptionsCfg(existingText, config)

          val targetUri =
            if (existing != null) {
              DocumentsContract.buildDocumentUriUsingTree(treeUri, existing.documentId)
            } else {
              createDocumentInTree(treeUri, rootDocId, "text/plain", "options.cfg")
                ?: error("Unable to create options.cfg inside selected OMSI 2 directory")
            }

          writeTextToUri(targetUri, patchedText)
          OptionsPatchResult(
            success = true,
            message =
              "Applied $appliedKeysCount 64-bit & Adreno keys to options.cfg" +
                if (backupCreated) " (backup saved as options.cfg.bak)" else "",
            backupCreated = backupCreated,
            appliedKeysCount = appliedKeysCount,
          )
        }
        .getOrElse { err ->
          OptionsPatchResult(
            success = false,
            message = "Failed to patch options.cfg: ${err.localizedMessage ?: "Permission denied"}",
          )
        }
    }

  suspend fun restoreOptionsBackup(treeUri: Uri): OptionsPatchResult =
    withContext(Dispatchers.IO) {
      runCatching {
          val rootDocId = DocumentsContract.getTreeDocumentId(treeUri)
          val rootChildren = queryChildren(treeUri, rootDocId)
          val backup =
            rootChildren.firstOrNull { !it.isDirectory && it.name.equals("options.cfg.bak", true) }
              ?: return@withContext OptionsPatchResult(
                success = false,
                message = "No options.cfg.bak backup found in your OMSI 2 directory.",
              )
          val backupText = readTextSafely(treeUri, backup.documentId, 512_000)
          val current =
            rootChildren.firstOrNull { !it.isDirectory && it.name.equals("options.cfg", true) }
          val targetUri =
            if (current != null) {
              DocumentsContract.buildDocumentUriUsingTree(treeUri, current.documentId)
            } else {
              createDocumentInTree(treeUri, rootDocId, "text/plain", "options.cfg")
                ?: error("Unable to recreate options.cfg")
            }
          writeTextToUri(targetUri, backupText)
          OptionsPatchResult(
            success = true,
            message = "Restored original options.cfg from options.cfg.bak.",
          )
        }
        .getOrElse { err ->
          OptionsPatchResult(
            success = false,
            message = "Restore failed: ${err.localizedMessage ?: "Unknown error"}",
          )
        }
    }

  suspend fun writeLaunchManifest(
    treeUri: Uri,
    mapFolder: String?,
    busPath: String?,
    repaint: String?,
    opt: OptimizationConfig,
    ctrl: MobileControlConfig,
  ) =
    withContext(Dispatchers.IO) {
      runCatching {
        val rootDocId = DocumentsContract.getTreeDocumentId(treeUri)
        val rootChildren = queryChildren(treeUri, rootDocId)
        val existing =
          rootChildren.firstOrNull { !it.isDirectory && it.name.equals("omsi64_launch_manifest.json", true) }
        val targetUri =
          if (existing != null) {
            DocumentsContract.buildDocumentUriUsingTree(treeUri, existing.documentId)
          } else {
            createDocumentInTree(treeUri, rootDocId, "application/json", "omsi64_launch_manifest.json")
          }
        if (targetUri != null) {
          val json =
            """
            {
              "launcher": "OMSI 64",
              "arch": "arm64-v8a",
              "mapFolder": "${mapFolder.orEmpty()}",
              "busFile": "${busPath.orEmpty()}",
              "repaint": "${repaint.orEmpty()}",
              "memoryPoolMb": ${opt.memoryPoolMb},
              "unlock64BitHeap": ${opt.unlock64BitHeap},
              "gpuBackend": "${opt.gpuBackend.configValue}",
              "workerThreads": ${opt.workerThreads},
              "tileLoadRadius": ${opt.tileLoadRadius},
              "steeringMode": "${ctrl.steeringMode.name}",
              "throttleExponent": ${ctrl.throttleExponent}
            }
            """.trimIndent()
          writeTextToUri(targetUri, json)
        }
      }
    }

  private fun discoverRepaints(treeUri: Uri, textureDir: SafEntry?): List<String> {
    if (textureDir == null) return emptyList()
    val children = queryChildren(treeUri, textureDir.documentId)
    val repaintsSub = children.firstOrNull { it.isDirectory && it.name.equals("repaints", true) }
    if (repaintsSub == null) return emptyList()
    val repaintChildren = queryChildren(treeUri, repaintsSub.documentId)
    val ctiNames =
      repaintChildren
        .filter { !it.isDirectory && it.name.endsWith(".cti", true) }
        .map { it.name.removeSuffix(".cti").removeSuffix(".CTI") }
    if (ctiNames.isNotEmpty()) return ctiNames.take(16)
    return repaintChildren.filter { it.isDirectory }.map { it.name }.take(16)
  }

  private fun queryChildren(treeUri: Uri, parentDocumentId: String): List<SafEntry> {
    val childrenUri = DocumentsContract.buildChildDocumentsUriUsingTree(treeUri, parentDocumentId)
    val projection =
      arrayOf(
        DocumentsContract.Document.COLUMN_DOCUMENT_ID,
        DocumentsContract.Document.COLUMN_DISPLAY_NAME,
        DocumentsContract.Document.COLUMN_MIME_TYPE,
        DocumentsContract.Document.COLUMN_SIZE,
      )
    val result = mutableListOf<SafEntry>()
    runCatching {
      resolver.query(childrenUri, projection, null, null, null)?.use { cursor ->
        val idCol = cursor.getColumnIndex(DocumentsContract.Document.COLUMN_DOCUMENT_ID)
        val nameCol = cursor.getColumnIndex(DocumentsContract.Document.COLUMN_DISPLAY_NAME)
        val mimeCol = cursor.getColumnIndex(DocumentsContract.Document.COLUMN_MIME_TYPE)
        val sizeCol = cursor.getColumnIndex(DocumentsContract.Document.COLUMN_SIZE)
        while (cursor.moveToNext()) {
          val docId = if (idCol >= 0) cursor.getString(idCol).orEmpty() else ""
          val name = if (nameCol >= 0) cursor.getString(nameCol).orEmpty() else ""
          val mime = if (mimeCol >= 0) cursor.getString(mimeCol).orEmpty() else ""
          val size = if (sizeCol >= 0 && !cursor.isNull(sizeCol)) cursor.getLong(sizeCol) else 0L
          if (docId.isNotEmpty() && name.isNotEmpty()) {
            result.add(
              SafEntry(
                documentId = docId,
                name = name,
                isDirectory = mime == DocumentsContract.Document.MIME_TYPE_DIR,
                sizeBytes = size,
              )
            )
          }
        }
      }
    }
    return result
  }

  private fun readTextSafely(treeUri: Uri, documentId: String, maxBytes: Int): String {
    val docUri = DocumentsContract.buildDocumentUriUsingTree(treeUri, documentId)
    return runCatching {
        resolver.openInputStream(docUri)?.use { input ->
          val buffer = ByteArray(maxBytes)
          var totalRead = 0
          while (totalRead < maxBytes) {
            val read = input.read(buffer, totalRead, maxBytes - totalRead)
            if (read <= 0) break
            totalRead += read
          }
          val charset =
            if (totalRead >= 2 && buffer[0] == 0xFF.toByte() && buffer[1] == 0xFE.toByte()) {
              Charsets.UTF_16LE
            } else {
              Charset.forName("windows-1252")
            }
          BufferedReader(InputStreamReader(buffer.copyOf(totalRead).inputStream(), charset)).readText()
        } ?: ""
      }
      .getOrDefault("")
  }

  private fun createDocumentInTree(
    treeUri: Uri,
    parentDocId: String,
    mimeType: String,
    displayName: String,
  ): Uri? {
    val parentUri = DocumentsContract.buildDocumentUriUsingTree(treeUri, parentDocId)
    return runCatching {
        DocumentsContract.createDocument(resolver, parentUri, mimeType, displayName)
      }
      .getOrNull()
  }

  private fun writeTextToUri(uri: Uri, content: String) {
    resolver.openOutputStream(uri, "wt")?.use { out ->
      out.write(content.toByteArray(Charsets.UTF_8))
      out.flush()
    } ?: error("Could not open SAF output stream for writing")
  }
}
