package com.example.data.local

import kotlinx.coroutines.flow.Flow

class OmsiRepository(private val dao: OmsiDao) {
  val maps: Flow<List<OmsiMapEntity>> = dao.observeMaps()
  val buses: Flow<List<OmsiBusEntity>> = dao.observeBuses()
  val mods: Flow<List<OmsiModEntity>> = dao.observeMods()

  suspend fun replaceScannedLibrary(
    maps: List<OmsiMapEntity>,
    buses: List<OmsiBusEntity>,
    mods: List<OmsiModEntity>,
  ) {
    dao.replaceLibrary(maps, buses, mods)
  }

  suspend fun clearLibrary() {
    dao.replaceLibrary(emptyList(), emptyList(), emptyList())
  }

  suspend fun toggleBusFavorite(busId: String, currentlyFavorite: Boolean) {
    dao.setBusFavorite(busId, !currentlyFavorite)
  }

  suspend fun setModEnabled(modId: String, enabled: Boolean) {
    dao.setModEnabled(modId, enabled)
  }
}
