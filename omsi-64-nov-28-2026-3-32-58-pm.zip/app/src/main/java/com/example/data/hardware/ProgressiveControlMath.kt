package com.example.data.hardware

import kotlin.math.abs
import kotlin.math.pow
import kotlin.math.sign

object ProgressiveControlMath {

  /**
   * Maps a normalized pedal input [0f..1f] through deadzone and exponential progressive curve.
   * Higher exponents give fine low-speed crawl control before opening full bus torque.
   */
  fun applyProgressiveCurve(rawInput: Float, deadzone: Float, exponent: Float): Float {
    val clamped = rawInput.coerceIn(0f, 1f)
    val dz = deadzone.coerceIn(0f, 0.35f)
    if (clamped <= dz) return 0f
    val normalized = ((clamped - dz) / (1f - dz)).coerceIn(0f, 1f)
    return normalized.pow(exponent.coerceIn(0.6f, 3.0f)).coerceIn(0f, 1f)
  }

  /**
   * Smoothly ramps throttle when holding a touch pedal or releases back to idle.
   */
  fun stepProgressiveHold(
    currentNormalized: Float,
    targetNormalized: Float,
    rampRatePerSec: Float,
    dtSeconds: Float,
  ): Float {
    val target = targetNormalized.coerceIn(0f, 1f)
    val dt = dtSeconds.coerceIn(0f, 0.2f)
    val rate = rampRatePerSec.coerceIn(0.2f, 4.0f)
    return if (target > currentNormalized) {
      (currentNormalized + rate * dt).coerceAtMost(target)
    } else {
      (currentNormalized - (rate * 1.8f) * dt).coerceAtLeast(target)
    }
  }

  /**
   * Maps gyroscope roll/tilt angle in degrees into normalized [-1f..1f] steering input.
   */
  fun mapGyroTiltToSteering(
    tiltDegrees: Float,
    deadzoneDegrees: Float,
    sensitivity: Float,
  ): Float {
    val mag = abs(tiltDegrees)
    if (mag <= deadzoneDegrees) return 0f
    val maxRange = (38f / sensitivity.coerceIn(0.5f, 2.2f)).coerceAtLeast(12f)
    val effective = ((mag - deadzoneDegrees) / maxRange).coerceIn(0f, 1f)
    return (effective * tiltDegrees.sign).coerceIn(-1f, 1f)
  }
}
