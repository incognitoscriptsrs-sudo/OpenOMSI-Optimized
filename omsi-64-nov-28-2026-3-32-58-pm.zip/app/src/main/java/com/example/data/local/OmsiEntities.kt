package com.example.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "omsi_maps")
data class OmsiMapEntity(
  @PrimaryKey val id: String,
  val folderName: String,
  val friendlyName: String,
  val description: String,
  val tileCount: Int,
  val referencedSceneryCount: Int,
  val missingDependenciesCount: Int,
  val missingDependenciesPreview: String,
  val hasGlobalCfg: Boolean,
  val lastScannedAt: Long,
)

@Entity(tableName = "omsi_buses")
data class OmsiBusEntity(
  @PrimaryKey val id: String,
  val folderName: String,
  val busFileName: String,
  val friendlyName: String,
  val description: String,
  val manufacturer: String,
  val repaintCount: Int,
  val repaintsCsv: String,
  val hasSoundCfg: Boolean,
  val hasModelCfg: Boolean,
  val isFavorite: Boolean = false,
)

@Entity(tableName = "omsi_mods")
data class OmsiModEntity(
  @PrimaryKey val id: String,
  val name: String,
  val category: String,
  val relativePath: String,
  val itemCount: Int,
  val sizeBytes: Long,
  val enabled: Boolean = true,
)
