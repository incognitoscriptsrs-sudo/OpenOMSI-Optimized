package com.example.data.local

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.floatPreferencesKey
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.example.domain.model.GpuBackend
import com.example.domain.model.MobileControlConfig
import com.example.domain.model.OptimizationConfig
import com.example.domain.model.SnapdragonProfile
import com.example.domain.model.SteeringMode
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.launcherDataStore: DataStore<Preferences> by
  preferencesDataStore(name = "omsi64_preferences")

class LauncherPreferencesRepository(private val context: Context) {

  private object Keys {
    val OMSI_TREE_URI = stringPreferencesKey("omsi_tree_uri")
    val SELECTED_MAP_ID = stringPreferencesKey("selected_map_id")
    val SELECTED_BUS_ID = stringPreferencesKey("selected_bus_id")
    val SELECTED_REPAINT = stringPreferencesKey("selected_repaint")

    val OPT_PROFILE = stringPreferencesKey("opt_profile")
    val OPT_UNLOCK_64BIT = booleanPreferencesKey("opt_unlock_64bit")
    val OPT_MEMORY_POOL_MB = intPreferencesKey("opt_memory_pool_mb")
    val OPT_TEXTURE_CAP_MB = intPreferencesKey("opt_texture_cap_mb")
    val OPT_TILE_RADIUS = intPreferencesKey("opt_tile_radius")
    val OPT_WORKER_THREADS = intPreferencesKey("opt_worker_threads")
    val OPT_GPU_BACKEND = stringPreferencesKey("opt_gpu_backend")
    val OPT_DXVK_ASYNC = booleanPreferencesKey("opt_dxvk_async")
    val OPT_TURNIP_LOW_LATENCY = booleanPreferencesKey("opt_turnip_low_latency")
    val OPT_ANISO = intPreferencesKey("opt_aniso")
    val OPT_AI_TRAFFIC = intPreferencesKey("opt_ai_traffic")
    val OPT_AI_PEDS = intPreferencesKey("opt_ai_peds")
    val OPT_TARGET_FPS = intPreferencesKey("opt_target_fps")
    val OPT_REDUCE_STUTTER = booleanPreferencesKey("opt_reduce_stutter")

    val CTRL_THROTTLE_EXP = floatPreferencesKey("ctrl_throttle_exp")
    val CTRL_THROTTLE_DEADZONE = floatPreferencesKey("ctrl_throttle_deadzone")
    val CTRL_THROTTLE_RAMP = floatPreferencesKey("ctrl_throttle_ramp")
    val CTRL_BRAKE_EXP = floatPreferencesKey("ctrl_brake_exp")
    val CTRL_BRAKE_DEADZONE = floatPreferencesKey("ctrl_brake_deadzone")
    val CTRL_STEERING_MODE = stringPreferencesKey("ctrl_steering_mode")
    val CTRL_STEERING_SENS = floatPreferencesKey("ctrl_steering_sens")
    val CTRL_GYRO_DEADZONE = floatPreferencesKey("ctrl_gyro_deadzone")
    val CTRL_AUTO_CENTER = booleanPreferencesKey("ctrl_auto_center")
    val CTRL_HAPTICS = booleanPreferencesKey("ctrl_haptics")
  }

  val persistedTreeUri: Flow<String?> =
    context.launcherDataStore.data.map { it[Keys.OMSI_TREE_URI] }

  val selectedMapId: Flow<String?> =
    context.launcherDataStore.data.map { it[Keys.SELECTED_MAP_ID] }

  val selectedBusId: Flow<String?> =
    context.launcherDataStore.data.map { it[Keys.SELECTED_BUS_ID] }

  val selectedRepaint: Flow<String?> =
    context.launcherDataStore.data.map { it[Keys.SELECTED_REPAINT] }

  val optimizationConfig: Flow<OptimizationConfig> =
    context.launcherDataStore.data.map { prefs ->
      val profile =
        prefs[Keys.OPT_PROFILE]?.let { runCatching { SnapdragonProfile.valueOf(it) }.getOrNull() }
          ?: SnapdragonProfile.BALANCED_60FPS
      val backend =
        prefs[Keys.OPT_GPU_BACKEND]?.let { runCatching { GpuBackend.valueOf(it) }.getOrNull() }
          ?: GpuBackend.VULKAN_TURNIP

      OptimizationConfig(
        activeProfile = profile,
        unlock64BitHeap = prefs[Keys.OPT_UNLOCK_64BIT] ?: true,
        memoryPoolMb = prefs[Keys.OPT_MEMORY_POOL_MB] ?: 4096,
        textureCapMb = prefs[Keys.OPT_TEXTURE_CAP_MB] ?: 1536,
        tileLoadRadius = prefs[Keys.OPT_TILE_RADIUS] ?: 2,
        workerThreads = prefs[Keys.OPT_WORKER_THREADS] ?: 6,
        gpuBackend = backend,
        dxvkAsyncShaders = prefs[Keys.OPT_DXVK_ASYNC] ?: true,
        turnipLowLatency = prefs[Keys.OPT_TURNIP_LOW_LATENCY] ?: true,
        anisotropicLevel = prefs[Keys.OPT_ANISO] ?: 4,
        aiTrafficDensity = prefs[Keys.OPT_AI_TRAFFIC] ?: 45,
        aiPedestrianDensity = prefs[Keys.OPT_AI_PEDS] ?: 35,
        targetFps = prefs[Keys.OPT_TARGET_FPS] ?: 60,
        reduceTileStutter = prefs[Keys.OPT_REDUCE_STUTTER] ?: true,
      )
    }

  val mobileControlConfig: Flow<MobileControlConfig> =
    context.launcherDataStore.data.map { prefs ->
      val steeringMode =
        prefs[Keys.CTRL_STEERING_MODE]?.let { runCatching { SteeringMode.valueOf(it) }.getOrNull() }
          ?: SteeringMode.TOUCH_SLIDER

      MobileControlConfig(
        throttleExponent = prefs[Keys.CTRL_THROTTLE_EXP] ?: 1.65f,
        throttleDeadzone = prefs[Keys.CTRL_THROTTLE_DEADZONE] ?: 0.05f,
        throttleHoldRampRate = prefs[Keys.CTRL_THROTTLE_RAMP] ?: 0.85f,
        brakeExponent = prefs[Keys.CTRL_BRAKE_EXP] ?: 1.45f,
        brakeDeadzone = prefs[Keys.CTRL_BRAKE_DEADZONE] ?: 0.04f,
        steeringMode = steeringMode,
        steeringSensitivity = prefs[Keys.CTRL_STEERING_SENS] ?: 1.15f,
        gyroDeadzoneDegrees = prefs[Keys.CTRL_GYRO_DEADZONE] ?: 2.5f,
        autoCenterSteering = prefs[Keys.CTRL_AUTO_CENTER] ?: true,
        progressiveHaptics = prefs[Keys.CTRL_HAPTICS] ?: true,
      )
    }

  suspend fun saveTreeUri(uriString: String?) {
    context.launcherDataStore.edit { prefs ->
      if (uriString == null) prefs.remove(Keys.OMSI_TREE_URI)
      else prefs[Keys.OMSI_TREE_URI] = uriString
    }
  }

  suspend fun saveSelectedMap(mapId: String?) {
    context.launcherDataStore.edit { prefs ->
      if (mapId == null) prefs.remove(Keys.SELECTED_MAP_ID)
      else prefs[Keys.SELECTED_MAP_ID] = mapId
    }
  }

  suspend fun saveSelectedBus(busId: String?, repaint: String?) {
    context.launcherDataStore.edit { prefs ->
      if (busId == null) prefs.remove(Keys.SELECTED_BUS_ID) else prefs[Keys.SELECTED_BUS_ID] = busId
      if (repaint == null) prefs.remove(Keys.SELECTED_REPAINT)
      else prefs[Keys.SELECTED_REPAINT] = repaint
    }
  }

  suspend fun saveOptimizationConfig(config: OptimizationConfig) {
    context.launcherDataStore.edit { prefs ->
      prefs[Keys.OPT_PROFILE] = config.activeProfile.name
      prefs[Keys.OPT_UNLOCK_64BIT] = config.unlock64BitHeap
      prefs[Keys.OPT_MEMORY_POOL_MB] = config.memoryPoolMb
      prefs[Keys.OPT_TEXTURE_CAP_MB] = config.textureCapMb
      prefs[Keys.OPT_TILE_RADIUS] = config.tileLoadRadius
      prefs[Keys.OPT_WORKER_THREADS] = config.workerThreads
      prefs[Keys.OPT_GPU_BACKEND] = config.gpuBackend.name
      prefs[Keys.OPT_DXVK_ASYNC] = config.dxvkAsyncShaders
      prefs[Keys.OPT_TURNIP_LOW_LATENCY] = config.turnipLowLatency
      prefs[Keys.OPT_ANISO] = config.anisotropicLevel
      prefs[Keys.OPT_AI_TRAFFIC] = config.aiTrafficDensity
      prefs[Keys.OPT_AI_PEDS] = config.aiPedestrianDensity
      prefs[Keys.OPT_TARGET_FPS] = config.targetFps
      prefs[Keys.OPT_REDUCE_STUTTER] = config.reduceTileStutter
    }
  }

  suspend fun saveMobileControlConfig(config: MobileControlConfig) {
    context.launcherDataStore.edit { prefs ->
      prefs[Keys.CTRL_THROTTLE_EXP] = config.throttleExponent
      prefs[Keys.CTRL_THROTTLE_DEADZONE] = config.throttleDeadzone
      prefs[Keys.CTRL_THROTTLE_RAMP] = config.throttleHoldRampRate
      prefs[Keys.CTRL_BRAKE_EXP] = config.brakeExponent
      prefs[Keys.CTRL_BRAKE_DEADZONE] = config.brakeDeadzone
      prefs[Keys.CTRL_STEERING_MODE] = config.steeringMode.name
      prefs[Keys.CTRL_STEERING_SENS] = config.steeringSensitivity
      prefs[Keys.CTRL_GYRO_DEADZONE] = config.gyroDeadzoneDegrees
      prefs[Keys.CTRL_AUTO_CENTER] = config.autoCenterSteering
      prefs[Keys.CTRL_HAPTICS] = config.progressiveHaptics
    }
  }
}
