package com.example.ui.viewmodel

import android.app.Application
import android.content.Intent
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.hardware.DeviceTelemetryProbe
import com.example.data.local.LauncherPreferencesRepository
import com.example.data.local.OmsiBusEntity
import com.example.data.local.OmsiDatabase
import com.example.data.local.OmsiMapEntity
import com.example.data.local.OmsiModEntity
import com.example.data.local.OmsiRepository
import com.example.data.parser.OmsiSafScanner
import com.example.domain.model.DeviceTelemetrySnapshot
import com.example.domain.model.LauncherTab
import com.example.domain.model.MobileControlConfig
import com.example.domain.model.OmsiInstallStatus
import com.example.domain.model.OptimizationConfig
import com.example.domain.model.OptionsPatchResult
import com.example.domain.model.SnapdragonProfile
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

class LauncherViewModel(application: Application) : AndroidViewModel(application) {

  private val prefs = LauncherPreferencesRepository(application)
  private val database = OmsiDatabase.getInstance(application)
  private val repository = OmsiRepository(database.omsiDao())
  private val scanner = OmsiSafScanner(application)
  private val telemetryProbe = DeviceTelemetryProbe(application)

  private val _activeTab = MutableStateFlow(LauncherTab.PLAY)
  val activeTab: StateFlow<LauncherTab> = _activeTab.asStateFlow()

  private val _installStatus = MutableStateFlow<OmsiInstallStatus>(OmsiInstallStatus.Unconfigured)
  val installStatus: StateFlow<OmsiInstallStatus> = _installStatus.asStateFlow()

  private val _telemetry = MutableStateFlow(DeviceTelemetrySnapshot())
  val telemetry: StateFlow<DeviceTelemetrySnapshot> = _telemetry.asStateFlow()

  private val _patchResult = MutableStateFlow<OptionsPatchResult?>(null)
  val patchResult: StateFlow<OptionsPatchResult?> = _patchResult.asStateFlow()

  private val _isCockpitActive = MutableStateFlow(false)
  val isCockpitActive: StateFlow<Boolean> = _isCockpitActive.asStateFlow()

  val maps: StateFlow<List<OmsiMapEntity>> =
    repository.maps.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

  val buses: StateFlow<List<OmsiBusEntity>> =
    repository.buses.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

  val mods: StateFlow<List<OmsiModEntity>> =
    repository.mods.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

  val selectedMapId: StateFlow<String?> =
    prefs.selectedMapId.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

  val selectedBusId: StateFlow<String?> =
    prefs.selectedBusId.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

  val selectedRepaint: StateFlow<String?> =
    prefs.selectedRepaint.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

  val optimizationConfig: StateFlow<OptimizationConfig> =
    prefs.optimizationConfig.stateIn(
      viewModelScope,
      SharingStarted.WhileSubscribed(5000),
      OptimizationConfig(),
    )

  val mobileControlConfig: StateFlow<MobileControlConfig> =
    prefs.mobileControlConfig.stateIn(
      viewModelScope,
      SharingStarted.WhileSubscribed(5000),
      MobileControlConfig(),
    )

  init {
    startTelemetryLoop()
    restorePersistedDirectory()
  }

  private fun startTelemetryLoop() {
    viewModelScope.launch {
      while (isActive) {
        _telemetry.value = telemetryProbe.captureSnapshot()
        delay(1500L)
      }
    }
  }

  private fun restorePersistedDirectory() {
    viewModelScope.launch {
      val savedUriStr = prefs.persistedTreeUri.first()
      if (!savedUriStr.isNullOrBlank()) {
        val uri = runCatching { Uri.parse(savedUriStr) }.getOrNull()
        val hasPermission =
          uri != null &&
            getApplication<Application>().contentResolver.persistedUriPermissions.any {
              it.uri == uri && it.isReadPermission
            }
        if (uri != null && hasPermission) {
          performScan(uri)
        } else {
          prefs.saveTreeUri(null)
          _installStatus.value = OmsiInstallStatus.Unconfigured
        }
      }
    }
  }

  fun selectTab(tab: LauncherTab) {
    _activeTab.value = tab
  }

  fun onDirectorySelected(uri: Uri) {
    val resolver = getApplication<Application>().contentResolver
    val flags = Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION
    runCatching { resolver.takePersistableUriPermission(uri, flags) }
    viewModelScope.launch {
      prefs.saveTreeUri(uri.toString())
      performScan(uri)
    }
  }

  fun rescanDirectory() {
    viewModelScope.launch {
      val savedUriStr = prefs.persistedTreeUri.first() ?: return@launch
      performScan(Uri.parse(savedUriStr))
    }
  }

  fun unlinkDirectory() {
    viewModelScope.launch {
      prefs.saveTreeUri(null)
      prefs.saveSelectedMap(null)
      prefs.saveSelectedBus(null, null)
      repository.clearLibrary()
      _installStatus.value = OmsiInstallStatus.Unconfigured
      _patchResult.value = null
    }
  }

  private suspend fun performScan(treeUri: Uri) {
    _installStatus.value = OmsiInstallStatus.Scanning("Starting SAF tree inspection…", 0.05f)
    val output =
      scanner.scanDirectory(treeUri) { stage, progress ->
        _installStatus.value = OmsiInstallStatus.Scanning(stage, progress)
      }
    _installStatus.value = output.status
    repository.replaceScannedLibrary(output.maps, output.buses, output.mods)

    if (output.status is OmsiInstallStatus.Verified) {
      val currentMap = prefs.selectedMapId.first()
      if (currentMap == null || output.maps.none { it.id == currentMap }) {
        prefs.saveSelectedMap(output.maps.firstOrNull()?.id)
      }
      val currentBus = prefs.selectedBusId.first()
      if (currentBus == null || output.buses.none { it.id == currentBus }) {
        val firstBus = output.buses.firstOrNull()
        val firstRepaint = firstBus?.repaintsCsv?.split("|")?.firstOrNull { it.isNotBlank() }
        prefs.saveSelectedBus(firstBus?.id, firstRepaint)
      }
    }
  }

  fun selectMap(mapId: String) {
    viewModelScope.launch { prefs.saveSelectedMap(mapId) }
  }

  fun selectBus(bus: OmsiBusEntity) {
    val defaultRepaint = bus.repaintsCsv.split("|").firstOrNull { it.isNotBlank() }
    viewModelScope.launch { prefs.saveSelectedBus(bus.id, defaultRepaint) }
  }

  fun selectRepaint(repaint: String) {
    val busId = selectedBusId.value ?: return
    viewModelScope.launch { prefs.saveSelectedBus(busId, repaint) }
  }

  fun toggleBusFavorite(bus: OmsiBusEntity) {
    viewModelScope.launch { repository.toggleBusFavorite(bus.id, bus.isFavorite) }
  }

  fun setModEnabled(mod: OmsiModEntity, enabled: Boolean) {
    viewModelScope.launch { repository.setModEnabled(mod.id, enabled) }
  }

  fun applySnapdragonProfile(profile: SnapdragonProfile) {
    viewModelScope.launch {
      val current = optimizationConfig.value
      val cores = _telemetry.value.cpuCores.coerceAtLeast(4)
      val updated =
        current.copy(
          activeProfile = profile,
          memoryPoolMb = profile.memoryPoolMb,
          textureCapMb = profile.textureCapMb,
          tileLoadRadius = profile.tileLoadRadius,
          aiTrafficDensity = profile.aiTraffic,
          aiPedestrianDensity = profile.aiPedestrians,
          gpuBackend = profile.gpuBackend,
          workerThreads = (cores - 2).coerceIn(2, 8),
        )
      prefs.saveOptimizationConfig(updated)
    }
  }

  fun updateOptimizationConfig(transform: (OptimizationConfig) -> OptimizationConfig) {
    viewModelScope.launch {
      val next = transform(optimizationConfig.value).copy(activeProfile = SnapdragonProfile.CUSTOM)
      prefs.saveOptimizationConfig(next)
    }
  }

  fun applyConfigToOmsiFiles() {
    viewModelScope.launch {
      val uriStr = prefs.persistedTreeUri.first()
      if (uriStr.isNullOrBlank()) {
        _patchResult.value =
          OptionsPatchResult(success = false, message = "Link your OMSI 2 folder first.")
        return@launch
      }
      val result = scanner.applyOptimizationToOptionsCfg(Uri.parse(uriStr), optimizationConfig.value)
      _patchResult.value = result
      if (result.success) {
        performScan(Uri.parse(uriStr))
      }
    }
  }

  fun restoreOptionsBackup() {
    viewModelScope.launch {
      val uriStr = prefs.persistedTreeUri.first() ?: return@launch
      _patchResult.value = scanner.restoreOptionsBackup(Uri.parse(uriStr))
    }
  }

  fun dismissPatchStatus() {
    _patchResult.value = null
  }

  fun updateMobileControlConfig(transform: (MobileControlConfig) -> MobileControlConfig) {
    viewModelScope.launch { prefs.saveMobileControlConfig(transform(mobileControlConfig.value)) }
  }

  fun launch64BitSession() {
    val status = _installStatus.value
    if (status !is OmsiInstallStatus.Verified) return
    viewModelScope.launch {
      val mapFolder = maps.value.firstOrNull { it.id == selectedMapId.value }?.folderName
      val bus = buses.value.firstOrNull { it.id == selectedBusId.value }
      val busPath = bus?.let { "${it.folderName}/${it.busFileName}" }
      scanner.writeLaunchManifest(
        treeUri = Uri.parse(status.treeUriString),
        mapFolder = mapFolder,
        busPath = busPath,
        repaint = selectedRepaint.value,
        opt = optimizationConfig.value,
        ctrl = mobileControlConfig.value,
      )
      _isCockpitActive.value = true
    }
  }

  fun exitCockpitSession() {
    _isCockpitActive.value = false
  }

  fun launchExternalRuntime(packageName: String) {
    val status = _installStatus.value
    viewModelScope.launch {
      if (status is OmsiInstallStatus.Verified) {
        val mapFolder = maps.value.firstOrNull { it.id == selectedMapId.value }?.folderName
        val bus = buses.value.firstOrNull { it.id == selectedBusId.value }
        scanner.writeLaunchManifest(
          treeUri = Uri.parse(status.treeUriString),
          mapFolder = mapFolder,
          busPath = bus?.let { "${it.folderName}/${it.busFileName}" },
          repaint = selectedRepaint.value,
          opt = optimizationConfig.value,
          ctrl = mobileControlConfig.value,
        )
      }
      val app = getApplication<Application>()
      val intent = app.packageManager.getLaunchIntentForPackage(packageName)
      if (intent != null) {
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        app.startActivity(intent)
      }
    }
  }
}
