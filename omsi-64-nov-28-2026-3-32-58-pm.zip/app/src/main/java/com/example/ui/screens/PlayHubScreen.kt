package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.DirectionsBus
import androidx.compose.material.icons.filled.ErrorOutline
import androidx.compose.material.icons.filled.FolderOpen
import androidx.compose.material.icons.filled.Memory
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.data.local.OmsiBusEntity
import com.example.data.local.OmsiMapEntity
import com.example.domain.model.DeviceTelemetrySnapshot
import com.example.domain.model.LauncherTab
import com.example.domain.model.OmsiChecklistItem
import com.example.domain.model.OmsiInstallStatus
import com.example.domain.model.OptimizationConfig
import com.example.ui.components.GamingPanel
import com.example.ui.components.StatusPill
import com.example.ui.components.TelemetryStatCell
import com.example.ui.theme.OmsiTheme

@Composable
fun PlayHubScreen(
  installStatus: OmsiInstallStatus,
  selectedMap: OmsiMapEntity?,
  selectedBus: OmsiBusEntity?,
  selectedRepaint: String?,
  optimizationConfig: OptimizationConfig,
  telemetry: DeviceTelemetrySnapshot,
  onPickFolder: () -> Unit,
  onRescan: () -> Unit,
  onUnlinkFolder: () -> Unit,
  onNavigateTab: (LauncherTab) -> Unit,
  onLaunch64Bit: () -> Unit,
  onLaunchExternalRuntime: (String) -> Unit,
) {
  Row(
    modifier = Modifier.fillMaxSize().padding(16.dp),
    horizontalArrangement = Arrangement.spacedBy(16.dp),
  ) {
    // Left Hero & Route Dispatch Pane (60%)
    Column(
      modifier = Modifier.weight(0.58f).fillMaxHeight().verticalScroll(rememberScrollState()),
      verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
      // Hero Banner Card
      Surface(
        modifier = Modifier.fillMaxWidth().height(178.dp),
        shape = RoundedCornerShape(14.dp),
        border = BorderStroke(1.dp, OmsiTheme.extended.border),
      ) {
        Box(modifier = Modifier.fillMaxSize()) {
          Image(
            painter = painterResource(id = R.drawable.img_cockpit_hero),
            contentDescription = stringResource(R.string.cd_cockpit_hero),
            contentScale = ContentScale.Crop,
            modifier = Modifier.fillMaxSize(),
          )
          Box(
            modifier =
              Modifier.fillMaxSize()
                .background(
                  Brush.horizontalGradient(
                    colors =
                      listOf(
                        MaterialTheme.colorScheme.background.copy(alpha = 0.94f),
                        MaterialTheme.colorScheme.background.copy(alpha = 0.72f),
                        MaterialTheme.colorScheme.background.copy(alpha = 0.25f),
                      )
                  )
                )
          )

          Column(
            modifier = Modifier.fillMaxSize().padding(18.dp),
            verticalArrangement = Arrangement.SpaceBetween,
          ) {
            Row(
              horizontalArrangement = Arrangement.spacedBy(8.dp),
              verticalAlignment = Alignment.CenterVertically,
            ) {
              StatusPill(
                text = if (telemetry.isArm64) "ARM64-V8A NATIVE" else "ABI CHECK",
                dotColor = MaterialTheme.colorScheme.primary,
                containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.85f),
                textColor = MaterialTheme.colorScheme.primary,
              )
              StatusPill(
                text = "${optimizationConfig.memoryPoolMb} MB HEAP",
                dotColor = MaterialTheme.colorScheme.secondary,
                containerColor = OmsiTheme.extended.transitAmberContainer.copy(alpha = 0.85f),
                textColor = MaterialTheme.colorScheme.secondary,
              )
            }

            Column {
              Text(
                text =
                  when (installStatus) {
                    is OmsiInstallStatus.Verified ->
                      selectedMap?.friendlyName ?: "Select Map in Library"
                    is OmsiInstallStatus.Scanning -> "Scanning OMSI 2 Directory…"
                    else -> stringResource(R.string.gate_title)
                  },
                style = MaterialTheme.typography.headlineMedium,
                color = MaterialTheme.colorScheme.onBackground,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
              )
              Spacer(modifier = Modifier.height(4.dp))
              Text(
                text =
                  when (installStatus) {
                    is OmsiInstallStatus.Verified ->
                      "${selectedBus?.friendlyName ?: "No Bus Selected"} • ${selectedRepaint ?: "Default Livery"}"
                    is OmsiInstallStatus.Scanning -> installStatus.stage
                    else ->
                      "Link your PC OMSI 2 folder (Omsi.exe, Maps, Vehicles) to unlock 64-bit launch."
                  },
                style = MaterialTheme.typography.bodyMedium,
                color = OmsiTheme.extended.mutedText,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis,
              )
            }
          }
        }
      }

      // Active Selection & Quick Controls Row
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(12.dp),
      ) {
        GamingPanel(modifier = Modifier.weight(1f)) {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically,
          ) {
            Text(
              text = "ACTIVE DISPATCH",
              style = MaterialTheme.typography.labelMedium,
              color = MaterialTheme.colorScheme.primary,
            )
            TextButton(
              onClick = { onNavigateTab(LauncherTab.LIBRARY) },
              modifier = Modifier.minimumInteractiveComponentSize().testTag("change_route_bus_button"),
            ) {
              Text("Change")
            }
          }
          Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            TelemetryStatCell(
              label = "Map",
              value = selectedMap?.friendlyName ?: "Unselected",
              modifier = Modifier.weight(1f),
            )
            TelemetryStatCell(
              label = "Vehicle",
              value = selectedBus?.friendlyName ?: "Unselected",
              modifier = Modifier.weight(1f),
            )
          }
          Spacer(modifier = Modifier.height(8.dp))
          Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            TelemetryStatCell(
              label = "GPU Pipeline",
              value = optimizationConfig.gpuBackend.displayName,
              accentColor = MaterialTheme.colorScheme.primary,
              modifier = Modifier.weight(1f),
            )
            TelemetryStatCell(
              label = "Snapdragon Preset",
              value = optimizationConfig.activeProfile.title,
              accentColor = MaterialTheme.colorScheme.secondary,
              modifier = Modifier.weight(1f),
            )
          }
        }
      }

      // Installed External Native / Container Runtimes (if detected via <queries>)
      val installedExternals = telemetry.externalRuntimes.filter { it.installed }
      if (installedExternals.isNotEmpty()) {
        GamingPanel(modifier = Modifier.fillMaxWidth()) {
          Text(
            text = "DETECTED EXTERNAL RUNTIMES",
            style = MaterialTheme.typography.labelMedium,
            color = MaterialTheme.colorScheme.secondary,
          )
          Spacer(modifier = Modifier.height(8.dp))
          Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            installedExternals.forEach { runtime ->
              OutlinedButton(
                onClick = { onLaunchExternalRuntime(runtime.packageName) },
                modifier =
                  Modifier.minimumInteractiveComponentSize()
                    .testTag("launch_external_${runtime.packageName}"),
              ) {
                Text("Open ${runtime.label}")
              }
            }
          }
        }
      }
    }

    // Right Directory Gate, Checklist & Primary Launch Dock (42%)
    GamingPanel(
      modifier = Modifier.weight(0.42f).fillMaxHeight(),
      highlighted = installStatus is OmsiInstallStatus.Verified,
    ) {
      Column(
        modifier = Modifier.fillMaxSize(),
        verticalArrangement = Arrangement.SpaceBetween,
      ) {
        Column(modifier = Modifier.weight(1f).verticalScroll(rememberScrollState())) {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically,
          ) {
            Text(
              text = "OMSI 2 FILES GATE",
              style = MaterialTheme.typography.labelMedium,
              color = MaterialTheme.colorScheme.primary,
            )
            when (installStatus) {
              is OmsiInstallStatus.Verified ->
                StatusPill(
                  text = "VERIFIED",
                  dotColor = OmsiTheme.extended.verifiedGreen,
                  containerColor = OmsiTheme.extended.verifiedGreenContainer,
                  textColor = OmsiTheme.extended.verifiedGreen,
                )
              is OmsiInstallStatus.Invalid ->
                StatusPill(
                  text = "MISSING FILES",
                  dotColor = OmsiTheme.extended.alertCrimson,
                  containerColor = OmsiTheme.extended.alertCrimsonContainer,
                  textColor = OmsiTheme.extended.alertCrimson,
                )
              is OmsiInstallStatus.Scanning ->
                StatusPill(
                  text = "SCANNING",
                  dotColor = MaterialTheme.colorScheme.secondary,
                  containerColor = OmsiTheme.extended.transitAmberContainer,
                  textColor = MaterialTheme.colorScheme.secondary,
                )
              OmsiInstallStatus.Unconfigured ->
                StatusPill(
                  text = "PATH REQUIRED",
                  dotColor = MaterialTheme.colorScheme.secondary,
                  containerColor = OmsiTheme.extended.transitAmberContainer,
                  textColor = MaterialTheme.colorScheme.secondary,
                )
            }
          }

          Spacer(modifier = Modifier.height(10.dp))

          when (installStatus) {
            is OmsiInstallStatus.Unconfigured -> {
              Text(
                text = stringResource(R.string.gate_description),
                style = MaterialTheme.typography.bodyMedium,
                color = OmsiTheme.extended.mutedText,
              )
              Spacer(modifier = Modifier.height(12.dp))
              Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                TelemetryStatCell(
                  label = "SoC",
                  value = telemetry.socModel,
                  modifier = Modifier.weight(1f),
                )
                TelemetryStatCell(
                  label = "Free RAM",
                  value = "${telemetry.availableRamMb} MB",
                  accentColor = OmsiTheme.extended.verifiedGreen,
                  modifier = Modifier.weight(1f),
                )
              }
            }

            is OmsiInstallStatus.Scanning -> {
              Text(
                text = installStatus.stage,
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurface,
              )
              Spacer(modifier = Modifier.height(10.dp))
              LinearProgressIndicator(
                progress = { installStatus.progress },
                modifier = Modifier.fillMaxWidth().height(6.dp).clip(RoundedCornerShape(3.dp)),
                color = MaterialTheme.colorScheme.primary,
                trackColor = OmsiTheme.extended.elevatedSurface,
              )
            }

            is OmsiInstallStatus.Invalid -> {
              Text(
                text = "Folder '${installStatus.displayFolderName}' is missing required OMSI 2 files:",
                style = MaterialTheme.typography.bodyMedium,
                color = OmsiTheme.extended.alertCrimson,
              )
              Spacer(modifier = Modifier.height(8.dp))
              installStatus.checklist.forEach { item ->
                ChecklistRow(item = item)
              }
            }

            is OmsiInstallStatus.Verified -> {
              Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically,
              ) {
                Column(modifier = Modifier.weight(1f)) {
                  Text(
                    text = "Path: /${installStatus.displayFolderName}",
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.onSurface,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                  )
                  Text(
                    text =
                      "${installStatus.mapCount} Maps • ${installStatus.busCount} Buses • ${installStatus.sceneryCount} Scenery",
                    style = MaterialTheme.typography.bodySmall,
                    color = OmsiTheme.extended.mutedText,
                  )
                }
                IconButton(
                  onClick = onRescan,
                  modifier = Modifier.minimumInteractiveComponentSize().testTag("rescan_folder_button"),
                ) {
                  Icon(
                    imageVector = Icons.Default.Refresh,
                    contentDescription = stringResource(R.string.cd_rescan_files),
                    tint = MaterialTheme.colorScheme.primary,
                  )
                }
              }
              Spacer(modifier = Modifier.height(6.dp))
              installStatus.checklist.take(5).forEach { item ->
                ChecklistRow(item = item)
              }
            }
          }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Bottom Primary Actions
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
          ) {
            OutlinedButton(
              onClick = onPickFolder,
              modifier =
                Modifier.weight(1f).minimumInteractiveComponentSize().testTag("select_omsi_folder_button"),
              border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary),
            ) {
              Icon(
                imageVector = Icons.Default.FolderOpen,
                contentDescription = stringResource(R.string.cd_folder_picker),
                modifier = Modifier.size(18.dp),
              )
              Spacer(modifier = Modifier.width(6.dp))
              Text(
                text =
                  if (installStatus is OmsiInstallStatus.Unconfigured)
                    stringResource(R.string.action_select_folder)
                  else "Change Path",
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
              )
            }
            if (installStatus !is OmsiInstallStatus.Unconfigured) {
              OutlinedButton(
                onClick = onUnlinkFolder,
                modifier = Modifier.minimumInteractiveComponentSize().testTag("unlink_folder_button"),
              ) {
                Text("Clear")
              }
            }
          }

          val canLaunch = installStatus is OmsiInstallStatus.Verified
          Button(
            onClick = onLaunch64Bit,
            enabled = canLaunch,
            modifier =
              Modifier.fillMaxWidth()
                .height(52.dp)
                .minimumInteractiveComponentSize()
                .testTag("launch_64bit_button"),
            shape = RoundedCornerShape(10.dp),
            colors =
              ButtonDefaults.buttonColors(
                containerColor = MaterialTheme.colorScheme.primary,
                contentColor = MaterialTheme.colorScheme.onPrimary,
                disabledContainerColor = OmsiTheme.extended.elevatedSurface,
                disabledContentColor = OmsiTheme.extended.mutedText,
              ),
          ) {
            Icon(
              imageVector =
                if (canLaunch) Icons.Default.PlayArrow else Icons.Default.ErrorOutline,
              contentDescription = null,
              modifier = Modifier.size(20.dp),
            )
            Spacer(modifier = Modifier.width(8.dp))
            Text(
              text =
                if (canLaunch) stringResource(R.string.action_launch_64bit)
                else stringResource(R.string.action_launch_locked),
              style = MaterialTheme.typography.labelLarge.copy(fontWeight = FontWeight.Bold),
            )
          }
        }
      }
    }
  }
}

@Composable
private fun ChecklistRow(item: OmsiChecklistItem) {
  Row(
    modifier = Modifier.fillMaxWidth().padding(vertical = 3.dp),
    horizontalArrangement = Arrangement.SpaceBetween,
    verticalAlignment = Alignment.CenterVertically,
  ) {
    Row(
      verticalAlignment = Alignment.CenterVertically,
      horizontalArrangement = Arrangement.spacedBy(8.dp),
      modifier = Modifier.weight(1f),
    ) {
      Icon(
        imageVector = if (item.present) Icons.Default.CheckCircle else Icons.Default.ErrorOutline,
        contentDescription = null,
        tint =
          when {
            item.present -> OmsiTheme.extended.verifiedGreen
            item.required -> OmsiTheme.extended.alertCrimson
            else -> MaterialTheme.colorScheme.secondary
          },
        modifier = Modifier.size(16.dp),
      )
      Text(
        text = item.label,
        style = MaterialTheme.typography.bodyMedium,
        color = MaterialTheme.colorScheme.onSurface,
        maxLines = 1,
        overflow = TextOverflow.Ellipsis,
      )
    }
    Text(
      text = item.detail,
      style = MaterialTheme.typography.labelSmall,
      color =
        when {
          item.present -> OmsiTheme.extended.mutedText
          item.required -> OmsiTheme.extended.alertCrimson
          else -> MaterialTheme.colorScheme.secondary
        },
      maxLines = 1,
      overflow = TextOverflow.Ellipsis,
    )
  }
}
