package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Memory
import androidx.compose.material.icons.filled.Restore
import androidx.compose.material.icons.filled.Save
import androidx.compose.material3.Button
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.domain.model.DeviceTelemetrySnapshot
import com.example.domain.model.GpuBackend
import com.example.domain.model.OmsiInstallStatus
import com.example.domain.model.OptimizationConfig
import com.example.domain.model.OptionsPatchResult
import com.example.domain.model.SnapdragonProfile
import com.example.ui.components.GamingPanel
import com.example.ui.components.SectionHeader
import com.example.ui.components.StatusPill
import com.example.ui.components.TelemetryStatCell
import com.example.ui.theme.OmsiTheme
import kotlin.math.roundToInt

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun OptimizerScreen(
  config: OptimizationConfig,
  telemetry: DeviceTelemetrySnapshot,
  installStatus: OmsiInstallStatus,
  patchResult: OptionsPatchResult?,
  onSelectProfile: (SnapdragonProfile) -> Unit,
  onUpdateConfig: ((OptimizationConfig) -> OptimizationConfig) -> Unit,
  onApplyToOptionsCfg: () -> Unit,
  onRestoreBackup: () -> Unit,
) {
  Row(
    modifier = Modifier.fillMaxSize().padding(16.dp),
    horizontalArrangement = Arrangement.spacedBy(16.dp),
  ) {
    // Left: 64-Bit Memory & Anti-Lag Threading (50%)
    GamingPanel(modifier = Modifier.weight(1f).fillMaxHeight()) {
      Column(
        modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(12.dp),
      ) {
        SectionHeader(
          title = "64-Bit Memory & Anti-Lag",
          subtitle = "Bypass legacy x32 2 GB limit on ARM64 Snapdragon",
          trailing = {
            StatusPill(
              text = if (config.unlock64BitHeap) "64-BIT UNLOCKED" else "LEGACY 2GB",
              dotColor =
                if (config.unlock64BitHeap) OmsiTheme.extended.verifiedGreen
                else OmsiTheme.extended.alertCrimson,
              containerColor =
                if (config.unlock64BitHeap) OmsiTheme.extended.verifiedGreenContainer
                else OmsiTheme.extended.alertCrimsonContainer,
              textColor =
                if (config.unlock64BitHeap) OmsiTheme.extended.verifiedGreen
                else OmsiTheme.extended.alertCrimson,
            )
          },
        )

        // Snapdragon Profile Selector
        Text(
          text = "SNAPDRAGON PRESETS",
          style = MaterialTheme.typography.labelMedium,
          color = MaterialTheme.colorScheme.primary,
        )
        FlowRow(
          horizontalArrangement = Arrangement.spacedBy(8.dp),
          verticalArrangement = Arrangement.spacedBy(8.dp),
        ) {
          SnapdragonProfile.entries.filter { it != SnapdragonProfile.CUSTOM }.forEach { profile ->
            FilterChip(
              selected = config.activeProfile == profile,
              onClick = { onSelectProfile(profile) },
              label = { Text(profile.title) },
              modifier =
                Modifier.minimumInteractiveComponentSize()
                  .testTag("preset_${profile.name.lowercase()}"),
              colors =
                FilterChipDefaults.filterChipColors(
                  selectedContainerColor = MaterialTheme.colorScheme.primaryContainer,
                  selectedLabelColor = MaterialTheme.colorScheme.primary,
                ),
            )
          }
        }

        // Toggle 64-bit heap
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically,
        ) {
          Column(modifier = Modifier.weight(1f)) {
            Text(
              text = "Unlock 64-Bit Heap (>2048 MB)",
              style = MaterialTheme.typography.titleMedium,
              color = MaterialTheme.colorScheme.onSurface,
            )
            Text(
              text = "Prevents OMSI out-of-memory crashes on dense maps",
              style = MaterialTheme.typography.bodySmall,
              color = OmsiTheme.extended.mutedText,
            )
          }
          Switch(
            checked = config.unlock64BitHeap,
            onCheckedChange = { enabled ->
              onUpdateConfig {
                it.copy(
                  unlock64BitHeap = enabled,
                  memoryPoolMb = if (enabled) maxOf(it.memoryPoolMb, 4096) else 2048,
                )
              }
            },
            modifier = Modifier.testTag("toggle_64bit_heap"),
          )
        }

        // Memory Pool Slider
        val maxSafePool = (telemetry.totalRamMb.coerceIn(4096L, 12288L)).toFloat()
        val exceedsSafe = config.memoryPoolMb > telemetry.availableRamMb && telemetry.availableRamMb > 0
        Column {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
          ) {
            Text("64-Bit Memory Pool", style = MaterialTheme.typography.bodyLarge)
            Text(
              text = "${config.memoryPoolMb} MB" + if (exceedsSafe) " (High)" else "",
              style = MaterialTheme.typography.labelMedium,
              color =
                if (exceedsSafe) MaterialTheme.colorScheme.secondary
                else MaterialTheme.colorScheme.primary,
            )
          }
          Slider(
            value = config.memoryPoolMb.toFloat().coerceIn(2048f, maxSafePool),
            onValueChange = { v ->
              onUpdateConfig { it.copy(memoryPoolMb = ((v / 256f).roundToInt() * 256)) }
            },
            valueRange = 2048f..maxSafePool,
            enabled = config.unlock64BitHeap,
            modifier = Modifier.testTag("slider_memory_pool"),
          )
        }

        // Texture Cap Slider
        Column {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
          ) {
            Text("Texture VRAM Cache Budget", style = MaterialTheme.typography.bodyLarge)
            Text(
              text = "${config.textureCapMb} MB",
              style = MaterialTheme.typography.labelMedium,
              color = MaterialTheme.colorScheme.primary,
            )
          }
          Slider(
            value = config.textureCapMb.toFloat(),
            onValueChange = { v ->
              onUpdateConfig { it.copy(textureCapMb = ((v / 128f).roundToInt() * 128)) }
            },
            valueRange = 512f..3072f,
            modifier = Modifier.testTag("slider_texture_cap"),
          )
        }

        // Tile Load Radius & Async Worker Threads
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
          Column(modifier = Modifier.weight(1f)) {
            Text(
              text = "Tile Preload Radius: ${config.tileLoadRadius}",
              style = MaterialTheme.typography.bodyMedium,
            )
            Slider(
              value = config.tileLoadRadius.toFloat(),
              onValueChange = { v -> onUpdateConfig { it.copy(tileLoadRadius = v.roundToInt()) } },
              valueRange = 1f..4f,
              steps = 2,
              modifier = Modifier.testTag("slider_tile_radius"),
            )
          }
          Column(modifier = Modifier.weight(1f)) {
            Text(
              text = "Async Threads: ${config.workerThreads}",
              style = MaterialTheme.typography.bodyMedium,
            )
            Slider(
              value = config.workerThreads.toFloat(),
              onValueChange = { v -> onUpdateConfig { it.copy(workerThreads = v.roundToInt()) } },
              valueRange = 2f..8f,
              steps = 5,
              modifier = Modifier.testTag("slider_worker_threads"),
            )
          }
        }
      }
    }

    // Right: Snapdragon Adreno Hardware Acceleration & options.cfg Sync (50%)
    GamingPanel(modifier = Modifier.weight(1f).fillMaxHeight()) {
      Column(
        modifier = Modifier.fillMaxSize(),
        verticalArrangement = Arrangement.SpaceBetween,
      ) {
        Column(
          modifier = Modifier.weight(1f).verticalScroll(rememberScrollState()),
          verticalArrangement = Arrangement.spacedBy(10.dp),
        ) {
          SectionHeader(
            title = "Adreno Hardware Acceleration",
            subtitle = "GPU: ${telemetry.gpuRenderer} • ${telemetry.vulkanVersionLabel}",
          )

          Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            TelemetryStatCell(
              label = "SoC",
              value = telemetry.socModel,
              modifier = Modifier.weight(1f),
            )
            TelemetryStatCell(
              label = "Free RAM",
              value = "${telemetry.availableRamMb} / ${telemetry.totalRamMb} MB",
              accentColor = OmsiTheme.extended.verifiedGreen,
              modifier = Modifier.weight(1f),
            )
          }

          Text(
            text = "GRAPHICS PIPELINE",
            style = MaterialTheme.typography.labelMedium,
            color = MaterialTheme.colorScheme.primary,
          )
          Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
            GpuBackend.entries.forEach { backend ->
              val selected = config.gpuBackend == backend
              Surface(
                onClick = { onUpdateConfig { it.copy(gpuBackend = backend) } },
                modifier = Modifier.fillMaxWidth().testTag("gpu_backend_${backend.name.lowercase()}"),
                shape = RoundedCornerShape(8.dp),
                color =
                  if (selected) MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.35f)
                  else OmsiTheme.extended.elevatedSurface,
                border =
                  BorderStroke(
                    1.dp,
                    if (selected) MaterialTheme.colorScheme.primary else OmsiTheme.extended.border,
                  ),
              ) {
                Column(modifier = Modifier.padding(10.dp)) {
                  Text(
                    text = backend.displayName,
                    style = MaterialTheme.typography.titleMedium,
                    color =
                      if (selected) MaterialTheme.colorScheme.primary
                      else MaterialTheme.colorScheme.onSurface,
                  )
                  Text(
                    text = backend.note,
                    style = MaterialTheme.typography.bodySmall,
                    color = OmsiTheme.extended.mutedText,
                  )
                }
              }
            }
          }

          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically,
          ) {
            Text("DXVK Async Shader Pre-Compile", style = MaterialTheme.typography.bodyLarge)
            Switch(
              checked = config.dxvkAsyncShaders,
              onCheckedChange = { v -> onUpdateConfig { it.copy(dxvkAsyncShaders = v) } },
              modifier = Modifier.testTag("toggle_dxvk_async"),
            )
          }

          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically,
          ) {
            Text("Turnip Low-Latency Command Queue", style = MaterialTheme.typography.bodyLarge)
            Switch(
              checked = config.turnipLowLatency,
              onCheckedChange = { v -> onUpdateConfig { it.copy(turnipLowLatency = v) } },
              modifier = Modifier.testTag("toggle_turnip_low_latency"),
            )
          }

          Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            Column(modifier = Modifier.weight(1f)) {
              Text(
                text = "AI Traffic: ${config.aiTrafficDensity}%",
                style = MaterialTheme.typography.bodyMedium,
              )
              Slider(
                value = config.aiTrafficDensity.toFloat(),
                onValueChange = { v -> onUpdateConfig { it.copy(aiTrafficDensity = v.roundToInt()) } },
                valueRange = 0f..100f,
                modifier = Modifier.testTag("slider_ai_traffic"),
              )
            }
            Column(modifier = Modifier.weight(1f)) {
              Text(
                text = "Pedestrians: ${config.aiPedestrianDensity}%",
                style = MaterialTheme.typography.bodyMedium,
              )
              Slider(
                value = config.aiPedestrianDensity.toFloat(),
                onValueChange = { v ->
                  onUpdateConfig { it.copy(aiPedestrianDensity = v.roundToInt()) }
                },
                valueRange = 0f..100f,
                modifier = Modifier.testTag("slider_ai_peds"),
              )
            }
          }

          if (patchResult != null) {
            Surface(
              shape = RoundedCornerShape(8.dp),
              color =
                if (patchResult.success) OmsiTheme.extended.verifiedGreenContainer
                else OmsiTheme.extended.alertCrimsonContainer,
              border =
                BorderStroke(
                  1.dp,
                  if (patchResult.success) OmsiTheme.extended.verifiedGreen
                  else OmsiTheme.extended.alertCrimson,
                ),
            ) {
              Text(
                text = patchResult.message,
                style = MaterialTheme.typography.labelMedium,
                color = MaterialTheme.colorScheme.onSurface,
                modifier = Modifier.fillMaxWidth().padding(10.dp),
              )
            }
          }
        }

        Spacer(modifier = Modifier.height(10.dp))

        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.spacedBy(10.dp),
        ) {
          OutlinedButton(
            onClick = onRestoreBackup,
            enabled = installStatus is OmsiInstallStatus.Verified,
            modifier =
              Modifier.minimumInteractiveComponentSize().testTag("restore_options_backup_button"),
          ) {
            Icon(Icons.Default.Restore, contentDescription = null)
            Spacer(modifier = Modifier.width(6.dp))
            Text(stringResource(R.string.action_restore_backup))
          }
          Button(
            onClick = onApplyToOptionsCfg,
            enabled = installStatus is OmsiInstallStatus.Verified,
            modifier =
              Modifier.weight(1f)
                .minimumInteractiveComponentSize()
                .testTag("apply_options_cfg_button"),
          ) {
            Icon(Icons.Default.Save, contentDescription = null)
            Spacer(modifier = Modifier.width(6.dp))
            Text(stringResource(R.string.action_apply_options))
          }
        }
      }
    }
  }
}
