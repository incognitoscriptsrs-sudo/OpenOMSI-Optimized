package com.example.ui.cockpit

import android.content.Context
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.opengl.GLSurfaceView
import android.os.Debug
import android.view.HapticFeedbackConstants
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.AirlineSeatReclineNormal
import androidx.compose.material.icons.filled.DoorFront
import androidx.compose.material.icons.filled.Highlight
import androidx.compose.material.icons.filled.Sync
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import com.example.R
import com.example.data.hardware.ProgressiveControlMath
import com.example.data.local.OmsiBusEntity
import com.example.data.local.OmsiMapEntity
import com.example.domain.model.DeviceTelemetrySnapshot
import com.example.domain.model.MobileControlConfig
import com.example.domain.model.OptimizationConfig
import com.example.domain.model.SteeringMode
import com.example.ui.components.StatusPill
import com.example.ui.theme.OmsiTheme
import kotlin.math.atan2
import kotlin.math.roundToInt
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive

@Composable
fun OmsiGlCockpitScreen(
  selectedMap: OmsiMapEntity?,
  selectedBus: OmsiBusEntity?,
  selectedRepaint: String?,
  optimizationConfig: OptimizationConfig,
  controlConfig: MobileControlConfig,
  telemetry: DeviceTelemetrySnapshot,
  onExit: () -> Unit,
) {
  BackHandler(onBack = onExit)

  val context = LocalContext.current
  val view = LocalView.current

  var measuredFps by remember { mutableIntStateOf(60) }
  var measuredFrameMs by remember { mutableFloatStateOf(16.6f) }

  var rawThrottlePressed by remember { mutableStateOf(false) }
  var rawThrottleTouchLevel by remember { mutableFloatStateOf(0f) }
  var progressiveThrottle by remember { mutableFloatStateOf(0f) }

  var rawBrakePressed by remember { mutableStateOf(false) }
  var rawBrakeTouchLevel by remember { mutableFloatStateOf(0f) }
  var progressiveBrake by remember { mutableFloatStateOf(0f) }

  var steeringNormalized by remember { mutableFloatStateOf(0f) }
  var speedKmh by remember { mutableFloatStateOf(0f) }
  var rpm by remember { mutableIntStateOf(650) }

  var headlightsOn by remember { mutableStateOf(true) }
  var door1Open by remember { mutableStateOf(false) }
  var door2Open by remember { mutableStateOf(false) }
  var kneelingActive by remember { mutableStateOf(false) }
  var retarderActive by remember { mutableStateOf(true) }
  var leftBlinker by remember { mutableStateOf(false) }
  var rightBlinker by remember { mutableStateOf(false) }
  var nativeHeapMb by remember { mutableIntStateOf(telemetry.appNativeHeapMb.toInt()) }

  val renderer = remember {
    OmsiGlRenderer { fps, frameMs ->
      measuredFps = fps
      measuredFrameMs = frameMs
    }
  }

  // Real gyroscope / gravity tilt sensor when GYROSCOPE_TILT steering is selected
  DisposableEffect(controlConfig.steeringMode, controlConfig.gyroDeadzoneDegrees, controlConfig.steeringSensitivity) {
    if (controlConfig.steeringMode != SteeringMode.GYROSCOPE_TILT) {
      onDispose {}
    } else {
      val sensorManager = context.getSystemService(Context.SENSOR_SERVICE) as SensorManager
      val accel = sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)
      val listener =
        object : SensorEventListener {
          override fun onSensorChanged(event: SensorEvent) {
            val y = event.values[1]
            val z = event.values[2]
            val tiltDeg = Math.toDegrees(atan2(y.toDouble(), z.toDouble().coerceAtLeast(0.5))).toFloat()
            steeringNormalized =
              ProgressiveControlMath.mapGyroTiltToSteering(
                tiltDegrees = tiltDeg,
                deadzoneDegrees = controlConfig.gyroDeadzoneDegrees,
                sensitivity = controlConfig.steeringSensitivity,
              )
          }

          override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {}
        }
      if (accel != null) {
        sensorManager.registerListener(listener, accel, SensorManager.SENSOR_DELAY_GAME)
      }
      onDispose { sensorManager.unregisterListener(listener) }
    }
  }

  // 60Hz progressive acceleration & bus kinematics loop
  LaunchedEffect(controlConfig, door1Open, door2Open, kneelingActive, retarderActive) {
    var tickCount = 0
    while (isActive) {
      val dt = 0.016f
      val targetThrottle =
        if (rawThrottlePressed) {
          ProgressiveControlMath.applyProgressiveCurve(
            rawInput = rawThrottleTouchLevel,
            deadzone = controlConfig.throttleDeadzone,
            exponent = controlConfig.throttleExponent,
          )
        } else 0f

      progressiveThrottle =
        ProgressiveControlMath.stepProgressiveHold(
          currentNormalized = progressiveThrottle,
          targetNormalized = targetThrottle,
          rampRatePerSec = controlConfig.throttleHoldRampRate,
          dtSeconds = dt,
        )

      val targetBrake =
        if (rawBrakePressed) {
          ProgressiveControlMath.applyProgressiveCurve(
            rawInput = rawBrakeTouchLevel,
            deadzone = controlConfig.brakeDeadzone,
            exponent = controlConfig.brakeExponent,
          )
        } else 0f

      progressiveBrake =
        ProgressiveControlMath.stepProgressiveHold(
          currentNormalized = progressiveBrake,
          targetNormalized = targetBrake,
          rampRatePerSec = 2.6f,
          dtSeconds = dt,
        )

      val doorInterlock = door1Open || door2Open || kneelingActive
      val driveForce = if (doorInterlock) 0f else progressiveThrottle * 24f
      val retarderDrag = if (retarderActive && progressiveThrottle < 0.05f && speedKmh > 6f) 4.2f else 0f
      val brakeDrag = progressiveBrake * 38f
      val aeroDrag = 0.012f * speedKmh + 0.55f

      speedKmh = (speedKmh + (driveForce - brakeDrag - retarderDrag - aeroDrag) * dt).coerceIn(0f, 85f)
      rpm = (650 + (progressiveThrottle * 1450f) + (speedKmh * 11f)).roundToInt().coerceIn(650, 2400)

      renderer.speedKmh = speedKmh
      renderer.steeringNormalized = steeringNormalized
      renderer.headlightsOn = headlightsOn
      renderer.brakeApplied = progressiveBrake > 0.05f || doorInterlock

      tickCount++
      if (tickCount % 30 == 0) {
        nativeHeapMb = (Debug.getNativeHeapAllocatedSize() / (1024L * 1024L)).toInt()
      }
      delay(16L)
    }
  }

  Box(modifier = Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background)) {
    // Hardware-accelerated OpenGL ES 3.0 3D Corridor Surface
    AndroidView(
      factory = { ctx ->
        GLSurfaceView(ctx).apply {
          setEGLContextClientVersion(3)
          preserveEGLContextOnPause = true
          setRenderer(renderer)
          renderMode = GLSurfaceView.RENDERMODE_CONTINUOUSLY
        }
      },
      modifier = Modifier.fillMaxSize().testTag("cockpit_gl_surface"),
    )

    // Subtle cockpit vignette overlay for HUD contrast
    Box(
      modifier =
        Modifier.fillMaxSize()
          .background(
            Brush.verticalGradient(
              colors =
                listOf(
                  MaterialTheme.colorScheme.background.copy(alpha = 0.72f),
                  Color.Transparent,
                  MaterialTheme.colorScheme.background.copy(alpha = 0.78f),
                )
            )
          )
    )

    Column(
      modifier =
        Modifier.fillMaxSize()
          .windowInsetsPadding(WindowInsets.safeDrawing)
          .padding(horizontal = 16.dp, vertical = 12.dp),
      verticalArrangement = Arrangement.SpaceBetween,
    ) {
      // Top Instrument HUD Bar
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically,
      ) {
        Row(
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.spacedBy(10.dp),
        ) {
          Surface(
            shape = RoundedCornerShape(10.dp),
            color = MaterialTheme.colorScheme.surface.copy(alpha = 0.9f),
            border = BorderStroke(1.dp, OmsiTheme.extended.border),
          ) {
            IconButton(
              onClick = onExit,
              modifier = Modifier.minimumInteractiveComponentSize().testTag("exit_cockpit_button"),
            ) {
              Icon(
                imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                contentDescription = stringResource(R.string.cd_close_cockpit),
                tint = MaterialTheme.colorScheme.onSurface,
              )
            }
          }

          Column {
            Text(
              text = "${selectedMap?.friendlyName ?: "Route"} • ${selectedBus?.friendlyName ?: "Bus"}",
              style = MaterialTheme.typography.titleMedium,
              color = MaterialTheme.colorScheme.onBackground,
            )
            Text(
              text =
                "ARM64 GLES3 • ${optimizationConfig.memoryPoolMb} MB Pool • ${selectedRepaint ?: "Default Livery"}",
              style = MaterialTheme.typography.labelSmall,
              color = MaterialTheme.colorScheme.primary,
            )
          }
        }

        Row(
          horizontalArrangement = Arrangement.spacedBy(8.dp),
          verticalAlignment = Alignment.CenterVertically,
        ) {
          StatusPill(
            text = "$measuredFps FPS • ${"%.1f".format(measuredFrameMs)} ms",
            dotColor = OmsiTheme.extended.verifiedGreen,
            containerColor = OmsiTheme.extended.verifiedGreenContainer.copy(alpha = 0.85f),
            textColor = OmsiTheme.extended.verifiedGreen,
          )
          StatusPill(
            text = "HEAP $nativeHeapMb MB • ${telemetry.thermalLabel}",
            dotColor = MaterialTheme.colorScheme.secondary,
            containerColor = MaterialTheme.colorScheme.surface.copy(alpha = 0.9f),
            textColor = MaterialTheme.colorScheme.onSurface,
          )
        }
      }

      // Center Speedometer & Door Interlock Readout
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.Center,
        verticalAlignment = Alignment.CenterVertically,
      ) {
        Surface(
          shape = RoundedCornerShape(14.dp),
          color = MaterialTheme.colorScheme.surface.copy(alpha = 0.82f),
          border = BorderStroke(1.dp, OmsiTheme.extended.border),
        ) {
          Row(
            modifier = Modifier.padding(horizontal = 20.dp, vertical = 10.dp),
            horizontalArrangement = Arrangement.spacedBy(24.dp),
            verticalAlignment = Alignment.CenterVertically,
          ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
              Text(
                text = "${speedKmh.roundToInt()}",
                style = MaterialTheme.typography.displaySmall,
                color = MaterialTheme.colorScheme.primary,
              )
              Text(
                text = "KM/H",
                style = MaterialTheme.typography.labelSmall,
                color = OmsiTheme.extended.mutedText,
              )
            }
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
              Text(
                text = "$rpm",
                style = MaterialTheme.typography.titleLarge,
                color = MaterialTheme.colorScheme.secondary,
              )
              Text(
                text = "RPM",
                style = MaterialTheme.typography.labelSmall,
                color = OmsiTheme.extended.mutedText,
              )
            }
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
              val statusMsg =
                when {
                  door1Open || door2Open -> "DOOR STOP"
                  kneelingActive -> "KNEELING"
                  progressiveBrake > 0.1f -> "BRAKING"
                  progressiveThrottle > 0.05f -> "DRIVE ${(progressiveThrottle * 100).roundToInt()}%"
                  else -> "COAST"
                }
              Text(
                text = statusMsg,
                style = MaterialTheme.typography.labelLarge,
                color =
                  if (door1Open || door2Open || kneelingActive) OmsiTheme.extended.alertCrimson
                  else OmsiTheme.extended.verifiedGreen,
              )
              Text(
                text = controlConfig.steeringMode.label.uppercase(),
                style = MaterialTheme.typography.labelSmall,
                color = OmsiTheme.extended.mutedText,
              )
            }
          }
        }
      }

      // Bottom Mobile-Only Driving Controls Deck
      Row(
        modifier = Modifier.fillMaxWidth().height(172.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.Bottom,
      ) {
        // Left: Steering Module + Blinkers
        Surface(
          modifier = Modifier.width(260.dp).fillMaxHeight(),
          shape = RoundedCornerShape(14.dp),
          color = MaterialTheme.colorScheme.surface.copy(alpha = 0.88f),
          border = BorderStroke(1.dp, OmsiTheme.extended.border),
        ) {
          Column(
            modifier = Modifier.fillMaxSize().padding(12.dp),
            verticalArrangement = Arrangement.SpaceBetween,
          ) {
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.SpaceBetween,
              verticalAlignment = Alignment.CenterVertically,
            ) {
              FilledTonalButton(
                onClick = { leftBlinker = !leftBlinker },
                modifier = Modifier.minimumInteractiveComponentSize().testTag("cockpit_blinker_left"),
                colors =
                  ButtonDefaults.filledTonalButtonColors(
                    containerColor =
                      if (leftBlinker) OmsiTheme.extended.transitAmberContainer
                      else OmsiTheme.extended.elevatedSurface
                  ),
              ) {
                Text(
                  text = "◄ L",
                  color =
                    if (leftBlinker) MaterialTheme.colorScheme.secondary
                    else MaterialTheme.colorScheme.onSurface,
                )
              }
              Text(
                text = "STEER ${(steeringNormalized * 450).roundToInt()}°",
                style = MaterialTheme.typography.labelMedium,
                color = MaterialTheme.colorScheme.primary,
              )
              FilledTonalButton(
                onClick = { rightBlinker = !rightBlinker },
                modifier = Modifier.minimumInteractiveComponentSize().testTag("cockpit_blinker_right"),
                colors =
                  ButtonDefaults.filledTonalButtonColors(
                    containerColor =
                      if (rightBlinker) OmsiTheme.extended.transitAmberContainer
                      else OmsiTheme.extended.elevatedSurface
                  ),
              ) {
                Text(
                  text = "R ►",
                  color =
                    if (rightBlinker) MaterialTheme.colorScheme.secondary
                    else MaterialTheme.colorScheme.onSurface,
                )
              }
            }

            when (controlConfig.steeringMode) {
              SteeringMode.GYROSCOPE_TILT -> {
                Column(
                  modifier = Modifier.fillMaxWidth(),
                  horizontalAlignment = Alignment.CenterHorizontally,
                ) {
                  Text(
                    text = "GYROSCOPE ACTIVE • TILT DEVICE",
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.primary,
                  )
                  Spacer(modifier = Modifier.height(6.dp))
                  Slider(
                    value = steeringNormalized,
                    onValueChange = { steeringNormalized = it },
                    valueRange = -1f..1f,
                    enabled = false,
                    colors =
                      SliderDefaults.colors(
                        disabledThumbColor = MaterialTheme.colorScheme.primary,
                        disabledActiveTrackColor = MaterialTheme.colorScheme.primary,
                      ),
                  )
                }
              }
              SteeringMode.VIRTUAL_WHEEL -> {
                val primaryColor = MaterialTheme.colorScheme.primary
                val trackColor = OmsiTheme.extended.border
                Box(
                  modifier =
                    Modifier.fillMaxWidth()
                      .height(84.dp)
                      .pointerInput(controlConfig.autoCenterSteering) {
                        detectHorizontalDragGestures(
                          onDragEnd = {
                            if (controlConfig.autoCenterSteering) steeringNormalized = 0f
                          },
                          onHorizontalDrag = { _, dragAmount ->
                            steeringNormalized =
                              (steeringNormalized + (dragAmount / 180f) * controlConfig.steeringSensitivity)
                                .coerceIn(-1f, 1f)
                          },
                        )
                      }
                      .testTag("cockpit_virtual_wheel"),
                  contentAlignment = Alignment.Center,
                ) {
                  Canvas(modifier = Modifier.size(76.dp)) {
                    drawCircle(
                      color = trackColor,
                      style = Stroke(width = 8.dp.toPx()),
                    )
                    val angleRad = steeringNormalized * 1.4f
                    val spokeEnd =
                      Offset(
                        x = center.x + kotlin.math.sin(angleRad) * (size.minDimension * 0.4f),
                        y = center.y - kotlin.math.cos(angleRad) * (size.minDimension * 0.4f),
                      )
                    drawLine(
                      color = primaryColor,
                      start = center,
                      end = spokeEnd,
                      strokeWidth = 6.dp.toPx(),
                      cap = StrokeCap.Round,
                    )
                  }
                }
              }
              SteeringMode.TOUCH_SLIDER -> {
                Slider(
                  value = steeringNormalized,
                  onValueChange = { steeringNormalized = it },
                  onValueChangeFinished = {
                    if (controlConfig.autoCenterSteering) steeringNormalized = 0f
                  },
                  valueRange = -1f..1f,
                  modifier = Modifier.fillMaxWidth().testTag("cockpit_steering_slider"),
                  colors =
                    SliderDefaults.colors(
                      thumbColor = MaterialTheme.colorScheme.primary,
                      activeTrackColor = MaterialTheme.colorScheme.primary,
                    ),
                )
              }
            }
          }
        }

        // Center: Bus Quick Cockpit Switches (Doors, Kneeling, Lights, Retarder)
        Surface(
          shape = RoundedCornerShape(14.dp),
          color = MaterialTheme.colorScheme.surface.copy(alpha = 0.88f),
          border = BorderStroke(1.dp, OmsiTheme.extended.border),
        ) {
          Row(
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 10.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalAlignment = Alignment.CenterVertically,
          ) {
            CockpitToggleChip(
              label = "DOOR 1",
              active = door1Open,
              icon = Icons.Default.DoorFront,
              tag = "cockpit_door_1",
              onClick = { door1Open = !door1Open },
            )
            CockpitToggleChip(
              label = "DOOR 2",
              active = door2Open,
              icon = Icons.Default.DoorFront,
              tag = "cockpit_door_2",
              onClick = { door2Open = !door2Open },
            )
            CockpitToggleChip(
              label = "KNEEL",
              active = kneelingActive,
              icon = Icons.Default.AirlineSeatReclineNormal,
              tag = "cockpit_kneel",
              onClick = { kneelingActive = !kneelingActive },
            )
            CockpitToggleChip(
              label = "LIGHTS",
              active = headlightsOn,
              icon = Icons.Default.Highlight,
              tag = "cockpit_lights",
              onClick = { headlightsOn = !headlightsOn },
            )
            CockpitToggleChip(
              label = "RETARD",
              active = retarderActive,
              icon = Icons.Default.Sync,
              tag = "cockpit_retarder",
              onClick = { retarderActive = !retarderActive },
            )
          }
        }

        // Right: Progressive Brake & Progressive Accelerator Pedals
        Row(
          modifier = Modifier.fillMaxHeight(),
          horizontalArrangement = Arrangement.spacedBy(10.dp),
          verticalAlignment = Alignment.Bottom,
        ) {
          ProgressivePedalPad(
            title = "BRAKE",
            level = progressiveBrake,
            accentColor = OmsiTheme.extended.alertCrimson,
            tag = "cockpit_brake_pedal",
            onInputChanged = { pressed, level ->
              if (pressed && !rawBrakePressed && controlConfig.progressiveHaptics) {
                view.performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP)
              }
              rawBrakePressed = pressed
              rawBrakeTouchLevel = level
            },
          )
          ProgressivePedalPad(
            title = "GAS",
            level = progressiveThrottle,
            accentColor = OmsiTheme.extended.verifiedGreen,
            tag = "cockpit_gas_pedal",
            onInputChanged = { pressed, level ->
              if (pressed && !rawThrottlePressed && controlConfig.progressiveHaptics) {
                view.performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP)
              }
              rawThrottlePressed = pressed
              rawThrottleTouchLevel = level
            },
          )
        }
      }
    }
  }
}

@Composable
private fun CockpitToggleChip(
  label: String,
  active: Boolean,
  icon: androidx.compose.ui.graphics.vector.ImageVector,
  tag: String,
  onClick: () -> Unit,
) {
  Surface(
    onClick = onClick,
    modifier = Modifier.minimumInteractiveComponentSize().testTag(tag),
    shape = RoundedCornerShape(10.dp),
    color =
      if (active) MaterialTheme.colorScheme.primaryContainer
      else OmsiTheme.extended.elevatedSurface,
    border =
      BorderStroke(
        1.dp,
        if (active) MaterialTheme.colorScheme.primary else OmsiTheme.extended.border,
      ),
  ) {
    Column(
      modifier = Modifier.padding(horizontal = 10.dp, vertical = 8.dp),
      horizontalAlignment = Alignment.CenterHorizontally,
    ) {
      Icon(
        imageVector = icon,
        contentDescription = label,
        tint =
          if (active) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface,
        modifier = Modifier.size(18.dp),
      )
      Spacer(modifier = Modifier.height(3.dp))
      Text(
        text = label,
        style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
        color =
          if (active) MaterialTheme.colorScheme.primary else OmsiTheme.extended.mutedText,
      )
    }
  }
}

@Composable
fun ProgressivePedalPad(
  title: String,
  level: Float,
  accentColor: Color,
  tag: String,
  onInputChanged: (pressed: Boolean, verticalNormalized: Float) -> Unit,
) {
  Surface(
    modifier =
      Modifier.width(96.dp)
        .fillMaxHeight()
        .clip(RoundedCornerShape(14.dp))
        .pointerInput(Unit) {
          awaitEachGesture {
            val down = awaitFirstDown()
            val heightPx = size.height.toFloat().coerceAtLeast(1f)
            val initialNorm = (1f - (down.position.y / heightPx)).coerceIn(0.35f, 1f)
            onInputChanged(true, initialNorm)
            while (true) {
              val event = awaitPointerEvent()
              val change = event.changes.firstOrNull() ?: break
              if (!change.pressed) {
                onInputChanged(false, 0f)
                break
              }
              val norm = (1f - (change.position.y / heightPx)).coerceIn(0.25f, 1f)
              onInputChanged(true, norm)
            }
          }
        }
        .testTag(tag),
    shape = RoundedCornerShape(14.dp),
    color = MaterialTheme.colorScheme.surface.copy(alpha = 0.9f),
    border = BorderStroke(1.5.dp, if (level > 0.05f) accentColor else OmsiTheme.extended.border),
  ) {
    Box(modifier = Modifier.fillMaxSize()) {
      // Progressive fill bar rising from bottom
      Box(
        modifier =
          Modifier.fillMaxWidth()
            .fillMaxHeight(level.coerceIn(0f, 1f))
            .align(Alignment.BottomCenter)
            .background(accentColor.copy(alpha = 0.28f))
      )
      Column(
        modifier = Modifier.fillMaxSize().padding(10.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.SpaceBetween,
      ) {
        Text(
          text = "${(level * 100).roundToInt()}%",
          style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold),
          color = accentColor,
        )
        Box(
          modifier =
            Modifier.size(8.dp)
              .clip(CircleShape)
              .background(if (level > 0.05f) accentColor else OmsiTheme.extended.border)
        )
        Text(
          text = title,
          style = MaterialTheme.typography.labelLarge,
          color = MaterialTheme.colorScheme.onSurface,
        )
      }
    }
  }
}
