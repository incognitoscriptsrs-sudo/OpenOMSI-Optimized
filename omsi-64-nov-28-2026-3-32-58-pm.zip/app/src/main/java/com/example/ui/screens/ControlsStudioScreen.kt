package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import com.example.data.hardware.ProgressiveControlMath
import com.example.domain.model.MobileControlConfig
import com.example.domain.model.SteeringMode
import com.example.ui.cockpit.ProgressivePedalPad
import com.example.ui.components.GamingPanel
import com.example.ui.components.SectionHeader
import com.example.ui.components.TelemetryStatCell
import com.example.ui.theme.OmsiTheme
import kotlin.math.roundToInt
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive

@Composable
fun ControlsStudioScreen(
  config: MobileControlConfig,
  onUpdateConfig: ((MobileControlConfig) -> MobileControlConfig) -> Unit,
) {
  var testGasPressed by remember { mutableStateOf(false) }
  var testGasRaw by remember { mutableFloatStateOf(0f) }
  var testGasOut by remember { mutableFloatStateOf(0f) }

  var testBrakePressed by remember { mutableStateOf(false) }
  var testBrakeRaw by remember { mutableFloatStateOf(0f) }
  var testBrakeOut by remember { mutableFloatStateOf(0f) }

  LaunchedEffect(config) {
    while (isActive) {
      val targetGas =
        if (testGasPressed) {
          ProgressiveControlMath.applyProgressiveCurve(
            testGasRaw,
            config.throttleDeadzone,
            config.throttleExponent,
          )
        } else 0f
      testGasOut =
        ProgressiveControlMath.stepProgressiveHold(
          testGasOut,
          targetGas,
          config.throttleHoldRampRate,
          0.016f,
        )

      val targetBrake =
        if (testBrakePressed) {
          ProgressiveControlMath.applyProgressiveCurve(
            testBrakeRaw,
            config.brakeDeadzone,
            config.brakeExponent,
          )
        } else 0f
      testBrakeOut =
        ProgressiveControlMath.stepProgressiveHold(testBrakeOut, targetBrake, 2.5f, 0.016f)
      delay(16L)
    }
  }

  Row(
    modifier = Modifier.fillMaxSize().padding(16.dp),
    horizontalArrangement = Arrangement.spacedBy(16.dp),
  ) {
    // Left: Progressive Acceleration & Steering Calibration (54%)
    GamingPanel(modifier = Modifier.weight(0.54f).fillMaxHeight()) {
      Column(
        modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(12.dp),
      ) {
        SectionHeader(
          title = "Mobile Progressive Controls",
          subtitle = "Touch-first throttle curves & handheld steering calibration",
        )

        Text(
          text = "STEERING METHOD",
          style = MaterialTheme.typography.labelMedium,
          color = MaterialTheme.colorScheme.primary,
        )
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
          SteeringMode.entries.forEach { mode ->
            val selected = config.steeringMode == mode
            Surface(
              onClick = { onUpdateConfig { it.copy(steeringMode = mode) } },
              modifier =
                Modifier.weight(1f).testTag("steering_mode_${mode.name.lowercase()}"),
              shape = RoundedCornerShape(8.dp),
              color =
                if (selected) MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.4f)
                else OmsiTheme.extended.elevatedSurface,
              border =
                BorderStroke(
                  1.dp,
                  if (selected) MaterialTheme.colorScheme.primary else OmsiTheme.extended.border,
                ),
            ) {
              Column(modifier = Modifier.padding(10.dp)) {
                Text(
                  text = mode.label,
                  style = MaterialTheme.typography.titleMedium,
                  color =
                    if (selected) MaterialTheme.colorScheme.primary
                    else MaterialTheme.colorScheme.onSurface,
                )
                Text(
                  text = mode.description,
                  style = MaterialTheme.typography.labelSmall,
                  color = OmsiTheme.extended.mutedText,
                )
              }
            }
          }
        }

        Column {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
          ) {
            Text("Progressive Throttle Curve", style = MaterialTheme.typography.bodyLarge)
            Text(
              text = "exp ${"%.2f".format(config.throttleExponent)}",
              style = MaterialTheme.typography.labelMedium,
              color = OmsiTheme.extended.verifiedGreen,
            )
          }
          Slider(
            value = config.throttleExponent,
            onValueChange = { v -> onUpdateConfig { it.copy(throttleExponent = v) } },
            valueRange = 0.8f..2.8f,
            modifier = Modifier.testTag("slider_throttle_exponent"),
          )
        }

        Column {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
          ) {
            Text("Progressive Pedal Ramp Speed", style = MaterialTheme.typography.bodyLarge)
            Text(
              text = "${"%.2f".format(config.throttleHoldRampRate)} /s",
              style = MaterialTheme.typography.labelMedium,
              color = MaterialTheme.colorScheme.primary,
            )
          }
          Slider(
            value = config.throttleHoldRampRate,
            onValueChange = { v -> onUpdateConfig { it.copy(throttleHoldRampRate = v) } },
            valueRange = 0.35f..2.5f,
            modifier = Modifier.testTag("slider_throttle_ramp"),
          )
        }

        Column {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
          ) {
            Text("Progressive Brake Curve", style = MaterialTheme.typography.bodyLarge)
            Text(
              text = "exp ${"%.2f".format(config.brakeExponent)}",
              style = MaterialTheme.typography.labelMedium,
              color = OmsiTheme.extended.alertCrimson,
            )
          }
          Slider(
            value = config.brakeExponent,
            onValueChange = { v -> onUpdateConfig { it.copy(brakeExponent = v) } },
            valueRange = 0.8f..2.6f,
            modifier = Modifier.testTag("slider_brake_exponent"),
          )
        }

        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
          Column(modifier = Modifier.weight(1f)) {
            Text(
              text = "Steering Gain: ${"%.2f".format(config.steeringSensitivity)}x",
              style = MaterialTheme.typography.bodyMedium,
            )
            Slider(
              value = config.steeringSensitivity,
              onValueChange = { v -> onUpdateConfig { it.copy(steeringSensitivity = v) } },
              valueRange = 0.6f..2.0f,
              modifier = Modifier.testTag("slider_steering_sensitivity"),
            )
          }
          Column(modifier = Modifier.weight(1f)) {
            Text(
              text = "Gyro Deadzone: ${"%.1f".format(config.gyroDeadzoneDegrees)}°",
              style = MaterialTheme.typography.bodyMedium,
            )
            Slider(
              value = config.gyroDeadzoneDegrees,
              onValueChange = { v -> onUpdateConfig { it.copy(gyroDeadzoneDegrees = v) } },
              valueRange = 0.5f..8.0f,
              modifier = Modifier.testTag("slider_gyro_deadzone"),
            )
          }
        }

        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically,
        ) {
          Text("Auto-Center Steering on Release", style = MaterialTheme.typography.bodyLarge)
          Switch(
            checked = config.autoCenterSteering,
            onCheckedChange = { v -> onUpdateConfig { it.copy(autoCenterSteering = v) } },
            modifier = Modifier.testTag("toggle_auto_center"),
          )
        }

        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically,
        ) {
          Text("Progressive Pedal Haptic Detents", style = MaterialTheme.typography.bodyLarge)
          Switch(
            checked = config.progressiveHaptics,
            onCheckedChange = { v -> onUpdateConfig { it.copy(progressiveHaptics = v) } },
            modifier = Modifier.testTag("toggle_progressive_haptics"),
          )
        }
      }
    }

    // Right: Live Curve Plotter & Interactive Pedal Test Bench (46%)
    GamingPanel(modifier = Modifier.weight(0.46f).fillMaxHeight()) {
      Column(
        modifier = Modifier.fillMaxSize(),
        verticalArrangement = Arrangement.SpaceBetween,
      ) {
        SectionHeader(
          title = "Live Curve & Pedal Bench",
          subtitle = "Press or slide pedals below to verify smooth ramp",
        )

        val gridColor = OmsiTheme.extended.border
        val gasColor = OmsiTheme.extended.verifiedGreen
        val brakeColor = OmsiTheme.extended.alertCrimson

        Box(
          modifier =
            Modifier.fillMaxWidth()
              .height(148.dp)
              .clip(RoundedCornerShape(10.dp))
              .background(OmsiTheme.extended.elevatedSurface)
              .padding(12.dp)
        ) {
          Canvas(modifier = Modifier.fillMaxSize().testTag("progressive_curve_canvas")) {
            val w = size.width
            val h = size.height
            // Grid lines
            for (step in 1..3) {
              val y = h * (step / 4f)
              val x = w * (step / 4f)
              drawLine(gridColor, Offset(0f, y), Offset(w, y), strokeWidth = 1.dp.toPx())
              drawLine(gridColor, Offset(x, 0f), Offset(x, h), strokeWidth = 1.dp.toPx())
            }

            // Brake curve path
            val brakePath = Path()
            for (i in 0..40) {
              val xNorm = i / 40f
              val yNorm =
                ProgressiveControlMath.applyProgressiveCurve(
                  xNorm,
                  config.brakeDeadzone,
                  config.brakeExponent,
                )
              val px = xNorm * w
              val py = h - (yNorm * h)
              if (i == 0) brakePath.moveTo(px, py) else brakePath.lineTo(px, py)
            }
            drawPath(
              path = brakePath,
              color = brakeColor.copy(alpha = 0.7f),
              style = Stroke(width = 2.5.dp.toPx(), cap = StrokeCap.Round),
            )

            // Throttle curve path
            val gasPath = Path()
            for (i in 0..40) {
              val xNorm = i / 40f
              val yNorm =
                ProgressiveControlMath.applyProgressiveCurve(
                  xNorm,
                  config.throttleDeadzone,
                  config.throttleExponent,
                )
              val px = xNorm * w
              val py = h - (yNorm * h)
              if (i == 0) gasPath.moveTo(px, py) else gasPath.lineTo(px, py)
            }
            drawPath(
              path = gasPath,
              color = gasColor,
              style = Stroke(width = 3.dp.toPx(), cap = StrokeCap.Round),
            )

            // Live dot on gas curve
            if (testGasOut > 0.01f) {
              drawCircle(
                color = gasColor,
                radius = 5.dp.toPx(),
                center = Offset(testGasRaw * w, h - testGasOut * h),
              )
            }
          }
        }

        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
          TelemetryStatCell(
            label = "Throttle Output",
            value = "${(testGasOut * 100).roundToInt()}%",
            accentColor = OmsiTheme.extended.verifiedGreen,
            modifier = Modifier.weight(1f),
          )
          TelemetryStatCell(
            label = "Brake Output",
            value = "${(testBrakeOut * 100).roundToInt()}%",
            accentColor = OmsiTheme.extended.alertCrimson,
            modifier = Modifier.weight(1f),
          )
        }

        Row(
          modifier = Modifier.fillMaxWidth().height(132.dp),
          horizontalArrangement = Arrangement.spacedBy(16.dp, Alignment.CenterHorizontally),
          verticalAlignment = Alignment.Bottom,
        ) {
          ProgressivePedalPad(
            title = "TEST BRAKE",
            level = testBrakeOut,
            accentColor = OmsiTheme.extended.alertCrimson,
            tag = "bench_brake_pedal",
            onInputChanged = { pressed, level ->
              testBrakePressed = pressed
              testBrakeRaw = level
            },
          )
          ProgressivePedalPad(
            title = "TEST GAS",
            level = testGasOut,
            accentColor = OmsiTheme.extended.verifiedGreen,
            tag = "bench_gas_pedal",
            onInputChanged = { pressed, level ->
              testGasPressed = pressed
              testGasRaw = level
            },
          )
        }
      }
    }
  }
}
