package com.example.ui.cockpit

import android.opengl.GLES30
import android.opengl.GLSurfaceView
import android.opengl.Matrix
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.FloatBuffer
import javax.microedition.khronos.egl.EGLConfig
import javax.microedition.khronos.opengles.GL10
import kotlin.math.abs

/**
 * Hardware-accelerated OpenGL ES 3.0 64-bit native viewport renderer for the OMSI 64 driving
 * cockpit. Renders a 3D perspective urban bus corridor synchronized with progressive throttle,
 * brake, steering, and headlight state.
 */
class OmsiGlRenderer(
  private val onFpsMeasured: (Int, Float) -> Unit,
) : GLSurfaceView.Renderer {

  @Volatile var speedKmh: Float = 0f
  @Volatile var steeringNormalized: Float = 0f
  @Volatile var headlightsOn: Boolean = true
  @Volatile var brakeApplied: Boolean = false

  private var programId: Int = 0
  private var posAttr: Int = 0
  private var colorAttr: Int = 0
  private var mvpUniform: Int = 0

  private val projectionMatrix = FloatArray(16)
  private val viewMatrix = FloatArray(16)
  private val mvpMatrix = FloatArray(16)

  private var roadOffsetZ = 0f
  private var lastFrameNanos = System.nanoTime()
  private var fpsAccumulator = 0
  private var fpsWindowStartNanos = System.nanoTime()

  private var dynamicBuffer: FloatBuffer =
    ByteBuffer.allocateDirect(4096 * 4).order(ByteOrder.nativeOrder()).asFloatBuffer()

  override fun onSurfaceCreated(gl: GL10?, config: EGLConfig?) {
    GLES30.glClearColor(0.035f, 0.043f, 0.06f, 1.0f)
    GLES30.glEnable(GLES30.GL_DEPTH_TEST)
    GLES30.glEnable(GLES30.GL_BLEND)
    GLES30.glBlendFunc(GLES30.GL_SRC_ALPHA, GLES30.GL_ONE_MINUS_SRC_ALPHA)

    val vertexShader =
      compileShader(
        GLES30.GL_VERTEX_SHADER,
        """
        #version 300 es
        layout(location = 0) in vec3 aPosition;
        layout(location = 1) in vec4 aColor;
        uniform mat4 uMvp;
        out vec4 vColor;
        void main() {
          gl_Position = uMvp * vec4(aPosition, 1.0);
          vColor = aColor;
        }
        """.trimIndent(),
      )
    val fragmentShader =
      compileShader(
        GLES30.GL_FRAGMENT_SHADER,
        """
        #version 300 es
        precision mediump float;
        in vec4 vColor;
        out vec4 fragColor;
        void main() {
          fragColor = vColor;
        }
        """.trimIndent(),
      )

    programId = GLES30.glCreateProgram()
    GLES30.glAttachShader(programId, vertexShader)
    GLES30.glAttachShader(programId, fragmentShader)
    GLES30.glLinkProgram(programId)
    posAttr = 0
    colorAttr = 1
    mvpUniform = GLES30.glGetUniformLocation(programId, "uMvp")
  }

  override fun onSurfaceChanged(gl: GL10?, width: Int, height: Int) {
    GLES30.glViewport(0, 0, width, height)
    val ratio = width.toFloat() / height.coerceAtLeast(1).toFloat()
    Matrix.perspectiveM(projectionMatrix, 0, 62f, ratio, 0.2f, 160f)
  }

  override fun onDrawFrame(gl: GL10?) {
    val now = System.nanoTime()
    val dt = ((now - lastFrameNanos) / 1_000_000_000f).coerceIn(0.001f, 0.1f)
    lastFrameNanos = now

    fpsAccumulator++
    val windowNs = now - fpsWindowStartNanos
    if (windowNs >= 500_000_000L) {
      val fps = ((fpsAccumulator * 1_000_000_000.0) / windowNs).toInt().coerceIn(1, 144)
      val frameMs = (windowNs / 1_000_000f) / fpsAccumulator
      onFpsMeasured(fps, frameMs)
      fpsAccumulator = 0
      fpsWindowStartNanos = now
    }

    val metersPerSec = speedKmh / 3.6f
    roadOffsetZ = (roadOffsetZ + metersPerSec * dt) % 10f

    GLES30.glClear(GLES30.GL_COLOR_BUFFER_BIT or GLES30.GL_DEPTH_BUFFER_BIT)
    GLES30.glUseProgram(programId)

    val camX = steeringNormalized * 1.1f
    val lookX = steeringNormalized * 6.5f
    Matrix.setLookAtM(viewMatrix, 0, camX, 2.35f, 0f, lookX, 1.3f, -35f, 0f, 1f, 0f)
    Matrix.multiplyMM(mvpMatrix, 0, projectionMatrix, 0, viewMatrix, 0)
    GLES30.glUniformMatrix4fv(mvpUniform, 1, false, mvpMatrix, 0)

    val vertices = buildCorridorGeometry()
    dynamicBuffer.clear()
    if (vertices.size > dynamicBuffer.capacity()) {
      dynamicBuffer =
        ByteBuffer.allocateDirect(vertices.size * 4).order(ByteOrder.nativeOrder()).asFloatBuffer()
    }
    dynamicBuffer.put(vertices).position(0)

    val stride = 7 * 4
    GLES30.glEnableVertexAttribArray(posAttr)
    GLES30.glVertexAttribPointer(posAttr, 3, GLES30.GL_FLOAT, false, stride, dynamicBuffer)

    dynamicBuffer.position(3)
    GLES30.glEnableVertexAttribArray(colorAttr)
    GLES30.glVertexAttribPointer(colorAttr, 4, GLES30.GL_FLOAT, false, stride, dynamicBuffer)

    val vertexCount = vertices.size / 7
    GLES30.glDrawArrays(GLES30.GL_TRIANGLES, 0, vertexCount)
  }

  private fun buildCorridorGeometry(): FloatArray {
    val list = ArrayList<Float>(2400)
    val curve = steeringNormalized * 0.008f

    // Asphalt road bed segments (-5f to -140f)
    for (seg in 0 until 26) {
      val z0 = -seg * 5f + (roadOffsetZ % 5f)
      val z1 = z0 - 5f
      val cx0 = curve * z0 * z0
      val cx1 = curve * z1 * z1
      val roadHalf = 4.6f

      val brightness = if (headlightsOn) 0.14f else 0.08f
      val glow = if (headlightsOn && abs(z0) < 35f) (1f - abs(z0) / 35f) * 0.12f else 0f
      val r = brightness + glow * 0.7f
      val g = brightness + glow * 0.9f
      val b = brightness + glow * 1.1f + 0.03f

      pushQuad(
        list,
        cx0 - roadHalf, 0f, z0,
        cx0 + roadHalf, 0f, z0,
        cx1 + roadHalf, 0f, z1,
        cx1 - roadHalf, 0f, z1,
        r, g, b, 1f,
      )

      // Curb cyan/amber edge guides
      val edgeR = if (brakeApplied) 1.0f else 0.0f
      val edgeG = if (brakeApplied) 0.25f else 0.9f
      val edgeB = if (brakeApplied) 0.35f else 1.0f
      pushQuad(
        list,
        cx0 - roadHalf - 0.18f, 0.02f, z0,
        cx0 - roadHalf, 0.02f, z0,
        cx1 - roadHalf, 0.02f, z1,
        cx1 - roadHalf - 0.18f, 0.02f, z1,
        edgeR, edgeG, edgeB, 0.75f,
      )
      pushQuad(
        list,
        cx0 + roadHalf, 0.02f, z0,
        cx0 + roadHalf + 0.18f, 0.02f, z0,
        cx1 + roadHalf + 0.18f, 0.02f, z1,
        cx1 + roadHalf, 0.02f, z1,
        edgeR, edgeG, edgeB, 0.75f,
      )

      // Dashed center transit lane markings every 10m
      if (seg % 2 == 0) {
        pushQuad(
          list,
          cx0 - 0.11f, 0.025f, z0 - 0.8f,
          cx0 + 0.11f, 0.025f, z0 - 0.8f,
          cx1 + 0.11f, 0.025f, z1 + 0.8f,
          cx1 - 0.11f, 0.025f, z1 + 0.8f,
          1.0f, 0.70f, 0.0f, 0.9f,
        )
      }

      // Stylized roadside transit light poles every 20m
      if (seg % 4 == 0) {
        val poleX = cx0 - roadHalf - 1.2f
        pushQuad(
          list,
          poleX - 0.08f, 0f, z0,
          poleX + 0.08f, 0f, z0,
          poleX + 0.08f, 5.2f, z0,
          poleX - 0.08f, 5.2f, z0,
          0.16f, 0.20f, 0.28f, 1f,
        )
        pushQuad(
          list,
          poleX, 5.0f, z0 - 0.15f,
          poleX + 1.4f, 5.0f, z0 - 0.15f,
          poleX + 1.4f, 5.18f, z0 + 0.15f,
          poleX, 5.18f, z0 + 0.15f,
          1.0f, 0.75f, 0.2f, 0.95f,
        )
      }
    }

    return list.toFloatArray()
  }

  private fun pushQuad(
    out: ArrayList<Float>,
    x0: Float, y0: Float, z0: Float,
    x1: Float, y1: Float, z1: Float,
    x2: Float, y2: Float, z2: Float,
    x3: Float, y3: Float, z3: Float,
    r: Float, g: Float, b: Float, a: Float,
  ) {
    pushVertex(out, x0, y0, z0, r, g, b, a)
    pushVertex(out, x1, y1, z1, r, g, b, a)
    pushVertex(out, x2, y2, z2, r, g, b, a)

    pushVertex(out, x0, y0, z0, r, g, b, a)
    pushVertex(out, x2, y2, z2, r, g, b, a)
    pushVertex(out, x3, y3, z3, r, g, b, a)
  }

  private fun pushVertex(
    out: ArrayList<Float>,
    x: Float, y: Float, z: Float,
    r: Float, g: Float, b: Float, a: Float,
  ) {
    out.add(x)
    out.add(y)
    out.add(z)
    out.add(r)
    out.add(g)
    out.add(b)
    out.add(a)
  }

  private fun compileShader(type: Int, source: String): Int {
    val shader = GLES30.glCreateShader(type)
    GLES30.glShaderSource(shader, source)
    GLES30.glCompileShader(shader)
    return shader
  }
}
