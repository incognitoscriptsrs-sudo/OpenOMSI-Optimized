package com.example.ui.theme

import androidx.compose.runtime.Immutable
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color

val ObsidianBg = Color(0xFF090B0F)
val CarbonSurface = Color(0xFF11151D)
val ElevatedCarbon = Color(0xFF181E29)
val CrispBorder = Color(0xFF273042)
val ElectricCyan = Color(0xFF00E5FF)
val CyanDim = Color(0xFF004B59)
val TransitAmber = Color(0xFFFFB300)
val AmberDim = Color(0xFF4D3600)
val TelemetryGreen = Color(0xFF00E676)
val GreenDim = Color(0xFF0A3D24)
val AlertCrimson = Color(0xFFFF3D57)
val CrimsonDim = Color(0xFF4A121D)
val CrispText = Color(0xFFF4F7FB)
val MutedSlate = Color(0xFF8D99AE)

@Immutable
data class OmsiExtendedColors(
  val border: Color = CrispBorder,
  val elevatedSurface: Color = ElevatedCarbon,
  val verifiedGreen: Color = TelemetryGreen,
  val verifiedGreenContainer: Color = GreenDim,
  val alertCrimson: Color = AlertCrimson,
  val alertCrimsonContainer: Color = CrimsonDim,
  val transitAmber: Color = TransitAmber,
  val transitAmberContainer: Color = AmberDim,
  val electricCyanContainer: Color = CyanDim,
  val mutedText: Color = MutedSlate,
)

val LocalOmsiColors = staticCompositionLocalOf { OmsiExtendedColors() }
