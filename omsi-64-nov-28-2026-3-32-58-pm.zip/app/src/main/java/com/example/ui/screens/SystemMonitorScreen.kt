package com.example.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.unit.dp
import com.example.domain.model.DeviceTelemetrySnapshot
import com.example.ui.components.GamingPanel
import com.example.ui.components.SectionHeader
import com.example.ui.components.StatusPill
import com.example.ui.components.TelemetryStatCell
import com.example.ui.theme.OmsiTheme

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun SystemMonitorScreen(telemetry: DeviceTelemetrySnapshot) {
  Row(
    modifier = Modifier.fillMaxSize().padding(16.dp),
    horizontalArrangement = Arrangement.spacedBy(16.dp),
  ) {
    // Left: Snapdragon SoC, 64-Bit ABI & GPU Hardware Verification
    GamingPanel(modifier = Modifier.weight(1f).fillMaxHeight()) {
      Column(
        modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(12.dp),
      ) {
        SectionHeader(
          title = "ARM64 & Snapdragon Probe",
          subtitle = telemetry.deviceModel,
          trailing = {
            StatusPill(
              text = if (telemetry.isArm64) "64-BIT ARM64" else "NON-ARM64",
              dotColor =
                if (telemetry.isArm64) OmsiTheme.extended.verifiedGreen
                else OmsiTheme.extended.alertCrimson,
              containerColor =
                if (telemetry.isArm64) OmsiTheme.extended.verifiedGreenContainer
                else OmsiTheme.extended.alertCrimsonContainer,
              textColor =
                if (telemetry.isArm64) OmsiTheme.extended.verifiedGreen
                else OmsiTheme.extended.alertCrimson,
            )
          },
        )

        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
          TelemetryStatCell(
            label = "SoC / Chipset",
            value = telemetry.socModel,
            accentColor = MaterialTheme.colorScheme.primary,
            modifier = Modifier.weight(1f),
          )
          TelemetryStatCell(
            label = "Supported ABIs",
            value = telemetry.abiList.joinToString(", ").ifBlank { "arm64-v8a" },
            modifier = Modifier.weight(1f),
          )
        }

        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
          TelemetryStatCell(
            label = "GPU Renderer",
            value = telemetry.gpuRenderer,
            accentColor = MaterialTheme.colorScheme.secondary,
            modifier = Modifier.weight(1f),
          )
          TelemetryStatCell(
            label = "Vulkan Hardware",
            value = telemetry.vulkanVersionLabel,
            accentColor =
              if (telemetry.vulkanSupported) OmsiTheme.extended.verifiedGreen
              else MaterialTheme.colorScheme.secondary,
            modifier = Modifier.weight(1f),
          )
        }

        TelemetryStatCell(
          label = "OpenGL ES Driver",
          value = "${telemetry.gpuVendor} • ${telemetry.glVersion}",
          modifier = Modifier.fillMaxWidth(),
        )

        Text(
          text = "EXTERNAL ENGINE COMPATIBILITY",
          style = MaterialTheme.typography.labelMedium,
          color = MaterialTheme.colorScheme.primary,
        )
        Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
          telemetry.externalRuntimes.forEach { runtime ->
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.SpaceBetween,
            ) {
              Text(
                text = runtime.label,
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurface,
              )
              Text(
                text = if (runtime.installed) "Detected" else "Not Installed",
                style = MaterialTheme.typography.labelMedium,
                color =
                  if (runtime.installed) OmsiTheme.extended.verifiedGreen
                  else OmsiTheme.extended.mutedText,
              )
            }
          }
        }
      }
    }

    // Right: Live RAM Headroom, Thermal Status & CPU Core Clocks
    GamingPanel(modifier = Modifier.weight(1f).fillMaxHeight()) {
      Column(
        modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(12.dp),
      ) {
        SectionHeader(
          title = "Live Memory & Thermal Telemetry",
          subtitle = "Polled every 1.5s from Android ActivityManager & PowerManager",
          trailing = {
            val isHot = telemetry.thermalStatusCode >= 3
            StatusPill(
              text = telemetry.thermalLabel,
              dotColor =
                if (isHot) OmsiTheme.extended.alertCrimson else OmsiTheme.extended.verifiedGreen,
              containerColor =
                if (isHot) OmsiTheme.extended.alertCrimsonContainer
                else OmsiTheme.extended.verifiedGreenContainer,
              textColor =
                if (isHot) OmsiTheme.extended.alertCrimson else OmsiTheme.extended.verifiedGreen,
            )
          },
        )

        val usedRamMb = (telemetry.totalRamMb - telemetry.availableRamMb).coerceAtLeast(0L)
        val ramRatio =
          if (telemetry.totalRamMb > 0L) (usedRamMb.toFloat() / telemetry.totalRamMb.toFloat()).coerceIn(0f, 1f)
          else 0f

        Column {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
          ) {
            Text("System Memory Usage", style = MaterialTheme.typography.bodyLarge)
            Text(
              text = "$usedRamMb / ${telemetry.totalRamMb} MB (${telemetry.availableRamMb} MB Free)",
              style = MaterialTheme.typography.labelMedium,
              color = MaterialTheme.colorScheme.primary,
            )
          }
          Spacer(modifier = Modifier.height(6.dp))
          LinearProgressIndicator(
            progress = { ramRatio },
            modifier = Modifier.fillMaxWidth().height(8.dp).clip(RoundedCornerShape(4.dp)),
            color = MaterialTheme.colorScheme.primary,
            trackColor = OmsiTheme.extended.elevatedSurface,
          )
        }

        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
          TelemetryStatCell(
            label = "App Native Heap",
            value = "${telemetry.appNativeHeapMb} MB",
            modifier = Modifier.weight(1f),
          )
          TelemetryStatCell(
            label = "JVM LargeHeap Cap",
            value = "${telemetry.appJvmMaxMb} MB",
            modifier = Modifier.weight(1f),
          )
          TelemetryStatCell(
            label = "Battery Temp",
            value =
              if (telemetry.batteryTempCelsius > 0f) "${"%.1f".format(telemetry.batteryTempCelsius)} °C"
              else "N/A",
            accentColor = MaterialTheme.colorScheme.secondary,
            modifier = Modifier.weight(1f),
          )
        }

        Text(
          text = "CPU CORES (${telemetry.cpuCores} LOGICAL)",
          style = MaterialTheme.typography.labelMedium,
          color = MaterialTheme.colorScheme.primary,
        )
        if (telemetry.cpuCoreFreqsMhz.isNotEmpty()) {
          FlowRow(
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp),
          ) {
            telemetry.cpuCoreFreqsMhz.forEachIndexed { idx, mhz ->
              TelemetryStatCell(
                label = "Core $idx",
                value = "$mhz MHz",
                accentColor = MaterialTheme.colorScheme.onSurface,
              )
            }
          }
        } else {
          Text(
            text = "${telemetry.cpuCores} ARM64 cores active (sysfs clock frequencies restricted by OS policy).",
            style = MaterialTheme.typography.bodySmall,
            color = OmsiTheme.extended.mutedText,
          )
        }
      }
    }
  }
}
