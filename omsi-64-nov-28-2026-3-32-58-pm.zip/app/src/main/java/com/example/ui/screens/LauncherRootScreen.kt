package com.example.ui.screens

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.FolderCopy
import androidx.compose.material.icons.filled.Gamepad
import androidx.compose.material.icons.filled.Memory
import androidx.compose.material.icons.filled.PlayCircle
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material.icons.outlined.FolderCopy
import androidx.compose.material.icons.outlined.Gamepad
import androidx.compose.material.icons.outlined.Memory
import androidx.compose.material.icons.outlined.PlayCircle
import androidx.compose.material.icons.outlined.Tune
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationRail
import androidx.compose.material3.NavigationRailItem
import androidx.compose.material3.NavigationRailItemDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.VerticalDivider
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.data.local.OmsiBusEntity
import com.example.data.local.OmsiMapEntity
import com.example.data.local.OmsiModEntity
import com.example.domain.model.DeviceTelemetrySnapshot
import com.example.domain.model.LauncherTab
import com.example.domain.model.MobileControlConfig
import com.example.domain.model.OmsiInstallStatus
import com.example.domain.model.OptimizationConfig
import com.example.domain.model.OptionsPatchResult
import com.example.domain.model.SnapdragonProfile
import com.example.ui.components.StatusPill
import com.example.ui.theme.OmsiTheme

@Composable
fun LauncherRootScreen(
  activeTab: LauncherTab,
  installStatus: OmsiInstallStatus,
  maps: List<OmsiMapEntity>,
  buses: List<OmsiBusEntity>,
  mods: List<OmsiModEntity>,
  selectedMapId: String?,
  selectedBusId: String?,
  selectedRepaint: String?,
  optimizationConfig: OptimizationConfig,
  mobileControlConfig: MobileControlConfig,
  telemetry: DeviceTelemetrySnapshot,
  patchResult: OptionsPatchResult?,
  onSelectTab: (LauncherTab) -> Unit,
  onPickFolder: () -> Unit,
  onRescan: () -> Unit,
  onUnlinkFolder: () -> Unit,
  onSelectMap: (String) -> Unit,
  onSelectBus: (OmsiBusEntity) -> Unit,
  onSelectRepaint: (String) -> Unit,
  onToggleFavoriteBus: (OmsiBusEntity) -> Unit,
  onSetModEnabled: (OmsiModEntity, Boolean) -> Unit,
  onSelectProfile: (SnapdragonProfile) -> Unit,
  onUpdateOptimization: ((OptimizationConfig) -> OptimizationConfig) -> Unit,
  onApplyOptionsCfg: () -> Unit,
  onRestoreBackup: () -> Unit,
  onUpdateControls: ((MobileControlConfig) -> MobileControlConfig) -> Unit,
  onLaunch64Bit: () -> Unit,
  onLaunchExternalRuntime: (String) -> Unit,
) {
  Surface(
    modifier = Modifier.fillMaxSize(),
    color = MaterialTheme.colorScheme.background,
  ) {
    Row(
      modifier =
        Modifier.fillMaxSize().windowInsetsPadding(WindowInsets.safeDrawing)
    ) {
      // Left Gaming Handheld NavigationRail
      NavigationRail(
        containerColor = MaterialTheme.colorScheme.surface,
        modifier = Modifier.fillMaxHeight().width(86.dp),
        header = {
          Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier.padding(top = 8.dp, bottom = 6.dp),
          ) {
            Image(
              painter = painterResource(id = R.drawable.img_launcher_fg),
              contentDescription = stringResource(R.string.cd_brand_logo),
              modifier = Modifier.size(40.dp).clip(RoundedCornerShape(8.dp)),
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
              text = "OMSI 64",
              style = MaterialTheme.typography.labelSmall,
              color = MaterialTheme.colorScheme.primary,
            )
          }
        },
      ) {
        LauncherTab.entries.forEach { tab ->
          val selected = activeTab == tab
          val (labelRes, selectedIcon, unselectedIcon) =
            when (tab) {
              LauncherTab.PLAY ->
                Triple(R.string.nav_play, Icons.Filled.PlayCircle, Icons.Outlined.PlayCircle)
              LauncherTab.LIBRARY ->
                Triple(R.string.nav_library, Icons.Filled.FolderCopy, Icons.Outlined.FolderCopy)
              LauncherTab.OPTIMIZE ->
                Triple(R.string.nav_optimize, Icons.Filled.Tune, Icons.Outlined.Tune)
              LauncherTab.CONTROLS ->
                Triple(R.string.nav_controls, Icons.Filled.Gamepad, Icons.Outlined.Gamepad)
              LauncherTab.SYSTEM ->
                Triple(R.string.nav_system, Icons.Filled.Memory, Icons.Outlined.Memory)
            }
          NavigationRailItem(
            selected = selected,
            onClick = { onSelectTab(tab) },
            icon = {
              Icon(
                imageVector = if (selected) selectedIcon else unselectedIcon,
                contentDescription = stringResource(labelRes),
              )
            },
            label = { Text(stringResource(labelRes), maxLines = 1) },
            modifier = Modifier.testTag("rail_tab_${tab.name.lowercase()}"),
            colors =
              NavigationRailItemDefaults.colors(
                selectedIconColor = MaterialTheme.colorScheme.primary,
                selectedTextColor = MaterialTheme.colorScheme.primary,
                indicatorColor = MaterialTheme.colorScheme.primaryContainer,
                unselectedIconColor = OmsiTheme.extended.mutedText,
                unselectedTextColor = OmsiTheme.extended.mutedText,
              ),
          )
        }
      }

      VerticalDivider(thickness = 1.dp, color = OmsiTheme.extended.border)

      // Right Workspace Column (Top Telemetry Strip + Active Screen)
      Column(modifier = Modifier.weight(1f).fillMaxHeight()) {
        Row(
          modifier =
            Modifier.fillMaxWidth()
              .background(MaterialTheme.colorScheme.surface)
              .padding(horizontal = 16.dp, vertical = 10.dp),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically,
        ) {
          Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(10.dp),
          ) {
            Text(
              text = stringResource(R.string.app_name),
              style = MaterialTheme.typography.titleLarge,
              color = MaterialTheme.colorScheme.onBackground,
            )
            Text(
              text = stringResource(R.string.launcher_subtitle),
              style = MaterialTheme.typography.labelSmall,
              color = OmsiTheme.extended.mutedText,
            )
          }

          Row(
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalAlignment = Alignment.CenterVertically,
          ) {
            StatusPill(
              text = "FREE ${telemetry.availableRamMb} MB",
              dotColor = OmsiTheme.extended.verifiedGreen,
              containerColor = OmsiTheme.extended.elevatedSurface,
              textColor = MaterialTheme.colorScheme.onSurface,
            )
            StatusPill(
              text = telemetry.thermalLabel.uppercase(),
              dotColor =
                if (telemetry.thermalStatusCode >= 3) OmsiTheme.extended.alertCrimson
                else MaterialTheme.colorScheme.secondary,
              containerColor = OmsiTheme.extended.elevatedSurface,
              textColor = MaterialTheme.colorScheme.onSurface,
            )
          }
        }
        HorizontalDivider(thickness = 1.dp, color = OmsiTheme.extended.border)

        Box(modifier = Modifier.weight(1f).fillMaxWidth()) {
          val selectedMap = maps.firstOrNull { it.id == selectedMapId }
          val selectedBus = buses.firstOrNull { it.id == selectedBusId }

          AnimatedContent(
            targetState = activeTab,
            transitionSpec = {
              fadeIn(animationSpec = tween(180)) togetherWith fadeOut(animationSpec = tween(120))
            },
            label = "launcher_tab_content",
          ) { tab ->
            when (tab) {
              LauncherTab.PLAY ->
                PlayHubScreen(
                  installStatus = installStatus,
                  selectedMap = selectedMap,
                  selectedBus = selectedBus,
                  selectedRepaint = selectedRepaint,
                  optimizationConfig = optimizationConfig,
                  telemetry = telemetry,
                  onPickFolder = onPickFolder,
                  onRescan = onRescan,
                  onUnlinkFolder = onUnlinkFolder,
                  onNavigateTab = onSelectTab,
                  onLaunch64Bit = onLaunch64Bit,
                  onLaunchExternalRuntime = onLaunchExternalRuntime,
                )

              LauncherTab.LIBRARY ->
                LibraryScreen(
                  installStatus = installStatus,
                  maps = maps,
                  buses = buses,
                  mods = mods,
                  selectedMapId = selectedMapId,
                  selectedBusId = selectedBusId,
                  selectedRepaint = selectedRepaint,
                  onPickFolder = onPickFolder,
                  onSelectMap = onSelectMap,
                  onSelectBus = onSelectBus,
                  onSelectRepaint = onSelectRepaint,
                  onToggleFavoriteBus = onToggleFavoriteBus,
                  onSetModEnabled = onSetModEnabled,
                )

              LauncherTab.OPTIMIZE ->
                OptimizerScreen(
                  config = optimizationConfig,
                  telemetry = telemetry,
                  installStatus = installStatus,
                  patchResult = patchResult,
                  onSelectProfile = onSelectProfile,
                  onUpdateConfig = onUpdateOptimization,
                  onApplyToOptionsCfg = onApplyOptionsCfg,
                  onRestoreBackup = onRestoreBackup,
                )

              LauncherTab.CONTROLS ->
                ControlsStudioScreen(
                  config = mobileControlConfig,
                  onUpdateConfig = onUpdateControls,
                )

              LauncherTab.SYSTEM -> SystemMonitorScreen(telemetry = telemetry)
            }
          }
        }
      }
    }
  }
}
