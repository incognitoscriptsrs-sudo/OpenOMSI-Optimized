package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider

private val OmsiDarkColorScheme =
  darkColorScheme(
    primary = ElectricCyan,
    onPrimary = ObsidianBg,
    primaryContainer = CyanDim,
    onPrimaryContainer = ElectricCyan,
    secondary = TransitAmber,
    onSecondary = ObsidianBg,
    secondaryContainer = AmberDim,
    onSecondaryContainer = TransitAmber,
    tertiary = TelemetryGreen,
    onTertiary = ObsidianBg,
    background = ObsidianBg,
    onBackground = CrispText,
    surface = CarbonSurface,
    onSurface = CrispText,
    surfaceVariant = ElevatedCarbon,
    onSurfaceVariant = MutedSlate,
    outline = CrispBorder,
    outlineVariant = CrispBorder,
    error = AlertCrimson,
    onError = CrispText,
    errorContainer = CrimsonDim,
    onErrorContainer = AlertCrimson,
  )

@Composable
fun Omsi64Theme(content: @Composable () -> Unit) {
  CompositionLocalProvider(LocalOmsiColors provides OmsiExtendedColors()) {
    MaterialTheme(
      colorScheme = OmsiDarkColorScheme,
      typography = Typography,
      content = content,
    )
  }
}

object OmsiTheme {
  val extended: OmsiExtendedColors
    @Composable get() = LocalOmsiColors.current
}
