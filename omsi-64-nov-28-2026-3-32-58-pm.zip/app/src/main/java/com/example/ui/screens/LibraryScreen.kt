package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.DirectionsBus
import androidx.compose.material.icons.filled.Extension
import androidx.compose.material.icons.filled.FolderOpen
import androidx.compose.material.icons.filled.Map
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.outlined.StarBorder
import androidx.compose.material3.Button
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.data.local.OmsiBusEntity
import com.example.data.local.OmsiMapEntity
import com.example.data.local.OmsiModEntity
import com.example.domain.model.OmsiInstallStatus
import com.example.ui.components.GamingPanel
import com.example.ui.components.SectionHeader
import com.example.ui.components.StatusPill
import com.example.ui.components.TelemetryStatCell
import com.example.ui.theme.OmsiTheme

private enum class LibraryFilter(val label: String) {
  MAPS("Maps"),
  BUSES("Vehicles"),
  MODS("Scenery & Mods"),
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun LibraryScreen(
  installStatus: OmsiInstallStatus,
  maps: List<OmsiMapEntity>,
  buses: List<OmsiBusEntity>,
  mods: List<OmsiModEntity>,
  selectedMapId: String?,
  selectedBusId: String?,
  selectedRepaint: String?,
  onPickFolder: () -> Unit,
  onSelectMap: (String) -> Unit,
  onSelectBus: (OmsiBusEntity) -> Unit,
  onSelectRepaint: (String) -> Unit,
  onToggleFavoriteBus: (OmsiBusEntity) -> Unit,
  onSetModEnabled: (OmsiModEntity, Boolean) -> Unit,
) {
  if (installStatus !is OmsiInstallStatus.Verified) {
    Column(
      modifier = Modifier.fillMaxSize().padding(24.dp),
      horizontalAlignment = Alignment.CenterHorizontally,
      verticalArrangement = Arrangement.Center,
    ) {
      Icon(
        imageVector = Icons.Default.FolderOpen,
        contentDescription = null,
        tint = MaterialTheme.colorScheme.primary,
        modifier = Modifier.size(44.dp),
      )
      Spacer(modifier = Modifier.height(10.dp))
      Text(
        text = "No Verified OMSI 2 Directory",
        style = MaterialTheme.typography.titleLarge,
        color = MaterialTheme.colorScheme.onBackground,
      )
      Spacer(modifier = Modifier.height(6.dp))
      Text(
        text = "Select your PC OMSI 2 folder to browse real Maps, Vehicles, Sceneryobjects, and Splines.",
        style = MaterialTheme.typography.bodyMedium,
        color = OmsiTheme.extended.mutedText,
      )
      Spacer(modifier = Modifier.height(16.dp))
      Button(
        onClick = onPickFolder,
        modifier = Modifier.minimumInteractiveComponentSize().testTag("library_pick_folder_button"),
      ) {
        Text("Select OMSI 2 Folder")
      }
    }
    return
  }

  var activeFilter by remember { mutableStateOf(LibraryFilter.MAPS) }
  var searchQuery by remember { mutableStateOf("") }

  Row(
    modifier = Modifier.fillMaxSize().padding(16.dp),
    horizontalArrangement = Arrangement.spacedBy(16.dp),
  ) {
    // Left Master List (56%)
    Column(
      modifier = Modifier.weight(0.56f).fillMaxHeight(),
      verticalArrangement = Arrangement.spacedBy(10.dp),
    ) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        verticalAlignment = Alignment.CenterVertically,
      ) {
        LibraryFilter.entries.forEach { tab ->
          val count =
            when (tab) {
              LibraryFilter.MAPS -> maps.size
              LibraryFilter.BUSES -> buses.size
              LibraryFilter.MODS -> mods.size
            }
          FilterChip(
            selected = activeFilter == tab,
            onClick = { activeFilter = tab },
            label = { Text("${tab.label} ($count)") },
            modifier = Modifier.minimumInteractiveComponentSize().testTag("library_filter_${tab.name.lowercase()}"),
            colors =
              FilterChipDefaults.filterChipColors(
                selectedContainerColor = MaterialTheme.colorScheme.primaryContainer,
                selectedLabelColor = MaterialTheme.colorScheme.primary,
              ),
          )
        }
      }

      OutlinedTextField(
        value = searchQuery,
        onValueChange = { searchQuery = it },
        singleLine = true,
        leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
        placeholder = { Text("Filter ${activeFilter.label.lowercase()}…") },
        modifier = Modifier.fillMaxWidth().testTag("library_search_input"),
      )

      when (activeFilter) {
        LibraryFilter.MAPS -> {
          val filtered =
            maps.filter {
              searchQuery.isBlank() ||
                it.friendlyName.contains(searchQuery, true) ||
                it.folderName.contains(searchQuery, true)
            }
          LazyColumn(
            modifier = Modifier.weight(1f),
            verticalArrangement = Arrangement.spacedBy(8.dp),
          ) {
            items(filtered, key = { it.id }) { map ->
              val selected = map.id == selectedMapId
              Surface(
                onClick = { onSelectMap(map.id) },
                modifier = Modifier.fillMaxWidth().testTag("map_card_${map.id}"),
                shape = RoundedCornerShape(10.dp),
                color =
                  if (selected) MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.35f)
                  else MaterialTheme.colorScheme.surface,
                border =
                  BorderStroke(
                    1.dp,
                    if (selected) MaterialTheme.colorScheme.primary else OmsiTheme.extended.border,
                  ),
              ) {
                Row(
                  modifier = Modifier.padding(12.dp),
                  horizontalArrangement = Arrangement.SpaceBetween,
                  verticalAlignment = Alignment.CenterVertically,
                ) {
                  Row(
                    modifier = Modifier.weight(1f),
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                    verticalAlignment = Alignment.CenterVertically,
                  ) {
                    Icon(
                      imageVector = Icons.Default.Map,
                      contentDescription = null,
                      tint =
                        if (selected) MaterialTheme.colorScheme.primary
                        else OmsiTheme.extended.mutedText,
                    )
                    Column {
                      Text(
                        text = map.friendlyName,
                        style = MaterialTheme.typography.titleMedium,
                        color = MaterialTheme.colorScheme.onSurface,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                      )
                      Text(
                        text = "Maps/${map.folderName} • ${map.tileCount} tiles",
                        style = MaterialTheme.typography.labelSmall,
                        color = OmsiTheme.extended.mutedText,
                      )
                    }
                  }
                  if (map.missingDependenciesCount > 0) {
                    StatusPill(
                      text = "${map.missingDependenciesCount} missing",
                      dotColor = MaterialTheme.colorScheme.secondary,
                      containerColor = OmsiTheme.extended.transitAmberContainer,
                      textColor = MaterialTheme.colorScheme.secondary,
                    )
                  } else {
                    StatusPill(
                      text = "OK",
                      dotColor = OmsiTheme.extended.verifiedGreen,
                      containerColor = OmsiTheme.extended.verifiedGreenContainer,
                      textColor = OmsiTheme.extended.verifiedGreen,
                    )
                  }
                }
              }
            }
          }
        }

        LibraryFilter.BUSES -> {
          val filtered =
            buses.filter {
              searchQuery.isBlank() ||
                it.friendlyName.contains(searchQuery, true) ||
                it.busFileName.contains(searchQuery, true) ||
                it.folderName.contains(searchQuery, true)
            }
          LazyColumn(
            modifier = Modifier.weight(1f),
            verticalArrangement = Arrangement.spacedBy(8.dp),
          ) {
            items(filtered, key = { it.id }) { bus ->
              val selected = bus.id == selectedBusId
              Surface(
                onClick = { onSelectBus(bus) },
                modifier = Modifier.fillMaxWidth().testTag("bus_card_${bus.id}"),
                shape = RoundedCornerShape(10.dp),
                color =
                  if (selected) MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.35f)
                  else MaterialTheme.colorScheme.surface,
                border =
                  BorderStroke(
                    1.dp,
                    if (selected) MaterialTheme.colorScheme.primary else OmsiTheme.extended.border,
                  ),
              ) {
                Row(
                  modifier = Modifier.padding(12.dp),
                  horizontalArrangement = Arrangement.SpaceBetween,
                  verticalAlignment = Alignment.CenterVertically,
                ) {
                  Row(
                    modifier = Modifier.weight(1f),
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                    verticalAlignment = Alignment.CenterVertically,
                  ) {
                    Icon(
                      imageVector = Icons.Default.DirectionsBus,
                      contentDescription = null,
                      tint =
                        if (selected) MaterialTheme.colorScheme.primary
                        else OmsiTheme.extended.mutedText,
                    )
                    Column {
                      Text(
                        text = bus.friendlyName,
                        style = MaterialTheme.typography.titleMedium,
                        color = MaterialTheme.colorScheme.onSurface,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                      )
                      Text(
                        text = "${bus.folderName}/${bus.busFileName} • ${bus.repaintCount} liveries",
                        style = MaterialTheme.typography.labelSmall,
                        color = OmsiTheme.extended.mutedText,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                      )
                    }
                  }
                  IconButton(
                    onClick = { onToggleFavoriteBus(bus) },
                    modifier =
                      Modifier.minimumInteractiveComponentSize().testTag("fav_bus_${bus.id}"),
                  ) {
                    Icon(
                      imageVector =
                        if (bus.isFavorite) Icons.Filled.Star else Icons.Outlined.StarBorder,
                      contentDescription = "Favorite bus",
                      tint =
                        if (bus.isFavorite) MaterialTheme.colorScheme.secondary
                        else OmsiTheme.extended.mutedText,
                    )
                  }
                }
              }
            }
          }
        }

        LibraryFilter.MODS -> {
          val filtered =
            mods.filter {
              searchQuery.isBlank() ||
                it.name.contains(searchQuery, true) ||
                it.category.contains(searchQuery, true)
            }
          LazyColumn(
            modifier = Modifier.weight(1f),
            verticalArrangement = Arrangement.spacedBy(8.dp),
          ) {
            items(filtered, key = { it.id }) { mod ->
              Surface(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(10.dp),
                color = MaterialTheme.colorScheme.surface,
                border = BorderStroke(1.dp, OmsiTheme.extended.border),
              ) {
                Row(
                  modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                  horizontalArrangement = Arrangement.SpaceBetween,
                  verticalAlignment = Alignment.CenterVertically,
                ) {
                  Row(
                    modifier = Modifier.weight(1f),
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                    verticalAlignment = Alignment.CenterVertically,
                  ) {
                    Icon(
                      imageVector = Icons.Default.Extension,
                      contentDescription = null,
                      tint = MaterialTheme.colorScheme.secondary,
                    )
                    Column {
                      Text(
                        text = mod.name,
                        style = MaterialTheme.typography.titleMedium,
                        color = MaterialTheme.colorScheme.onSurface,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                      )
                      Text(
                        text = "${mod.category} • ${mod.relativePath}",
                        style = MaterialTheme.typography.labelSmall,
                        color = OmsiTheme.extended.mutedText,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                      )
                    }
                  }
                  Switch(
                    checked = mod.enabled,
                    onCheckedChange = { onSetModEnabled(mod, it) },
                    modifier = Modifier.testTag("mod_toggle_${mod.id}"),
                  )
                }
              }
            }
          }
        }
      }
    }

    // Right Detail & Dependency Inspector Pane (44%)
    GamingPanel(modifier = Modifier.weight(0.44f).fillMaxHeight()) {
      Column(modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
        val currentMap = maps.firstOrNull { it.id == selectedMapId }
        val currentBus = buses.firstOrNull { it.id == selectedBusId }

        if (activeFilter == LibraryFilter.MAPS && currentMap != null) {
          SectionHeader(
            title = currentMap.friendlyName,
            subtitle = "Maps/${currentMap.folderName}/global.cfg",
          )
          Spacer(modifier = Modifier.height(12.dp))
          Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            TelemetryStatCell(
              label = "Tiles",
              value = "${currentMap.tileCount}",
              modifier = Modifier.weight(1f),
            )
            TelemetryStatCell(
              label = "Asset Refs",
              value = "${currentMap.referencedSceneryCount}",
              modifier = Modifier.weight(1f),
            )
            TelemetryStatCell(
              label = "Missing",
              value = "${currentMap.missingDependenciesCount}",
              accentColor =
                if (currentMap.missingDependenciesCount > 0) MaterialTheme.colorScheme.secondary
                else OmsiTheme.extended.verifiedGreen,
              modifier = Modifier.weight(1f),
            )
          }
          Spacer(modifier = Modifier.height(12.dp))
          Text(
            text = currentMap.description,
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurface,
          )
          if (currentMap.missingDependenciesCount > 0) {
            Spacer(modifier = Modifier.height(12.dp))
            Text(
              text = "MISSING SCENERY / SPLINE PACKS",
              style = MaterialTheme.typography.labelMedium,
              color = MaterialTheme.colorScheme.secondary,
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
              text = currentMap.missingDependenciesPreview,
              style = MaterialTheme.typography.labelSmall,
              color = OmsiTheme.extended.mutedText,
            )
          }
        } else if (currentBus != null) {
          SectionHeader(
            title = currentBus.friendlyName,
            subtitle = "Vehicles/${currentBus.folderName}/${currentBus.busFileName}",
          )
          Spacer(modifier = Modifier.height(12.dp))
          Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            TelemetryStatCell(
              label = "Model CFG",
              value = if (currentBus.hasModelCfg) "Verified" else "Missing",
              accentColor =
                if (currentBus.hasModelCfg) OmsiTheme.extended.verifiedGreen
                else OmsiTheme.extended.alertCrimson,
              modifier = Modifier.weight(1f),
            )
            TelemetryStatCell(
              label = "Sound CFG",
              value = if (currentBus.hasSoundCfg) "Verified" else "Check",
              modifier = Modifier.weight(1f),
            )
          }
          Spacer(modifier = Modifier.height(12.dp))
          Text(
            text = currentBus.description,
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurface,
          )
          val repaints = currentBus.repaintsCsv.split("|").filter { it.isNotBlank() }
          if (repaints.isNotEmpty()) {
            Spacer(modifier = Modifier.height(14.dp))
            Text(
              text = "LIVERY / REPAINT",
              style = MaterialTheme.typography.labelMedium,
              color = MaterialTheme.colorScheme.primary,
            )
            Spacer(modifier = Modifier.height(6.dp))
            FlowRow(
              horizontalArrangement = Arrangement.spacedBy(8.dp),
              verticalArrangement = Arrangement.spacedBy(8.dp),
            ) {
              repaints.forEach { repaint ->
                FilterChip(
                  selected = selectedRepaint == repaint,
                  onClick = { onSelectRepaint(repaint) },
                  label = { Text(repaint) },
                  modifier = Modifier.testTag("repaint_chip_$repaint"),
                )
              }
            }
          }
        } else {
          SectionHeader(
            title = "Asset Inspector",
            subtitle = "Select any Map or Vehicle to inspect dependencies and repaints.",
          )
        }
      }
    }
  }
}
