package com.example.domain.model

enum class LauncherTab {
  PLAY,
  LIBRARY,
  OPTIMIZE,
  CONTROLS,
  SYSTEM,
}

data class OmsiChecklistItem(
  val label: String,
  val expectedRelativePath: String,
  val required: Boolean,
  val present: Boolean,
  val detail: String,
)

sealed interface OmsiInstallStatus {
  data object Unconfigured : OmsiInstallStatus

  data class Scanning(val stage: String, val progress: Float) : OmsiInstallStatus

  data class Verified(
    val treeUriString: String,
    val displayFolderName: String,
    val exeSizeMb: Float,
    val mapCount: Int,
    val busCount: Int,
    val sceneryCount: Int,
    val splineCount: Int,
    val hasOptionsCfg: Boolean,
    val checklist: List<OmsiChecklistItem>,
    val lastScannedAt: Long,
  ) : OmsiInstallStatus

  data class Invalid(
    val treeUriString: String,
    val displayFolderName: String,
    val missingRequired: List<String>,
    val checklist: List<OmsiChecklistItem>,
  ) : OmsiInstallStatus
}

enum class GpuBackend(val displayName: String, val configValue: String, val note: String) {
  VULKAN_TURNIP(
    displayName = "Vulkan 1.1 + Turnip Adreno",
    configValue = "vulkan_turnip",
    note = "Low-overhead Adreno command buffers & zero shader stutter",
  ),
  GLES_32(
    displayName = "OpenGL ES 3.2 Hardware Direct",
    configValue = "gles32_direct",
    note = "Maximum compatibility with stock Snapdragon Qualcomm drivers",
  ),
  DXVK_ASYNC(
    displayName = "DXVK Async Pipeline Cache",
    configValue = "dxvk_async",
    note = "Pre-compiled async shader pipeline for dense urban intersections",
  ),
}

enum class SnapdragonProfile(
  val title: String,
  val subtitle: String,
  val memoryPoolMb: Int,
  val textureCapMb: Int,
  val tileLoadRadius: Int,
  val aiTraffic: Int,
  val aiPedestrians: Int,
  val gpuBackend: GpuBackend,
) {
  ADRENO_MAX_PERF(
    title = "Adreno Max 64-Bit",
    subtitle = "6 GB heap pool • 3-tile preload • Turnip/Vulkan",
    memoryPoolMb = 6144,
    textureCapMb = 2048,
    tileLoadRadius = 3,
    aiTraffic = 65,
    aiPedestrians = 50,
    gpuBackend = GpuBackend.VULKAN_TURNIP,
  ),
  BALANCED_60FPS(
    title = "Snapdragon 60 FPS Lock",
    subtitle = "4 GB heap pool • 2-tile stream • Zero lag spikes",
    memoryPoolMb = 4096,
    textureCapMb = 1536,
    tileLoadRadius = 2,
    aiTraffic = 45,
    aiPedestrians = 35,
    gpuBackend = GpuBackend.GLES_32,
  ),
  THERMAL_SAFE(
    title = "Thermal & Battery Guard",
    subtitle = "3 GB heap pool • 1-tile load • Cool sustained clocks",
    memoryPoolMb = 3072,
    textureCapMb = 1024,
    tileLoadRadius = 1,
    aiTraffic = 25,
    aiPedestrians = 20,
    gpuBackend = GpuBackend.GLES_32,
  ),
  CUSTOM(
    title = "Custom Tuning",
    subtitle = "Manual memory, tile radius & GPU pipeline",
    memoryPoolMb = 4096,
    textureCapMb = 1536,
    tileLoadRadius = 2,
    aiTraffic = 50,
    aiPedestrians = 40,
    gpuBackend = GpuBackend.VULKAN_TURNIP,
  ),
}

enum class SteeringMode(val label: String, val description: String) {
  VIRTUAL_WHEEL("Virtual Wheel", "Multi-turn touch steering wheel with auto-return"),
  TOUCH_SLIDER("Precision Slider", "Low-latency horizontal thumb rail"),
  GYROSCOPE_TILT("Gyroscope Tilt", "Hardware IMU steering with deadzone calibration"),
}

data class OptimizationConfig(
  val activeProfile: SnapdragonProfile = SnapdragonProfile.BALANCED_60FPS,
  val unlock64BitHeap: Boolean = true,
  val memoryPoolMb: Int = 4096,
  val textureCapMb: Int = 1536,
  val tileLoadRadius: Int = 2,
  val workerThreads: Int = 6,
  val gpuBackend: GpuBackend = GpuBackend.VULKAN_TURNIP,
  val dxvkAsyncShaders: Boolean = true,
  val turnipLowLatency: Boolean = true,
  val anisotropicLevel: Int = 4,
  val aiTrafficDensity: Int = 45,
  val aiPedestrianDensity: Int = 35,
  val targetFps: Int = 60,
  val reduceTileStutter: Boolean = true,
)

data class MobileControlConfig(
  val throttleExponent: Float = 1.65f,
  val throttleDeadzone: Float = 0.05f,
  val throttleHoldRampRate: Float = 0.85f,
  val brakeExponent: Float = 1.45f,
  val brakeDeadzone: Float = 0.04f,
  val steeringMode: SteeringMode = SteeringMode.TOUCH_SLIDER,
  val steeringSensitivity: Float = 1.15f,
  val gyroDeadzoneDegrees: Float = 2.5f,
  val autoCenterSteering: Boolean = true,
  val progressiveHaptics: Boolean = true,
)

data class ExternalRuntimeInfo(
  val packageName: String,
  val label: String,
  val installed: Boolean,
)

data class DeviceTelemetrySnapshot(
  val abiList: List<String> = emptyList(),
  val isArm64: Boolean = false,
  val socModel: String = "Probing...",
  val deviceModel: String = "",
  val hardwareName: String = "",
  val gpuRenderer: String = "Probing GPU...",
  val gpuVendor: String = "",
  val glVersion: String = "",
  val vulkanSupported: Boolean = false,
  val vulkanVersionLabel: String = "Unavailable",
  val cpuCores: Int = 0,
  val cpuCoreFreqsMhz: List<Int> = emptyList(),
  val totalRamMb: Long = 0L,
  val availableRamMb: Long = 0L,
  val appNativeHeapMb: Long = 0L,
  val appJvmMaxMb: Long = 0L,
  val thermalStatusCode: Int = 0,
  val thermalLabel: String = "Nominal",
  val batteryTempCelsius: Float = 0f,
  val externalRuntimes: List<ExternalRuntimeInfo> = emptyList(),
)

data class OptionsPatchResult(
  val success: Boolean,
  val message: String,
  val backupCreated: Boolean = false,
  val appliedKeysCount: Int = 0,
)
