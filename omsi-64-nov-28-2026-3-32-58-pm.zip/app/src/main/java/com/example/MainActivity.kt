package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.runtime.getValue
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.ui.cockpit.OmsiGlCockpitScreen
import com.example.ui.screens.LauncherRootScreen
import com.example.ui.theme.Omsi64Theme
import com.example.ui.viewmodel.LauncherViewModel

class MainActivity : ComponentActivity() {

  private val viewModel: LauncherViewModel by viewModels()

  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    enableEdgeToEdge()

    setContent {
      Omsi64Theme {
        val activeTab by viewModel.activeTab.collectAsStateWithLifecycle()
        val installStatus by viewModel.installStatus.collectAsStateWithLifecycle()
        val maps by viewModel.maps.collectAsStateWithLifecycle()
        val buses by viewModel.buses.collectAsStateWithLifecycle()
        val mods by viewModel.mods.collectAsStateWithLifecycle()
        val selectedMapId by viewModel.selectedMapId.collectAsStateWithLifecycle()
        val selectedBusId by viewModel.selectedBusId.collectAsStateWithLifecycle()
        val selectedRepaint by viewModel.selectedRepaint.collectAsStateWithLifecycle()
        val optimizationConfig by viewModel.optimizationConfig.collectAsStateWithLifecycle()
        val mobileControlConfig by viewModel.mobileControlConfig.collectAsStateWithLifecycle()
        val telemetry by viewModel.telemetry.collectAsStateWithLifecycle()
        val patchResult by viewModel.patchResult.collectAsStateWithLifecycle()
        val isCockpitActive by viewModel.isCockpitActive.collectAsStateWithLifecycle()

        val folderPickerLauncher =
          rememberLauncherForActivityResult(
            contract = ActivityResultContracts.OpenDocumentTree(),
            onResult = { uri ->
              if (uri != null) {
                viewModel.onDirectorySelected(uri)
              }
            },
          )

        if (isCockpitActive) {
          val currentMap = maps.firstOrNull { it.id == selectedMapId }
          val currentBus = buses.firstOrNull { it.id == selectedBusId }
          OmsiGlCockpitScreen(
            selectedMap = currentMap,
            selectedBus = currentBus,
            selectedRepaint = selectedRepaint,
            optimizationConfig = optimizationConfig,
            controlConfig = mobileControlConfig,
            telemetry = telemetry,
            onExit = viewModel::exitCockpitSession,
          )
        } else {
          LauncherRootScreen(
            activeTab = activeTab,
            installStatus = installStatus,
            maps = maps,
            buses = buses,
            mods = mods,
            selectedMapId = selectedMapId,
            selectedBusId = selectedBusId,
            selectedRepaint = selectedRepaint,
            optimizationConfig = optimizationConfig,
            mobileControlConfig = mobileControlConfig,
            telemetry = telemetry,
            patchResult = patchResult,
            onSelectTab = viewModel::selectTab,
            onPickFolder = { folderPickerLauncher.launch(null) },
            onRescan = viewModel::rescanDirectory,
            onUnlinkFolder = viewModel::unlinkDirectory,
            onSelectMap = viewModel::selectMap,
            onSelectBus = viewModel::selectBus,
            onSelectRepaint = viewModel::selectRepaint,
            onToggleFavoriteBus = viewModel::toggleBusFavorite,
            onSetModEnabled = viewModel::setModEnabled,
            onSelectProfile = viewModel::applySnapdragonProfile,
            onUpdateOptimization = viewModel::updateOptimizationConfig,
            onApplyOptionsCfg = viewModel::applyConfigToOmsiFiles,
            onRestoreBackup = viewModel::restoreOptionsBackup,
            onUpdateControls = viewModel::updateMobileControlConfig,
            onLaunch64Bit = viewModel::launch64BitSession,
            onLaunchExternalRuntime = viewModel::launchExternalRuntime,
          )
        }
      }
    }
  }
}
