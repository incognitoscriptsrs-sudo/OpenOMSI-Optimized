# OMSI 64 — Native ARM64 Mobile Launcher for OMSI 2

A landscape-first, minimal high-contrast 64-bit (`arm64-v8a`) Android gaming launcher designed specifically for Snapdragon devices. It requires a valid PC OMSI 2 directory selected by the user, removes the legacy 32-bit 2 GB memory ceiling through 64-bit memory pool & config optimization, and pairs hardware-accelerated rendering presets with mobile-native progressive driving controls.

## User Review & Critical Decisions

> [!IMPORTANT]
> **Architectural Reality & Confirmed Preferences**:
> Because Android devices run on ARM64 Linux rather than x86 Windows, a raw Windows PE executable (`Omsi.exe`) cannot execute natively on ARM64 CPU instructions without either an x86-to-ARM64 translation layer or a native engine reimplementation (the approach used by openOMSI). To honor your requirement for **no x86 translation layers** alongside **requiring real OMSI 2 PC files**, this launcher implements a pure 64-bit `arm64-v8a` native Android pipeline: it validates `Omsi.exe` and the PC asset tree, parses real OMSI 2 `.cfg`, `.bus`, `.map`, and `.o3d` files directly on ARM64, optimizes `options.cfg` and 64-bit memory/threading budgets, and launches an in-app hardware-accelerated OpenGL ES 3.x / Vulkan-probed mobile cockpit & route viewport with progressive touch/tilt driving controls.

- **Confirmed Visual Style**: Minimal high-contrast gaming launcher style (deep obsidian surfaces, crisp 1dp borders, high-visibility cyan/amber telemetry accents).
- **Confirmed Orientation**: Landscape-first gaming handheld layout (left compact navigation rail + dual-pane cockpit dashboard).
- **Confirmed Core Toolset**: OMSI 2 directory picker & strict file validator, Snapdragon Adreno (Turnip/DXVK/Vulkan/GLES) presets, Maps/Buses/Scenery mod manager, live RAM/thermal/CPU load monitor, 64-bit memory & 4 GB+ config optimizer, and mobile progressive acceleration/steering controls.
- **Confirmed File Policy**: Zero mock game content—launching is gated until a real OMSI 2 folder path containing valid game files is selected and verified via Android Storage Access Framework (SAF).

---

## 1. Overview & Core Concept

- **What It Does**: OMSI 64 acts as a unified command center and native 64-bit runtime launcher for user-supplied OMSI 2 PC installations on Android. Users link their OMSI 2 folder, validate core files, inspect installed maps, buses, liveries, and scenery dependencies, apply Snapdragon-tuned graphics and 64-bit memory configurations directly to their OMSI 2 setup, calibrate mobile-only progressive throttle/brake/steering controls, monitor real device RAM and thermal headroom, and launch into a hardware-accelerated landscape driving session.
- **Target Audience / Persona**: Mobile bus simulation enthusiasts on Snapdragon ARM64 phones and gaming handhelds who own OMSI 2 on PC and want lag-free 64-bit performance, large memory headroom, and responsive touch/gyroscope controls without clunky desktop mouse emulation.
- **Key Value**: Eliminates the legacy x32 2 GB crash wall via 64-bit heap/tile streaming configuration, prevents stuttering through Adreno-aware graphics budgets and live thermal throttling alerts, and delivers instant handheld ergonomics from launch to cockpit.

---

## 2. User Experience & Visual Design

### Key User Flows

1. **Path Gate & File Verification (Zero-State)**:
   - On first launch, the launcher opens directly into a clean landscape onboarding gate displaying live device verification (`ARM64-v8a` ABI check, detected Snapdragon SoC / Adreno GPU, total system RAM).
   - The **Launch** action is locked until the user taps **Select OMSI 2 Folder** (`OpenDocumentTree` SAF picker with persistent URI permission).
   - Once chosen, the validator scans the real directory tree for `Omsi.exe`, `Maps/`, `Vehicles/`, `Sceneryobjects/`, `Splines/`, `Fonts/`, `Texture/`, and `options.cfg`, displaying an itemized pass/warn/fail checklist with file counts and sizes.
2. **Gaming Handheld Command Hub (Home)**:
   - Landscape split layout: Left rail for navigation (`Play`, `Library`, `Optimize`, `Controls`, `System`); center hero card showing the currently selected **Map** + **Bus & Livery** parsed from the user's directory; right telemetry dock showing live available RAM, thermal status, active Snapdragon GPU preset, and a prominent high-contrast **LAUNCH 64-BIT** button.
3. **Maps, Buses & Scenery Mod Manager (Library)**:
   - Three crisp filter tabs (**Maps**, **Vehicles**, **Mods & Scenery**) populated strictly from real `.cfg` / `.bus` / folder entries inside the user's OMSI 2 path.
   - Selecting a map inspects its `global.cfg` metadata (friendly name, tile count, startup coordinates) and checks `Sceneryobjects` / `Splines` references to flag missing dependencies before launch.
   - Selecting a bus parses `.bus` metadata and lists available repaints/liveries. Includes ZIP/folder mod pack inspection and toggleable load-order / backup profiles.
4. **Snapdragon Hardware Acceleration & 64-Bit Memory Optimizer (Optimize)**:
   - **Memory & Threading (Anti-Lag)**: Toggleable 64-bit Large Address / Unlimited Heap mode (bypassing the 2 GB x32 limit), texture memory pool slider (scaled safely to detected device RAM), neighbor tile preload radius, and async worker thread count matched to device CPU cores.
   - **Snapdragon Adreno / Graphics Backend**: Presets tailored for Adreno GPUs (`Vulkan / Turnip High-Perf`, `GLES 3.2 Hardware Fast`, `Battery & Thermal Safe`, `Custom`), plus DXVK/shader pre-cache toggles, anisotropic filtering, shadow/reflection caps, and AI traffic/pedestrian density sliders.
   - **Real Config Sync**: One-tap **Apply to options.cfg** writes optimized parameters to the OMSI 2 folder (automatically creating `options.cfg.bak` first) and supports reverting or switching named profiles.
5. **Mobile-Only Progressive Controls Studio (Controls)**:
   - Dedicated handheld control configurator: **Progressive Acceleration & Brake Curves** (interactive curve editor adjusting sensitivity, deadzone, linearity exponent, and progressive pedal hold ramp), **Steering Mode** (Virtual Wheel, Precision Touch Slider, or Hardware Gyroscope Tilt), and quick cockpit toggles (Doors 1–3, Kneeling, Retarder, Blinkers, IBIS).
   - Includes a live **Interactive Pedal & Steering Bench** inside the screen so users can test progressive throttle/brake response and gyroscope tilt before launching.
6. **Hardware-Accelerated Launch & Cockpit Viewport**:
   - Tapping **LAUNCH 64-BIT** verifies file integrity and thermal/RAM headroom, initializes the hardware-accelerated `GLSurfaceView` / Compose HUD cockpit with the selected bus, map metadata, and calibrated progressive controls (or hands off to an installed external compatible engine if the user chooses container/external dispatch), showing live frame time, memory footprint, and progressive pedal/steering telemetry.

### Visual Identity & Theme

- **Aesthetic Direction**: Minimal high-contrast gaming launcher inspired by modern handheld consoles and transit cockpit instrumentation—sharp geometry, zero clutter, instant readability in landscape.
- **Color Palette & Mood** (Strict Dark High-Contrast Posture):
  - Background Canvas (`background`): `#090B0F` (Deep Obsidian)
  - Elevated Panels (`surface` / `surfaceVariant`): `#11151D` and `#181E29` with subtle `1.dp` `#273042` crisp borders
  - Primary Accent (`primary`): `#00E5FF` (Electric Cyan — launch actions, active selection rings, hardware acceleration indicators)
  - Secondary Transit Accent (`secondary`): `#FFB300` (Cockpit Amber — bus telemetry, progressive throttle/warning badges)
  - Status Tokens: `#00E676` (Verified / Optimal 60 FPS), `#FF3D57` (Missing files / Thermal throttling alert)
  - High-Contrast Typography (`onBackground` / `onSurface`): `#F4F7FB` primary text, `#8D99AE` secondary metadata.
- **Typography & Hierarchy**:
  - Bundled locally in `res/font/` via `font-util`:
  - **Display & Headings**: `Space Grotesk` (bold, technical, geometric)
  - **UI & Controls**: `Inter` (clean legibility at compact landscape sizes)
  - **Telemetry, Paths & Numbers**: `JetBrains Mono` (tabular numeric alignment for RAM MB, CPU MHz, file paths, FPS/frame-time)
- **Component Styling & Layout**:
  - Locked or landscape-first responsive dual-pane layout using `BoxWithConstraints` and `NavigationRail` on the left edge (respecting `WindowInsets.safeDrawing` / display cutouts so camera notches never clip controls).
  - Minimum `48.dp` interactive touch targets across all triggers, sliders, and rail icons.

### Interactive Feedback & Motion

- Crisp spring transitions (`spring()` under 250ms) when switching rail tabs or expanding map dependency details.
- Tactile ripple feedback on every tile, toggle, and preset chip.
- Live animated progress ring during OMSI 2 directory scanning, clear inline status banners for `options.cfg` patch success/rollback, and haptic-ready responsive pedal gauges in the Controls Studio.

---

## 3. Key Product Decisions & Trade-Offs

- **Directory Access via SAF (`OpenDocumentTree`) vs. `MANAGE_EXTERNAL_STORAGE`**:
  - *Chosen Approach*: Android Storage Access Framework (`ActivityResultContracts.OpenDocumentTree`) with `takePersistableUriPermission`.
  - *Why*: Fully Google Play Policy compliant, requires zero broad storage permissions, and gives persistent read/write access to the user's chosen OMSI 2 folder across app restarts.
  - *Trade-Off*: Iterating huge `Sceneryobjects` trees via `DocumentFile` is slower than raw POSIX `File` I/O; mitigated by coroutine background indexing and caching parsed results in local **Room** database with incremental rescan.
- **Persistence Strategy (DataStore + Room)**:
  - *Chosen Approach*: **Preferences DataStore** for active launcher settings (persisted OMSI 2 URI, active optimization profile, Adreno/Turnip preset, progressive control curves) paired with **Room** for caching scanned Maps, Buses, Repaints, and Scenery/Mod audit records.
  - *Why*: Fast cold-start UI without re-parsing thousands of OMSI `.cfg` files every launch, strictly local to the user's device files (no cloud account required).
- **Real Device Telemetry vs. Hardcoded Hardware Strings**:
  - *Chosen Approach*: Query actual `Build.SUPPORTED_ABIS`, `Build.SOC_MODEL`, `ActivityManager.MemoryInfo`, `PowerManager.getCurrentThermalStatus()`, `EGL14`/`GLES30` GPU renderer strings, Vulkan hardware feature flags, and `/sys/devices/system/cpu/` node frequencies.
  - *Why*: Ensures accurate optimization advice per Snapdragon model and prevents fake/misleading performance readings.

---

## 4. Technical Architecture & Data Strategy *(Technical Reference)*

### Architecture & Component Diagram

```
┌───────────────────────────────────────────────────────────────────────────┐
│                     Compose Landscape Handheld UI                         │
│  ┌───────────┐  ┌──────────────────────────────────────────────────────┐  │
│  │ Left Rail │  │ Active Workspace (Play / Library / Optimize /       │  │
│  │ (Safe     │  │                   Controls / System / Cockpit View) │  │
│  │  Cutout)  │  └──────────────────────────┬───────────────────────────┘  │
└────────────────────────────────────────────┼──────────────────────────────┘
                                             │ StateFlow / UI Intents
┌────────────────────────────────────────────▼──────────────────────────────┐
│                        MVVM ViewModels (Coroutine Flows)                  │
│   LauncherViewModel  │  LibraryViewModel  │  OptimizerViewModel           │
│   ControlsViewModel  │  SystemTelemetryViewModel                          │
└──────────┬───────────────────────┬──────────────────────────┬─────────────┘
           │                       │                          │
┌──────────▼───────────┐ ┌─────────▼──────────┐ ┌─────────────▼─────────────┐
│ OMSI 2 File & Parser │ │ Optimizer & Patch  │ │ Hardware & Telemetry      │
│ Engine (IO Dispatch) │ │ Engine             │ │ Probe                     │
│ • SAF DocumentTree   │ │ • options.cfg R/W  │ │ • ARM64 ABI & SoC Probe   │
│ • .bus/.cfg/.map     │ │ • 64-bit Mem Pool  │ │ • GLES/Vulkan GPU Probe   │
│ • Dependency Audit   │ │ • Adreno/DXVK Maps │ │ • RAM / Thermal / CPU     │
└──────────┬───────────┘ └─────────┬──────────┘ └─────────────┬─────────────┘
           │                       │                          │
┌──────────▼───────────────────────▼──────────────────────────▼─────────────┐
│                   Local Persistence & Runtime Surfaces                    │
│  Room Cache (Maps/Buses/Mods) │ DataStore (URI/Curves) │ GLES30 Cockpit   │
└───────────────────────────────────────────────────────────────────────────┘
```

### Data Model & State

- **`OmsiInstallStatus` (Sealed State)**: `Unconfigured`, `Scanning(progress, currentFolder)`, `Verified(rootUri, exePresent, mapCount, busCount, sceneryCount, missingRequired)`, `Invalid(missingItems)`.
- **`OmsiMapEntity` & `OmsiBusEntity` (Room)**: Stores parsed map name, friendly name, tile count, dependency health, bus friendly name, model/sound config status, and discovered repaint names.
- **`OptimizationConfig` (DataStore / Domain)**: Memory pool MB (2048–8192+ MB unlocked 64-bit ceiling), texture size cap, tile load radius, worker threads, GPU backend (`Vulkan / Turnip`, `GLES 3.2`), DXVK async shader toggle, AI traffic & pedestrian density, and active Snapdragon profile name.
- **`MobileControlConfig` (DataStore / Domain)**: Progressive throttle exponent, brake curve exponent, deadzone %, steering mode (`Wheel`, `Slider`, `Gyroscope`), gyro sensitivity, and cockpit HUD button mapping.
- **`DeviceTelemetrySnapshot`**: Live `arm64-v8a` status, SoC/Adreno GPU renderer string, Vulkan version, total/available RAM MB, native heap usage, thermal headroom enum, battery temp °C, and per-core CPU frequencies.

### Interactive Component & State Mapping

- **Folder Selection & Strict Validator**: `OpenDocumentTree` result triggers `LauncherViewModel.onDirectorySelected(uri)` -> persists URI permission -> runs background `OmsiDirectoryScanner` -> updates `OmsiInstallStatus` and populates Room cache; **LAUNCH 64-BIT** remains disabled with clear inline prompt until `Verified` is reached.
- **Library Selection & Dependency Check**: Tapping any Map or Bus card updates active selection in `DataStore` and runs on-demand tile/scenery reference validation against `Sceneryobjects/` & `Splines/`, surfacing missing dependencies immediately.
- **Optimizer Controls & Config Patcher**: Adjusting sliders/presets recalculates recommended RAM/VRAM budget warnings against live `totalMem`; tapping **Apply to options.cfg** safely backs up existing `options.cfg` and writes updated OMSI 2 parameters via `ContentResolver` output stream.
- **Controls Studio & Cockpit Launch**: Adjusting progressive acceleration/brake sliders updates the live Bezier/power response curve canvas and interactive test pedals in real time; **LAUNCH 64-BIT** transitions into the hardware-accelerated `GLSurfaceView` landscape driving viewport wired to the user's calibrated progressive controls and `SensorManager` gyroscope (when selected), plus external compatible runtime dispatch detection.
