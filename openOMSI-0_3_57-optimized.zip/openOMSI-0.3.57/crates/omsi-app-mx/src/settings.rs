//! The user's settings: graphics and gameplay switches, kept as `key=value` lines in
//! `~/.openomsi/settings.cfg` (the launcher writes the same file). Anything missing
//! keeps its default, so an old file never breaks a new build.

use std::path::PathBuf;

/// Version of the settings file (`version=`); files without it are version 1.
#[cfg(test)]
#[rustfmt::skip]
pub const SETTINGS_VERSION: u32 = 4;

#[derive(Debug, Clone, PartialEq)]
#[rustfmt::skip]
pub struct Settings {
    /// Samples per pixel: 1, 2, 4 or 8.
    pub msaa: u32,
    /// Anisotropic filtering 1..16.
    pub anisotropy: u16,
    pub ssao: bool,
    pub shadows: bool,
    pub shadow_size: u32,
    /// Draw the models' `[isshadow]` shadow meshes: OMSI's flat blob under a vehicle,
    /// standing in for the sky light the body keeps off the road. Off, only the sun shadow
    /// map shades under a vehicle (the blob is a fake OMSI draws whatever the depth).
    pub shadow_blobs: bool,
    /// Enhanced: the street lamps' and headlamps' shadow maps (`lamp_shadows`; on by default).
    pub lamp_shadows: bool,
    /// The route navigator in the lower right corner.
    pub navigator: bool,
    /// How much of the interface's backgrounds shows - the navigator's, the menu's, the
    /// timetable's, the notes' plates - 0.2 .. 1, the texts staying solid: 0.85 (the default)
    /// as designed (`ui::backdrop`). `navigator_opacity` in older files: it was the
    /// navigator's alone.
    pub ui_opacity: f32,
    /// The shared palette for all game UI: `dark` (default) or `light`.
    pub ui_theme: String,
    /// Which corner the navigator sits in: `bottom-left` (default), `bottom-right`,
    /// `top-left` or `top-right`.
    pub navigator_corner: String,
    /// How passengers board: `auto` - they pay at the cash desk and take the ticket
    /// themselves; `pay` - they wait at the desk for the driver to sell the ticket (the
    /// ticket key or the printer); `walk` - they just walk into the saloon (a flat-fare
    /// or ticket-machine service).
    pub boarding: String,
    /// The chance (0..1) a boarding passenger stands although a seat is free
    /// (`standing_chance`, in percent in the file).
    pub standing_chance: f32,
    /// Passenger poses: `original` (the OMSI animation, default) or `enhanced` (experimental IK).
    pub passenger_animation: String,
    /// Allow a rider to make a subsequent valid journey after alighting.
    pub passenger_connections: bool,
    /// Probability (0..100) for eligible onward transfers; inert when disabled.
    pub passenger_transfer_percent: f32,
    /// Opt-in passenger behavior; false preserves original OMSI semantics.
    pub passenger_hailing: bool,
    /// Independent opt-in full-bus visual reaction; off by default.
    pub passenger_full_bus_reaction: bool,
    pub pax_short_rides_stand: bool,
    /// The photo mode's panel: "simple" (a few settings, the look) or "advanced" (a camera's
    /// body: the exposure triangle, metering, white balance in kelvin, tilt-shift, ...).
    pub photo_mode: String,
    /// The people as drawn: `original` (the content's own, default) or `improved` (the
    /// Microsoft Rocketbox avatars with living faces, on this computer only).
    pub character_models: String,
    /// Procedural detail (fractal) texturing of the ground and large walls when close.
    pub detail_textures: bool,
    /// Passengers pay the exact fare (no change to give at the cash desk).
    pub exact_fare: bool,
    pub pax_bad_driving: bool,
    /// The stop's passengers walk to the bus only once it stands still with a door open
    /// (#2757); off, they set off as soon as it is listed and rolling in, as OMSI had it.
    pub pax_board_when_stopped: bool,
    /// At each stop of a depot file that keeps two recordings per stop, the game presses the
    /// IBIS's "next stop" key so that the arrival recording is heard as well (see
    /// `auto_announce`).
    pub auto_announce: bool,
    /// Enhanced graphics: the physically based renderer (its own lighting, sky, exposure).
    pub enhanced: bool,
    /// The graphics: `vanilla` (as OMSI 2 draws it: no sun shadows, no ambient occlusion,
    /// no detail grain, no snow cover or rain drops of our own), `vanilla_plus` (the same
    /// renderer with those extras, the default) or `enhanced` (`enhanced` follows it).
    pub graphics: String,
    /// Start a PC OpenXR headset session when the game starts (Windows only).
    pub vr: bool,
    /// Fraction of the OpenXR runtime's recommended eye resolution.
    pub vr_scale: f32,
    /// Optional VR head pose smoothing time in milliseconds; zero uses raw tracking.
    pub vr_head_smoothing_ms: f32,
    /// Total bus mirror redraws per second in VR; zero freezes them,
    /// and -1 redraws every mirror once per game frame.
    pub vr_mirror_rate: f32,
    /// Copy the left eye to the desktop while VR is active.
    pub vr_desktop_mirror: bool,
    pub triple: omsi_render::TripleScreen,
    pub triple_span: bool,
    pub triple_hud_center: bool,
    pub fullscreen: bool,
    pub vsync: bool,
    /// Master volume 0..1.
    pub volume: f32,
    /// Control preset: "simple", "wasd", "arrows" or "omsi".
    pub drive_keys: String,
    /// Mobile screen-door controls: standard physical grouping or direct OMSI script triggers.
    pub touch_door_mode: String,
    /// The screen pedals' length against their standard one (0.8 .. 1.6, #1458): a longer
    /// pedal gives a finger more travel for the same press.
    pub touch_pedal_length: f32,
    /// The share at the foot of a screen pedal where a resting finger presses nothing
    /// (0 .. 0.4): a thumb laid on the pedal is not yet a brake.
    pub touch_pedal_deadzone: f32,
    /// Anti-aliasing of the enhanced picture after tone mapping: `fxaa` (default) or `off`.
    pub post_aa: String,
    /// OMSI's maintenance condition (`[wear_lifespan]`): 0 infinite (no wear), 1 very bad,
    /// 2 bad, 3 normal, 4 good - the player's bus's `wearlifespan` 1.5e6, 0.01, 0.1, 1, 10
    ///; AI vehicles never wear.
    pub maintenance: u8,
    /// `[AIUnschedFactor]`: the share of the random traffic (percent of the map's density).
    pub ai_unsched_factor: f32,
    /// `ai_reaction`: the AI drivers' reaction time as a factor of the default (percent in the
    /// file, 25 to 200; below 100 a queue pulls away closer together).
    pub ai_reaction: f32,
    /// `[AIMaxCountScheduled]`: timetable vehicles on the road at once (0 = no limit).
    pub ai_max_scheduled: u32,
    /// `[AIMaxCountParked]`: parked cars placed in the loaded tiles (0 = every space, -1 =
    /// none at all).
    pub ai_max_parked: i32,
    /// `[AIMaxCountRandom]`'s second line: Omsi.exe makes this many people at the start and
    /// no more (0x709274, "Create Humans") - everybody waiting, walking and riding comes out
    /// of them, and at most half walk the pavements (0x62463c).
    pub ai_max_humans: u32,
    /// The parked buses of a server drawn at most, the nearest (`omsi_net::parked`): each
    /// costs what another player's bus does, and the server's owner chose their number.
    /// -1 (the default): as many as the machine's textures have room for
    /// (`on_foot::parked_drawn`). Other players' buses are never among them.
    pub parked_buses_drawn: i32,
    /// An early timetable bus waits for its departure only at the stops the timetable times
    /// itself (#1773); off (the default) it waits at every stop it serves, as in OMSI.
    pub ai_wait_timed_stops_only: bool,
    /// `[no_collision_vehToVeh]` off: the player's bus collides with the traffic.
    pub collision_vehicles: bool,
    /// `[no_collision]` off: the player's bus collides with the map's solid objects.
    pub collision_objects: bool,
    /// `[no_collision_pedastrians]` off: people are knocked down.
    pub collision_pedestrians: bool,
    /// Realistic road physics (opt-in): slip-angle tyres, grip and roughness by surface, wind
    /// (see `omsi_sim::rigid::realism`). Off, road vehicles drive by OMSI 2's model.
    pub realistic_road_physics: bool,
    /// `[driverview_moving]`: the driver's head moves with the bus (braking, bends, bumps).
    pub head_movement: bool,
    /// The interior camera glides between viewpoints (OMSI's `[driverview_smooth]`).
    pub driverview_smooth: bool,
    /// The driver's hands on the wheel in the cab view (the rest of the figure left out).
    pub hands_in_cab: bool,
    /// The driver sits back on the seat with his hands off the wheel, as in OMSI 2, instead of
    /// leaning forward to hold it.
    pub driver_like_omsi: bool,
    /// OMSI's `[altView]` (options.cfg): the right mouse button turns the view and
    /// Shift+right zooms. Off, the right button zooms and the middle one turns the view
    /// (TForm_main.Panel1MouseMove 0x82c5f8) - OMSI's default, but on here by default: a
    /// laptop's touchpad has no middle button to look round with, and right-drag looking
    /// is what openOMSI always did.
    pub alt_view: bool,
    /// Precision zoom: the both-drag zoom follows the FOV-multiplier curve
    /// instead of OMSI's linear way over 500 px. Off (OMSI's way).
    pub precision_zoom: bool,
    pub zoom_hold_amount: f32,
    pub zoom_hold_latch: bool,
    pub flashlight_cursor: bool,
    /// The 3D picture drawn at this fraction of the window's size and scaled up (0.5..1),
    /// 0 = automatic (full size unless the window has more pixels than a 2560x1080 screen,
    /// as a Retina window does). The HUD is always drawn at full size.
    pub render_scale: f32,
    /// Upscaling method for the main game picture: default or experimental fsr1.
    pub upscaler: String,
    /// How much DLSS, AMD FSR 3 or Apple MetalFX scale up (`temporal::TemporalQuality`).
    pub upscale_quality: String,
    /// Frame generation (`omsi_cfg::upscaler_files::frame_generation_word`): `metalfx` with
    /// Apple MetalFX upscaling on, else `off`.
    pub frame_generation: String,
    /// FSR1 internal resolution preset, or custom to use render_scale.
    pub fsr_quality: String,
    /// FidelityFX RCAS sharpening strength (0 .. 1).
    pub fsr_sharpness: f32,
    /// Language of the texts the game shows about the cockpit: `ENG` (default), `DEU` or
    /// `FRA` - OMSI's own language file codes.
    pub language: String,
    /// What passengers say: `all`, `tickets` (only what they ask for) or `off`.
    pub pax_voices: String,
    /// The units of the game's own texts: `metric`, `uk` or `us` (see `units`).
    pub units: String,
    /// OMSI 2's route arrows over the road (as well as or instead of the navigator).
    pub nav_dynamic_arrows: bool,
    /// Route arrows placed by the map author.
    pub nav_map_arrows: bool,
    /// The other (AI) vehicles as dots on the navigator's and the city map.
    pub nav_ai: bool,
    pub nav_ai_cars: bool,
    /// The map's package's surface under the roads of the navigator and the city map, and their light look.
    pub nav_surface: bool, pub nav_light: bool,
    /// The navigator's houses stand in 3D (and the city map tilts when zoomed in).
    pub nav_3d: bool,
    /// Minimal top-down navigator without the detailed ground or 3D buildings.
    pub nav_classic_2d: bool,
    /// The navigator is a widget: dragged anywhere and sized at its corner.
    pub nav_widget: bool,
    /// The MileZero radio card over the navigator (`milezero`).
    pub milezero: bool,
    /// The navigator's size against the usual one (0.6 - 2).
    pub nav_size: f32,
    pub hud_sizes: [f32; 3],
    /// The driver may get up from the seat and walk about (Ctrl+Shift+G).
    pub get_up: bool,
    /// A summary of each trip of a duty as it ends: its stops with their times as planned and
    /// as driven (`game_panels::trip_summary`).
    pub trip_summary: bool,
    /// The AI traffic, the people and the scenery scripts stepped on a thread of their own
    /// while the picture is drawn (`omsi_sim::sim_thread`; the AI cars one frame later), from
    /// the next start; `OMSI_SIM_THREAD` over it.
    pub sim_thread: bool,
    /// A new bus starts with its tank full, filled by its own fuel pump (`veh_tank`) as at a
    /// petrol station; off, it has what its script gives it. A saved situation keeps its own.
    pub full_tank: bool,
    /// Uncompressed texture files are compressed on loading where that leaves the picture
    /// close (DXT files always stay compressed on a GPU that takes them).
    pub texture_compression: bool,
    /// DXT/BC textures stay compressed on a GPU that takes them (on by default); off, every
    /// texture is decoded to RGBA on loading - for a driver that mishandles block formats.
    /// (RGBA takes four to eight times the memory: the automatic texture memory then
    /// holds fewer fine mip levels.) `OMSI_NO_BC=1` turns it off as well.
    pub gpu_texture_compression: bool,
    /// Video memory (MB) for all the game holds on the graphics card, before far textures lose
    /// their finest mip levels; 0 = automatic (see `memory::video_memory_limit`). The old
    /// `texture_memory=` and `[texmemlimit]` were texture budgets and are not read into it.
    pub video_memory: u32,
    /// OMSI's automatic clutch (`AutoClutch`, on unless `[no_automaticClutch]`): the
    /// manual-gearbox scripts work the clutch themselves while it is on.
    pub auto_clutch: bool,
    /// Manual gate buttons return the gearbox to neutral when released.
    pub momentary_gears: bool,
    /// The automated manual: a gear lever's gates are worked by the engine speed (#713).
    pub auto_shift: bool,
    /// The original's `performance_minObjSize`: objects smaller on the screen than this are
    /// not drawn (its presets say 0.013; 0.020 for slow machines, smaller keeps more).
    pub min_obj_size: f32,
    /// The original's `performance_maxObjDist` (m): objects farther away are not drawn
    /// (0 = no limit). `auto` (-1) takes `view_distance` when the file sets one, else 900 m
    /// (the original's high presets).
    pub max_obj_dist: f32,
    /// Frames a second at most (the original's `[maxFPS]`); 0 = no limit. The frame waits
    /// asleep, so a limit also saves power and heat, and the CPU time for the rest.
    pub max_fps: u32,
    /// The chat of a LAN session (V shows and hides it, / types); off leaves it out altogether.
    pub chat: bool,
    /// The chat's own size on top of the interface's (`ui_scale`): 0.5 .. 3, also set with
    /// Ctrl + the mouse wheel over the chat.
    pub chat_size: f32,
    /// The name of what the cursor points at, shown next to the cursor.
    pub tooltips: bool,
    /// The other players' names above their buses.
    pub name_tags: bool,
    /// The driver sits in the player's bus, turning the wheel, seen from outside and the
    /// passengers' seats and in the mirrors (`driver`), never in the driver's own view.
    pub driver: bool,
    /// The frame rate in the HUD.
    pub show_fps: bool,
    pub perf_overlay: String,
    /// The driving hints: why the bus does not move, the change due, what a service did, as
    /// short notifications when they start (off, the game keeps them to itself; the server's
    /// and the plugins' notifications still come). The key keeps its old name, `notes`.
    pub notes: bool,
    pub notes_driving: bool,
    pub notes_script: bool,
    pub notes_trip: bool,
    pub notes_tickets: bool,
    /// The information bar along the top (Shift+Y, the menu, the touch panel's button): as
    /// it was left, not switched on again every session (#1164).
    pub info_bar: bool,
    /// The size of the game's interface over the picture - texts, the menu, the timetable,
    /// the navigator - on top of the screen's own scale and the window's height (see
    /// `ui::size_factor`): 0.5 .. 2 (1 = as designed).
    pub ui_scale: f32,
    /// Ordered pause-menu action IDs as JSON; "default" keeps the built-in shortcuts.
    pub pause_quick_actions: String,
    /// The interface theme (`themes`): its id, "" for openOMSI's own look.
    pub ui_theme_pack: String,
    /// The interface grows with a window taller than 1080 lines (`ui::size_factor`); off,
    /// it keeps its size on any window, as before.
    pub ui_scale_window: bool,
    /// Clouds in the sky (volumetric with enhanced graphics, OMSI's cloud layer without).
    pub clouds: bool,
    /// How finely the enhanced graphics' volumetric clouds are marched: `high` (the default)
    /// or `low`, the same clouds in fewer steps (`Lighting::low_clouds`).
    pub cloud_quality: String,
    /// The Enhanced picture's street-scale light - the sky's occlusion by houses and trees
    /// over 18 m and the light the surfaces send to each other: `off` by default, `on`,
    /// or `auto` (on except on a small or shared graphics chip; see `RenderOptions::street_light`).
    pub street_light: String,
    /// Enhanced: Real-Time Ray Tracing - the sun's shadows, the ambient occlusion and the
    /// reflections traced with hardware ray queries where the card has them (what Enhanced+ was;
    /// a file that says `graphics=enhanced_plus` is read as `enhanced` with this on).
    pub ray_tracing_on: bool,
    /// Enhanced: which lights cast shadows - `off`, `street` (the street lamps and the vehicles'
    /// headlamps) or `all` (the spots along their own axis, the lamps that shine every way in
    /// cube maps; see `RenderOptions::light_shadows`).
    pub light_shadows: String,
    /// Enhanced: the clouds' shadow over the land and the sun's shafts through the gaps.
    pub cloud_shadows: bool,
    /// Enhanced: the glare round bright lights and the lamps' halo in the night air.
    pub light_glow: bool,
    /// Enhanced: fog you can see the light in - the sun's shafts, drifting banks of mist, the
    /// clouds' shadows in the air (on by default).
    pub volumetric_fog: bool,
    /// How much the rain costs to draw: `high` (the default: the drops on the glass painted
    /// 30 times a second, every vehicle's spray, the full curtain of falling streaks),
    /// `medium` (the glass 15 times a second, the player's spray only, half the streaks) or
    /// `low` (OMSI 2's own texture rain on the glass, no spray, a quarter of the streaks).
    pub rain_quality: String,
    /// Vehicle [smoke] sprites: all (default), player, or off; scenery remains untouched.
    pub vehicle_smoke: String,
    /// The wet roads' reflections: `high` (as they were), `low` (near the bus, cheaper) or `off`.
    pub puddles: String,
    /// Windy trees: the trees' foliage bends and sways in the weather's wind and its gusts
    /// (above the trunk only; with no wind nothing moves).
    pub windy_trees: bool,
    /// Lights in the houses in a downpour: by day in a heavy rain some of the windows round
    /// the street are lit, as people switch the light on when it gets that dark.
    pub rain_lights: bool,
    pub detailed_trees: bool,
    /// Built-up snow: while it snows, snow builds up on the roads and the vehicles' roofs,
    /// with ruts and tyre tracks, and thaws again (omsi_scene::road_snow); off, the weather's
    /// on/off snow on road as in OMSI 2. A set `OMSI_ROAD_SNOW` overrides it.
    pub road_snow: bool,
    /// How many people wait and ride, against the map's own numbers (OMSI's `AIPassFactor`,
    /// 1 = 100 %).
    pub pax_density: f32,
    /// Volume of the AI vehicles and of the scenery's sounds (OMSI's `sound_ai`,
    /// `sound_scenery`), 0..1.
    pub vol_ai: f32,
    pub vol_scenery: f32,
    /// openOMSI's ambience from recordings (the place, the weather, the creatures, the town's
    /// life and the map's objects - see `soundscape`), and its volume 0..1.
    pub ambient: bool,
    pub vol_ambient: f32,
    /// What the bus radio's own sound does to a station (`radio_speaker`, `radio_hiss`,
    /// `radio_dropouts`, each 0..1, all 0 at first: see `omsi_audio::radio_fx`).
    pub radio_fx: omsi_audio::radio_fx::RadioFxParams,
    /// Edge of the mirrors' pictures in pixels (OMSI's `performance_reflTexSize`, 2^n); 0 disables mirror rendering.
    pub mirror_size: u32,
    /// How often the mirrors are drawn (OMSI's `performance_realreflexions`): `off` once
    /// for each bus and then still, `eco` 15 times a second at most, `full` 30 (the default),
    /// `every` each of them every frame - the street moves through them as smoothly as
    /// through the windscreen, where in turns it went by in steps, the longer the faster.
    pub mirror_refresh: String,
    /// How the mirrors are shaded in the Enhanced pictures: `standard` with the plain light
    /// (the cost of a small picture), `enhanced` as the window's picture is.
    pub mirror_quality: String,
    /// The mirrors show the sun's shadows (`mirror_shadows`, off by default).
    pub mirror_shadows: bool,
    /// The mirrors show smoke and spray (`mirror_particles`, off by default; OMSI's `No PS in reflections`).
    pub mirror_particles: bool,
    /// Copies of the main side mirrors in the corners of the window while in the cab: 0 off, 1 the right one, 2 the left, 3 both, + 4 the front one.
    pub mirror_hud: u8,
    /// The mirror panels (Ctrl+M) drawn every frame, as ETS2 draws its screen mirrors, rather than
    /// in turn with the other mirrors within `mirror_refresh`.
    pub mirror_hud_every_frame: bool,
    /// OMSI's `sound_doppler`: approaching sounds higher, receding ones lower.
    pub doppler: bool,
    /// How fast the clock runs (1 real time .. 30); in LAN play the host's decides.
    pub time_speed: f64,
    /// The game's date and time follow this device's clock (the host's in LAN play); the
    /// time cannot be changed while it is on.
    pub time_sync: bool,
    /// The weather follows the METAR report of the airport nearest the map (refreshed every
    /// few minutes); the weather cannot be changed while it is on.
    pub metar_sync: bool,
    /// The airport (ICAO) whose report the METAR sync follows; empty: the one nearest the map.
    pub metar_station: String,
    /// Texts the interface has no translation of are translated on this machine by a
    /// neural translation model (downloaded once, ~620 MB), for the languages OMSI has no
    /// language files of.
    pub machine_translation: bool,
    /// Which meshes cast sun shadows: "all" solid ones, or "omsi" - only those the models
    /// mark `[shadow]`, as OMSI 2's shadows do.
    pub shadow_casters: String,
    /// Dead zone round the centre of a set-up game controller's axes (0..0.3).
    pub ctrl_deadzone: f32,
    /// Use a gamepad's right stick for automatic camera movement.
    pub right_stick_look: bool,
    pub ctrl_background: bool,
    /// How long (ms) a gamepad stick's steering takes to settle where the stick points
    /// (0..300; 0 = the stick as it reads).
    pub pad_steer_smooth: f32,
    /// A gamepad stick steers as a wheel's axis: the wheel where the stick points, as far
    /// at any speed - for the cheap wheels the system calls an Xbox controller (#1653).
    pub pad_steer_linear: bool,
    /// Seconds a gamepad stick takes to turn the wheel from the middle to the full lock
    /// (0.8..5): the wheel followed the stick in 1.2 s, which is quick for twelve tonnes.
    pub pad_steer_speed: f32,
    /// The dead zone round a gamepad stick's centre (0..0.4).
    pub pad_deadzone: f32,
    /// The gamepad family the buttons are named for: `auto`, `xbox`, `ps4` or `ps5`.
    pub pad_type: String,
    /// A gamepad nobody set up buttons for drives the cabin with its default buttons
    /// (`gamepad_profile`).
    pub pad_buttons: bool,
    /// With a wheel steering, Left/Right switch the interior cameras as without one (as in
    /// Omsi.exe, whose view_interiorcam keys, 0x706a3c, ask for no controller), instead of
    /// turning the head (a glance), #1345; on by default since #2164.
    pub arrows_switch_cams: bool,
    /// Game controllers switched off, by name (`|` between them).
    pub ctrl_off: String,
    /// Keyboard steering at OMSI's steady pace (`KeyboardAxes::linear`).
    pub steering_linear: bool,
    /// The wheel stays where the keys left it (`KeyboardAxes::old_steering`).
    pub old_steering: bool,
    /// OMSI's `[redSteerSpd]`: the steering keys slower at speed (`KeyboardAxes::red_steer_spd`).
    pub red_steer_spd: bool,
    /// The materials' reflection maps (`RenderOptions::reflections`).
    pub reflections: f32,
    /// Enhanced: direct road and ground sunlight glare (0..2, 1 = original).
    pub road_glare: f32,
    /// Vanilla / Vanilla+: other vehicles' white headlamp sprites and classic beams (0..2).
    pub traffic_headlights: f32,
    /// How bright an LED panel's dots burn (`Lighting::led_glow`): 0 (off) .. 15, 16 levels.
    pub led_glow: u8,
    /// How much of the mip chain an LED panel is held at (`Lighting::led_mips`): its own
    /// picture and its `\S:n` mask are sampled at the level their screen footprint asks
    /// for, never coarser than this. 0 point-samples them (the sharpest dots, and the
    /// worst shimmer); 1.3 (the default) leaves a matrix's dots a couple of pixels across
    /// when the panel is small; 4 is near the calm of the full chain.
    pub led_mips: f32,
    /// Enhanced graphics: how much brighter the night is shown, in exposure steps (0 .. 3).
    pub night_brightness: f32,
    /// Mouse steering: how far the wheel turns for the same hand movement (1 = OMSI's: the
    /// window's width is the full lock).
    pub mouse_sens: f32,
    pub mouse_pedal_strength: f32,
    /// The graphics interface: `auto` (Vulkan, else DirectX 12, else OpenGL), `vulkan`,
    /// `dx12`, `gl` or `angle` (OpenGL ES on ANGLE over DirectX 11, Windows; see
    /// `startup::backend_order`).
    pub graphics_api: String,
    /// mX Graphics (Experimental, read on a Mac only): the game drawn by mX, openOMSI's own
    /// graphics library, through wgpu; where mX cannot open a device, wgpu's own backends take
    /// over (`startup::game_graphics_instance`; `OMSI_MX` overrides it on every system).
    pub mx_graphics: bool,
    /// Default motor polarity for wheels without a saved per-device direction.
    pub ff_invert: bool,
    /// Force feedback and rumble at all (off: the controller neither pushes nor shakes).
    pub ff_enabled: bool,
    /// The constant trembling of the tarmac under the wheels (0 = none .. 4 = strong).
    pub ff_road_vib: f32,
    /// The engine's buzz in the wheel, whatever gear the bus is in (0 = none .. 4 =
    /// strong).
    pub ff_engine_vib: f32,
    /// How long (s) a jolt's or a script's vibration eases away once it stops (0: it stops
    /// where it stands; 1.5 = a long easing-off).
    pub ff_fade: f32,
    /// OMSI's held brake on the keyboard (see `KeyboardAxes::pedal_hold`); `brake_hold` in
    /// the file - the old `pedal_hold` (off unless set, and holding the throttle as well)
    /// is left behind.
    pub brake_hold: bool,
    /// Mouse steering as it was left last time (O or the menu switches it; the game
    /// starts with it as the player had it).
    pub mouse_steering: bool,
    /// A right click ends the mouse steering, as in Omsi.exe (0x6f44aa: the right button
    /// held while the mouse steers fires `toggel_mouse_ctrl`). Off by default: looking
    /// round with the right button dragged switched it off every time.
    pub mouse_right_off: bool,
    /// The mouse steering's wheel and pedals ease after the cursor (~60 ms); off, they follow
    /// it at once, as in Omsi.exe (#1092).
    pub mouse_smooth: bool,
    /// The cursor is caught while the mouse steers, so the wheel reaches its full lock at any
    /// speed (0.2.17). Off: the system's crosshair cursor stays free and shows where the mouse
    /// steers without the frame's delay, and the window's edges are the lock, as in OMSI
    /// (#1948).
    pub mouse_hold: bool,
    /// The mouse steering works the pedals too (up the throttle, down the brake), as in
    /// Omsi.exe; off, it only steers and the pedals stay on the keys or a controller (#1704).
    pub mouse_pedals: bool,
    /// How fast the throttle and brake keys push their pedals, against OMSI's (1), #1371.
    pub key_pedal_speed: f32,
    /// How fast the view turns for the mouse's way while looking round (1 = Omsi.exe's
    /// field of view / 78.75 degrees per pixel in the views of the bus; #859).
    pub look_sens: f32,
    /// How long the view takes to come round to where the mouse (or the stick, or the
    /// arrow keys) turned it (milliseconds; 0 = off, the view goes there at once, as it
    /// always did). A little of this takes the edge off a mouse that reports in jumps and
    /// off a hand that shakes: the view glides to the angle instead of jumping to it.
    pub look_smoothing_ms: f32,
    /// The bus's script may cancel the indicator after a turn (#451: off, an indicator set
    /// stays on until the player turns it off).
    pub blinker_cancel: bool,
    /// The steering wheel's own rotation, lock to lock (degrees; a G29 turns 900).
    pub wheel_range: f32,
    /// How far the wheel is turned, lock to lock, for the bus's full lock (degrees); 0 = the
    /// whole of the wheel's rotation, as OMSI.
    pub wheel_lock: f32,
    /// How far the steering wheel in the cab turns, lock to lock (degrees, 180..=1800; 0 = as
    /// the bus's model.cfg turns it - the SD200 1450 x its lock, about 2200°). Set to the
    /// player's own wheel's rotation, the one in the cab turns alike (only the player's bus;
    /// see `VehicleInstance::set_cab_wheel_rotation`).
    pub cab_wheel_rotation: u32,
    /// Field of view of the views from the bus (degrees; 0 = the bus's own cameras).
    pub fov: f32,
    /// The outside camera is pulled in in front of what stands between it and the bus
    /// (off: it goes through everything, as in OMSI).
    pub camera_collision: bool,
    /// The driver's view turns a little into the steering (off: it stays fixed to the bus,
    /// as in OMSI, which has no such thing).
    pub steer_look: bool,
    /// Maximum automatic driver's-view yaw at full steering lock (degrees).
    pub steer_look_angle: f32,
    /// Steering-view smoothing time constant (seconds).
    pub steer_look_response: f32,
    /// How much the view sways on its own when nothing is done to it: a head at rest breathes
    /// and shifts its weight, and most of that is seen while the bus waits at a stop. 0 is not
    /// at all (as OMSI, and the default); 1 is the whole of the sway `head_idle` makes.
    pub head_idle: f32,
    /// How fast that sway moves, against the pace it is designed at (1: as designed; below 1
    /// slower, above it quicker).
    pub head_idle_pace: f32,
    /// How strongly the analog throttle and brake pedals act: the response curve's
    /// strength (1 = linear, below 1 softer at the start, above 1 stronger).
    pub pedal_throttle: f32,
    pub pedal_brake: f32,
    /// The driver's eye moved from the bus's own camera (m, bus frame: right, forward, up).
    pub seat: [f32; 3],
    /// The driver's default head pitch (degrees; positive looks up).
    pub seat_pitch_deg: f32,
    /// Head tracking through opentrack's UDP output (TrackIR, webcams, phones), and its port.
    pub head_tracking: bool,
    pub head_tracking_port: u16,
    /// Axes of the tracker turned the other way (`yaw,pitch,roll`): trackers disagree.
    pub head_tracking_invert: String,
    /// Head-tracking rotation sensitivity for yaw, pitch and roll.
    pub head_tracking_yaw_sens: f32,
    pub head_tracking_pitch_sens: f32,
    pub head_tracking_roll_sens: f32,
    /// Head-tracking translation sensitivity for X/Y/Z (percentage, 100 = 1:1).
    pub head_tracking_x_sens: f32,
    pub head_tracking_y_sens: f32,
    pub head_tracking_z_sens: f32,
    /// Explicit per-axis inversion for native TrackIR/head tracking rotation.
    pub head_tracking_invert_yaw: bool,
    pub head_tracking_invert_pitch: bool,
    pub head_tracking_invert_roll: bool,
    /// Explicit per-axis inversion for native TrackIR/head tracking translation.
    pub head_tracking_invert_x: bool,
    pub head_tracking_invert_y: bool,
    pub head_tracking_invert_z: bool,
    /// Where the head's pose comes from: "auto", "opentrack" or "tobii" (`crate::tobii`), and
    /// for a Tobii eye tracker whether a look at the screen's edges turns the view further.
    pub head_tracking_source: String,
    pub tobii_edges: bool,
    /// A Tobii tracker's pose steadied (0..1) and the dead zone round where the view is
    /// (degrees of the head), `crate::head_filter`.
    pub head_tracking_smoothing: f32,
    pub head_tracking_dead_zone: f32,
    /// Discord's "Playing" status (Rich Presence) and the Discord application it shows as.
    pub discord_status: bool,
    pub discord_app_id: String,
    pub discord_show: crate::discord::Show,
    /// Voice chat in multiplayer (`voice`): off until switched on, and then the microphone is
    /// opened only while a talk key is held (`voice_mode` `ptt`) or, in the open mode, always.
    pub voice_enabled: bool,
    /// `ptt` (talk keys) or `open` (what is loud enough is sent to the players nearby).
    pub voice_mode: String,
    /// Microphone gain (multiplier), the open microphone's threshold (dB full scale) and the
    /// microphone to use (empty: the system's).
    pub voice_mic_gain: f32,
    pub voice_threshold_db: f32,
    pub voice_input_device: String,
    /// Loudness of everybody's voice chat, and of the nearby and the radio channel alone.
    pub voice_volume: f32,
    pub voice_volume_nearby: f32,
    pub voice_volume_radio: f32,
    /// How far a player is heard on the nearby channel (m) in a session this game hosts.
    pub voice_range: f32,
    /// The list of who is talking on the screen.
    pub voice_talker_list: bool,
    /// Every other player's voice chat off (the players' list mutes one at a time).
    pub voice_all_off: bool,
    pub remote_cockpit: bool,
    pub remote_cockpit_port: u16,
}

#[rustfmt::skip]
impl Default for Settings {
    fn default() -> Self {
        // a phone's graphics chip and battery: 2x MSAA (cheap on a tiled GPU), no
        // ambient occlusion, a smaller shadow map and mirrors, a shorter view
        if crate::platform::MOBILE { Self::phone() } else { Self::desktop() }
    }
}

/// A dedicated server's AI limits (`server.cfg`'s `ai_unsched_factor`, `ai_max_scheduled`,
/// `ai_max_parked`, `ai_max_humans`), as `settings.cfg` lines read after the machine's own.
#[rustfmt::skip]
pub(crate) static SERVER_AI_LIMITS: std::sync::OnceLock<String> = std::sync::OnceLock::new();

#[rustfmt::skip]
impl Settings {
    /// HUD coordinates occupy the centre panel by default; world picking always
    /// keeps the full window's physical coordinates.
    pub fn hud_viewport(&self, size: (u32, u32)) -> [f32; 4] {
        if self.triple.enabled && self.triple_hud_center && !self.vr_requested() && size.0 >= 3 {
            // (the centre panel, as the renderer draws it)
            let w = omsi_render::panel_width(size.0);
            [w as f32, 0.0, w as f32, size.1 as f32]
        } else {
            [0.0, 0.0, size.0 as f32, size.1 as f32]
        }
    }
    pub fn is_light_theme(&self) -> bool {
        self.ui_theme == "light"
    }
    pub(crate) fn phone() -> Self {
        Self { msaa: 2, anisotropy: 4, ssao: false, shadow_size: 1024, mirror_size: 128, max_fps: 60, max_obj_dist: 900.0, pax_density: 0.7, navigator_corner: "top-center".into(), ..Self::desktop() }
    }
    /// The defaults of a computer.
    fn desktop() -> Self {
        Self { msaa: 4, anisotropy: 8, ssao: true, shadows: true, shadow_size: 2048, shadow_blobs: true, lamp_shadows: true, navigator: true, ui_opacity: 0.85, ui_theme: "dark".into(), notes: true, notes_driving: true, notes_script: true, notes_trip: true, notes_tickets: true, ui_scale: 1.0, pause_quick_actions: "default".into(), ui_theme_pack: String::new(), ui_scale_window: true, navigator_corner: "bottom-left".into(), boarding: "auto".into(), passenger_animation: "original".into(), passenger_hailing: false, passenger_full_bus_reaction: false, pax_short_rides_stand: false, passenger_connections: false, passenger_transfer_percent: 20.0, units: "metric".into(), photo_mode: "simple".into(), character_models: "original".into(), standing_chance: 0.05, ambient: true, vol_ambient: 0.8, radio_fx: Default::default(), detail_textures: true, exact_fare: true, pax_bad_driving: true, pax_board_when_stopped: false, auto_announce: false, enhanced: false, graphics: "vanilla_plus".into(), triple: Default::default(), triple_span: true, triple_hud_center: true, vr: false, vr_scale: 0.65, vr_head_smoothing_ms: 0.0, vr_mirror_rate: 16.0, vr_desktop_mirror: true, fullscreen: false, vsync: true, volume: 0.6, drive_keys: "simple".into(), touch_door_mode: "standard".into(), touch_pedal_length: 1.0, touch_pedal_deadzone: 0.15, post_aa: "fxaa".into(), render_scale: 0.0, upscaler: "default".into(), upscale_quality: "quality".into(), frame_generation: "off".into(), fsr_quality: "quality".into(), fsr_sharpness: 0.8, language: "ENG".into(), pax_voices: "all".into(), nav_dynamic_arrows: false, nav_map_arrows: false, nav_ai: true, nav_ai_cars: true, nav_surface: true, nav_light: false, nav_3d: true, nav_classic_2d: false, nav_widget: true, milezero: false, nav_size: 1.0, get_up: false, trip_summary: true, full_tank: true, sim_thread: false, texture_compression: true, gpu_texture_compression: true, video_memory: 0, auto_clutch: true, momentary_gears: false, auto_shift: false, min_obj_size: 0.013, max_obj_dist: -1.0, max_fps: 0, chat: true, chat_size: 1.0, tooltips: true, name_tags: true, show_fps: false, perf_overlay: "off".into(), clouds: true, cloud_quality: "high".into(), street_light: "off".into(), ray_tracing_on: false, light_shadows: "off".into(), cloud_shadows: false, light_glow: false, volumetric_fog: true, rain_quality: "high".into(), vehicle_smoke: "all".into(), puddles: "high".into(), windy_trees: true, rain_lights: true, detailed_trees: true, road_snow: false, pax_density: 1.0, vol_ai: 1.0, vol_scenery: 1.0, mirror_size: 256, mirror_hud: 0, mirror_hud_every_frame: false, mirror_refresh: "full".into(), mirror_quality: "standard".into(), mirror_shadows: false, mirror_particles: false, doppler: true, driver: true, maintenance: 0, ai_unsched_factor: 1.0, ai_reaction: 1.0, ai_max_scheduled: 0, ai_max_parked: 0, ai_max_humans: 200, parked_buses_drawn: -1, ai_wait_timed_stops_only: false, collision_vehicles: true, collision_objects: true, collision_pedestrians: true, realistic_road_physics: false, head_movement: true, driverview_smooth: true, hands_in_cab: false, driver_like_omsi: false, alt_view: true, precision_zoom: false, zoom_hold_amount: 0.5, zoom_hold_latch: false, flashlight_cursor: false, time_speed: 1.0, time_sync: false, metar_sync: false, metar_station: String::new(), machine_translation: false, shadow_casters: "all".into(), ctrl_deadzone: 0.0, right_stick_look: true, ctrl_background: false, pad_steer_smooth: 120.0, pad_steer_linear: false, pad_steer_speed: 2.0, pad_deadzone: 0.08, pad_type: "auto".into(), pad_buttons: true, arrows_switch_cams: true, ctrl_off: String::new(), steering_linear: false, old_steering: false, red_steer_spd: false, reflections: 1.0, road_glare: 1.0, traffic_headlights: 1.0, led_glow: 6, led_mips: 1.3, night_brightness: 0.0, mouse_sens: 1.0, mouse_pedal_strength: 1.0, graphics_api: "auto".into(), mx_graphics: false, ff_invert: false, ff_enabled: true, ff_road_vib: 1.0, ff_engine_vib: 1.0, ff_fade: 0.28, brake_hold: true, mouse_steering: false, mouse_right_off: false, mouse_smooth: true, mouse_hold: true, mouse_pedals: true, key_pedal_speed: 1.0, look_sens: 1.0, look_smoothing_ms: 0.0, blinker_cancel: true, wheel_range: 900.0, wheel_lock: 0.0, cab_wheel_rotation: 0, fov: 0.0, camera_collision: true, steer_look: false, steer_look_angle: 30.0, steer_look_response: 0.25, head_idle: 0.0, head_idle_pace: 1.0, pedal_throttle: 1.0, pedal_brake: 1.0, seat: [0.0; 3], seat_pitch_deg: 0.0, head_tracking: false, head_tracking_port: 4242, head_tracking_invert: String::new(), head_tracking_yaw_sens: 100.0, head_tracking_pitch_sens: 100.0, head_tracking_roll_sens: 100.0, head_tracking_x_sens: 100.0, head_tracking_y_sens: 100.0, head_tracking_z_sens: 100.0, head_tracking_invert_yaw: false, head_tracking_invert_pitch: false, head_tracking_invert_roll: false, head_tracking_invert_x: false, head_tracking_invert_y: false, head_tracking_invert_z: false, head_tracking_source: "auto".into(), tobii_edges: false, head_tracking_smoothing: 0.5, head_tracking_dead_zone: 0.1, discord_status: false, discord_app_id: String::new(), discord_show: Default::default(), voice_enabled: false, voice_mode: "ptt".into(), voice_mic_gain: 1.0, voice_threshold_db: -45.0, voice_input_device: String::new(), voice_volume: 1.0, voice_volume_nearby: 1.0, voice_volume_radio: 1.0, voice_range: 75.0, voice_talker_list: true, voice_all_off: false, info_bar: false, hud_sizes: [1.0; 3], remote_cockpit: false, remote_cockpit_port: 8642 }
    }
}

#[rustfmt::skip]
impl Settings {
    pub fn perf_overlay_on(&self) -> bool {
        self.perf_overlay != "off"
    }

    /// The launcher setting, with the old environment switch kept for existing VR runs.
    pub fn vr_requested(&self) -> bool {
        cfg!(windows) && (self.vr || omsi_cfg::flags::OMSI_OPENXR.is_set())
    }

    /// `~/.openomsi/settings.cfg` (or `%USERPROFILE%` on Windows).
    pub fn path() -> Option<PathBuf> {
        let home = std::env::var_os("HOME").or_else(|| std::env::var_os("USERPROFILE"))?;
        Some(PathBuf::from(home).join(".openomsi").join("settings.cfg"))
    }

    /// The window's size in pixels the settings ask for (`resolution=WxH`, #904); None:
    /// automatic (fitted to the screen, the whole of it under gamescope).
    pub fn resolution() -> Option<(u32, u32)> {
        let text = std::fs::read_to_string(Self::path()?).ok()?;
        resolution_of(&text)
    }

    pub fn load() -> Settings {
        let Some(p) = Self::path() else { return Settings::default() };
        let mut text = std::fs::read_to_string(&p).unwrap_or_default();
        // OMSI_GRAPHICS=vanilla|vanilla_plus|enhanced: another renderer for one run
        if let Some(g) = omsi_cfg::flags::OMSI_GRAPHICS.var() {
            text.push_str(&format!("\ngraphics={g}\n"));
        }
        // a dedicated server's AI limits (`server.cfg`) over the machine's own
        if let Some(lines) = SERVER_AI_LIMITS.get() {
            text.push('\n');
            text.push_str(lines);
        }
        // The settings made of the text read last, while the file says just the same: a
        // start asked for them some twenty times, and each time parsed the file anew.
        // (Compared by its text, not its time of change: a menu's change saved and read
        // back within the same second must not be missed.)
        static LAST: parking_lot::Mutex<Option<(PathBuf, String, Settings)>> = parking_lot::Mutex::new(None);
        if let Some((path, was, s)) = LAST.lock().as_ref() {
            if *path == p && *was == text {
                return s.clone();
            }
        }
        let mut s = Self::from_text(&text);
        // OMSI_SAFE_GPU=<n>: the game was started again after its graphics device was lost
        // (see `App::restart_after_device_loss`): lighter on the card each time
        if let Some(n) = omsi_cfg::flags::OMSI_SAFE_GPU.parse::<u32>().filter(|n| *n > 0) {
            s.apply_safe_gpu(n);
        }
        log::info!("settings from {}: msaa {} af {} ssao {} shadows {} ({}) navigator {} graphics {} post aa {} vsync {} render scale {} boarding {} min object size {} max object distance {} max fps {}", p.display(), s.msaa, s.anisotropy, s.ssao, s.shadows, s.shadow_size, s.navigator, s.graphics, s.post_aa, s.vsync, s.render_scale_text(), s.boarding, s.min_obj_size, s.object_distance(), s.max_fps);
        *LAST.lock() = Some((p, text, s.clone()));
        s
    }

    /// One of the Tobii head-tracking lines, the pause menu's shortcuts or the interface theme of the settings file (`from_text`).
    fn read_extra(&mut self, k: &str, v: &str) {
        match k {
            "head_tracking_source" => self.head_tracking_source = omsi_launcher_lib::head_tracking_source(v).to_string(),
            "pause_quick_actions" => self.pause_quick_actions = v.to_string(),
            "ui_theme_pack" => self.ui_theme_pack = crate::themes::setting(v),
            "tobii_edges" => self.tobii_edges = matches!(v.to_ascii_lowercase().as_str(), "1" | "true" | "on" | "yes"),
            "zoom_hold_latch" => self.zoom_hold_latch = matches!(v.to_ascii_lowercase().as_str(), "1" | "true" | "on" | "yes"),
            "zoom_hold_amount" => self.zoom_hold_amount = v.parse::<f32>().ok().filter(|x| x.is_finite()).map(|x| x.clamp(0.15, 1.0)).unwrap_or(self.zoom_hold_amount),
            "flashlight_cursor" => self.flashlight_cursor = matches!(v.to_ascii_lowercase().as_str(), "1" | "true" | "on" | "yes"),
            _ => {
                let x = omsi_launcher_lib::head_tracking_value(k, v.parse::<f64>().ok()) as f32;
                if k == "head_tracking_smoothing" { self.head_tracking_smoothing = x } else { self.head_tracking_dead_zone = x }
            }
        }
    }
    fn read_voice(&mut self, k: &str, v: &str) {
        match k {
            "voice_enabled" => self.voice_enabled = matches!(v.to_ascii_lowercase().as_str(), "1" | "true" | "on" | "yes"),
            "voice_mode" => self.voice_mode = if v.trim().eq_ignore_ascii_case("open") { "open".into() } else { "ptt".into() },
            "voice_mic_gain" => self.voice_mic_gain = v.parse::<f32>().ok().filter(|x| x.is_finite()).map(|x| x.clamp(0.0, 4.0)).unwrap_or(self.voice_mic_gain),
            "voice_threshold_db" => self.voice_threshold_db = v.parse::<f32>().ok().filter(|x| x.is_finite()).map(|x| x.clamp(-80.0, -10.0)).unwrap_or(self.voice_threshold_db),
            "voice_input_device" => self.voice_input_device = v.trim().to_string(),
            "voice_volume" => self.voice_volume = v.parse::<f32>().ok().filter(|x| x.is_finite()).map(|x| x.clamp(0.0, 2.0)).unwrap_or(self.voice_volume),
            "voice_volume_nearby" => self.voice_volume_nearby = v.parse::<f32>().ok().filter(|x| x.is_finite()).map(|x| x.clamp(0.0, 2.0)).unwrap_or(self.voice_volume_nearby),
            "voice_volume_radio" => self.voice_volume_radio = v.parse::<f32>().ok().filter(|x| x.is_finite()).map(|x| x.clamp(0.0, 2.0)).unwrap_or(self.voice_volume_radio),
            "voice_range" => self.voice_range = v.parse::<f32>().ok().filter(|x| x.is_finite()).map(|x| x.clamp(5.0, 1000.0)).unwrap_or(self.voice_range),
            "voice_talker_list" => self.voice_talker_list = matches!(v.to_ascii_lowercase().as_str(), "1" | "true" | "on" | "yes"),
            "voice_all_off" => self.voice_all_off = matches!(v.to_ascii_lowercase().as_str(), "1" | "true" | "on" | "yes"),
            _ => {}
        }
    }
    /// The settings a `settings.cfg` text describes (anything missing keeps its default).
    /// The upscaler's lines of settings.cfg (`from_text`): unknown values fall back to the
    /// standard upscaler, the Quality preset and 80 % sharpening.
    fn read_upscaler(&mut self, k: &str, v: &str) {
        match k {
            "upscaler" => self.upscaler = omsi_launcher_lib::upscaler_word(v).into(),
            "upscale_quality" => self.upscale_quality = omsi_render::TemporalQuality::parse(v).as_str().into(),
            "frame_generation" => self.frame_generation = omsi_cfg::upscaler_files::frame_generation_word(v).into(),
            "fsr_quality" => self.fsr_quality = match v.to_ascii_lowercase().as_str() {
                "ultra" => "ultra", "balanced" => "balanced", "performance" => "performance",
                "custom" => "custom", "auto" => "auto", _ => "quality",
            }.into(),
            _ => self.fsr_sharpness = v.parse::<f32>().ok().filter(|n| n.is_finite()).map(|n| n.clamp(0.0, 1.0)).unwrap_or(0.8),
        }
    }

    /// The lit LEDs' glow and mipmaps, the night's brightness and the graphics interface
    /// (`from_text`): an unreadable number keeps the default.
    fn read_graphics(&mut self, k: &str, v: &str) {
        let v = v.trim();
        match k {
            "led_glow" => self.led_glow = v.parse::<i32>().map(|x| x.clamp(0, 15) as u8).unwrap_or(self.led_glow),
            "night_brightness" => self.night_brightness = v.parse::<f32>().ok().filter(|x| x.is_finite()).map(|x| x.clamp(0.0, 3.0)).unwrap_or(self.night_brightness),
            "led_mips" => self.led_mips = v.parse::<f32>().ok().filter(|x| x.is_finite()).map(|x| x.clamp(0.0, 4.0)).unwrap_or(self.led_mips),
            "graphics_api" => self.graphics_api = v.to_ascii_lowercase(),
            "mx_graphics" => self.mx_graphics = matches!(v.to_ascii_lowercase().as_str(), "1" | "true" | "on" | "yes"),
            _ => {}
        }
    }

    pub fn from_text(text: &str) -> Settings {
        let mut s = Settings::default();
        let mut version = 0u32;
        let mut graphics: Option<String> = None;
        let mut theme = (false, None);
        for line in text.lines().map(str::trim).filter(|line| !line.is_empty() && !line.starts_with('#') && !line.starts_with(';')) {
            let Some((k, v)) = line.split_once('=') else { continue };
            let (k, v) = (k.trim().to_ascii_lowercase(), v.trim());
            let b = |v: &str| matches!(v.to_ascii_lowercase().as_str(), "1" | "true" | "on" | "yes");
            match k.as_str() {
                "version" => version = v.parse().unwrap_or(0),
                "msaa" => s.msaa = v.parse().unwrap_or(s.msaa),
                "anisotropy" | "af" => s.anisotropy = v.parse().unwrap_or(s.anisotropy),
                "ssao" | "ambient_occlusion" => s.ssao = b(v),
                "shadows" => s.shadows = b(v),
                "shadow_size" => s.shadow_size = v.parse().unwrap_or(s.shadow_size),
                "shadow_blobs" | "lamp_shadows" => { let on = b(v); if k == "lamp_shadows" { s.lamp_shadows = on } else { s.shadow_blobs = on } }
                "navigator" => s.navigator = b(v),
                "ui_opacity" | "navigator_opacity" => s.ui_opacity = v.parse::<f32>().ok().filter(|x| x.is_finite()).map(|x| x.clamp(0.2, 1.0)).unwrap_or(s.ui_opacity),
                "ui_theme" => { theme.0 = true; s.ui_theme = if v.eq_ignore_ascii_case("light") { "light" } else { "dark" }.into(); }
                "navigator_corner" => s.navigator_corner = v.to_ascii_lowercase(),
                "boarding" => s.boarding = v.to_ascii_lowercase(),
                "standing_chance" => s.standing_chance = v.trim_end_matches('%').parse::<f32>().ok().filter(|x| x.is_finite()).map(|x| (x / 100.0).clamp(0.0, 1.0)).unwrap_or(s.standing_chance),
                "photo_mode" => s.photo_mode = if v.eq_ignore_ascii_case("advanced") { "advanced" } else { "simple" }.into(),
                "passenger_connections" => s.passenger_connections = b(v),
                "passenger_transfer_percent" => s.passenger_transfer_percent = v.parse::<f32>().ok().filter(|x| x.is_finite()).unwrap_or(20.0).clamp(0.0,100.0),
                "passenger_hailing" => s.passenger_hailing = b(v),
                "passenger_full_bus_reaction" => s.passenger_full_bus_reaction = b(v),
                "pax_short_rides_stand" => s.pax_short_rides_stand = b(v),
                "passenger_animation" => s.passenger_animation = if v.eq_ignore_ascii_case("enhanced") { "enhanced" } else { "original" }.into(),
                "character_models" => s.character_models = if v.eq_ignore_ascii_case("improved") { "improved" } else { "original" }.into(),
                "detail_textures" | "fractal" => s.detail_textures = b(v),
                "exact_fare" => s.exact_fare = b(v),
                "pax_bad_driving" => s.pax_bad_driving = b(v),
                "pax_board_when_stopped" => s.pax_board_when_stopped = b(v),
                "auto_announce" => s.auto_announce = b(v),
                "enhanced" => s.enhanced = b(v),
                "graphics" | "renderer" => graphics = Some(graphics_mode(v).to_string()),
                "vr" => s.vr = b(v),
                "vr_scale" => s.vr_scale = v.parse::<f32>().ok().filter(|x| x.is_finite()).map(|x| x.clamp(0.5, 1.0)).unwrap_or(s.vr_scale),
                "vr_head_smoothing_ms" => s.vr_head_smoothing_ms = v.parse::<f32>().ok().filter(|x| x.is_finite()).map(|x| x.clamp(0.0, 30.0)).unwrap_or(s.vr_head_smoothing_ms),
                "vr_mirror_rate" => s.vr_mirror_rate = v.parse::<f32>().ok().filter(|x| x.is_finite()).map(|x| x.clamp(-1.0, 360.0)).unwrap_or(s.vr_mirror_rate),
                "vr_desktop_mirror" => s.vr_desktop_mirror = b(v),
                "triple_screen" => s.triple.enabled = b(v),
                "triple_span" => s.triple_span = b(v),
                "triple_hud_center" => s.triple_hud_center = b(v),
                "triple_fov_deg" => {
                    s.triple.fov_deg = v
                        .parse::<f32>()
                        .ok()
                        .filter(|x| x.is_finite())
                        .map(|x| if x < 20.0 { 0.0 } else { x.min(120.0) })
                        .unwrap_or(s.triple.fov_deg)
                }
                "triple_width_mm" => {
                    s.triple.width_mm = v
                        .parse::<f32>()
                        .ok()
                        .filter(|x| x.is_finite())
                        .map(|x| x.clamp(200.0, 2000.0))
                        .unwrap_or(s.triple.width_mm)
                }
                "triple_distance_mm" => {
                    s.triple.distance_mm = v
                        .parse::<f32>()
                        .ok()
                        .filter(|x| x.is_finite())
                        .map(|x| x.clamp(200.0, 3000.0))
                        .unwrap_or(s.triple.distance_mm)
                }
                "triple_bezel_mm" => {
                    s.triple.bezel_mm = v
                        .parse::<f32>()
                        .ok()
                        .filter(|x| x.is_finite())
                        .map(|x| x.clamp(0.0, 100.0))
                        .unwrap_or(s.triple.bezel_mm)
                }
                "triple_left_angle_deg" => {
                    s.triple.left_angle_deg = v
                        .parse::<f32>()
                        .ok()
                        .filter(|x| x.is_finite())
                        .map(|x| x.clamp(0.0, 90.0))
                        .unwrap_or(s.triple.left_angle_deg)
                }
                "triple_right_angle_deg" => {
                    s.triple.right_angle_deg = v
                        .parse::<f32>()
                        .ok()
                        .filter(|x| x.is_finite())
                        .map(|x| x.clamp(0.0, 90.0))
                        .unwrap_or(s.triple.right_angle_deg)
                }
                "triple_eye_height_mm" => s.triple.eye_height_mm = v.parse::<f32>().ok().filter(|x| x.is_finite()).map(|x| x.clamp(-500.0, 500.0)).unwrap_or(s.triple.eye_height_mm),
                "fullscreen" => s.fullscreen = b(v),
                "vsync" => s.vsync = b(v),
                "volume" => s.volume = v.parse().unwrap_or(s.volume),
                "upscaler" | "upscale_quality" | "frame_generation" | "fsr_quality" | "fsr_sharpness" => s.read_upscaler(&k, v),
                // "auto", a fraction (0.75) or a percentage (75)
                "render_scale" => {
                    s.render_scale = if v.eq_ignore_ascii_case("auto") {
                        0.0
                    } else {
                        match v.trim_end_matches('%').parse::<f32>() {
                            Ok(x) if x > 1.5 => (x / 100.0).clamp(0.5, 1.0),
                            Ok(x) if x > 0.0 => x.clamp(0.5, 1.0),
                            Ok(_) => 0.0,
                            Err(_) => s.render_scale,
                        }
                    }
                }
                "language" | "lang" => s.language = crate::describe::language_code(v),
                "units" => s.units = crate::units::Units::from_setting(v).setting().into(),
                "pax_voices" => s.pax_voices = match v.to_ascii_lowercase().as_str() { "tickets" => "tickets".into(), "off" | "0" | "none" => "off".into(), _ => "all".into() },
                "nav_ai" => s.nav_ai = b(v), "nav_ai_cars" => s.nav_ai_cars = b(v), "nav_surface" => s.nav_surface = b(v), "nav_light" => { let light = b(v); s.nav_light = light; theme.1 = Some(light); }, "nav_3d" => s.nav_3d = b(v), "nav_classic_2d" => s.nav_classic_2d = b(v), "nav_widget" => s.nav_widget = b(v), "milezero" => s.milezero = b(v), "nav_size" => s.nav_size = v.parse::<f32>().ok().filter(|x| x.is_finite()).map(|x| x.clamp(0.6, 2.0)).unwrap_or(1.0),
                "get_up" => s.get_up = b(v),
                "trip_summary" => s.trip_summary = b(v),
                "sim_thread" => s.sim_thread = b(v),
                "full_tank" => s.full_tank = b(v),
                "texture_compression" => s.texture_compression = b(v),
                "gpu_texture_compression" => s.gpu_texture_compression = gpu_texture_compression(v),
                "auto_clutch" | "automatic_clutch" => s.auto_clutch = b(v),
                "momentary_gears" | "gear_buttons_hold" => s.momentary_gears = b(v),
                "auto_shift" => s.auto_shift = b(v),
                "min_obj_size" | "performance_minobjsize" => s.min_obj_size = v.parse::<f32>().map(|x| x.clamp(0.0, 0.2)).unwrap_or(s.min_obj_size),
                "max_obj_dist" | "performance_maxobjdist" => s.max_obj_dist = if v.eq_ignore_ascii_case("off") { 0.0 } else if v.eq_ignore_ascii_case("auto") { -1.0 } else { v.parse::<f32>().map(|x| x.max(0.0)).unwrap_or(s.max_obj_dist) },
                "max_fps" | "maxfps" => {
                    s.max_fps = v.parse::<f32>().map(|x| x.max(0.0) as u32).unwrap_or(s.max_fps);
                    // a phone given the PC OMSI's 30 by the settings import: 60
                    if cfg!(any(target_os = "android", target_os = "ios")) && s.max_fps == 30 {
                        s.max_fps = 60;
                    }
                }
                "chat" => s.chat = b(v),
                "tooltips" | "mouseover" => s.tooltips = b(v),
                "name_tags" | "nametags" => s.name_tags = b(v),
                "driver" => s.driver = b(v),
                "show_fps" | "fps" => s.show_fps = b(v),
                "perf_overlay" => s.perf_overlay = omsi_launcher_lib::perf_overlay_mode(v).into(),
                "clouds" => s.clouds = b(v),
                "cloud_quality" => s.cloud_quality = cloud_quality(v).into(),
                "street_light" => s.street_light = street_light(v).into(), "ray_tracing" | "rt" | "light_shadows" | "cloud_shadows" | "light_glow" | "volumetric_fog" => s.set_light_option(k.as_str(), v),
                "rain_quality" => s.rain_quality = rain_quality(v).into(),
                "vehicle_smoke" => s.vehicle_smoke = omsi_launcher_lib::vehicle_smoke(v).into(),
                "puddles" => s.puddles = omsi_launcher_lib::puddles(v).into(),
                "windy_trees" => s.windy_trees = b(v), "rain_lights" => s.rain_lights = b(v), "detailed_trees" => s.detailed_trees = b(v), "road_snow" => s.road_snow = b(v),
                "pax_density" | "aipassfactor" => s.pax_density = v.trim_end_matches('%').parse::<f32>().map(|x| if x > 5.0 { x / 100.0 } else { x }).map(|x| x.clamp(0.0, 3.0)).unwrap_or(s.pax_density),
                "vol_ai" => s.vol_ai = v.parse::<f32>().map(|x| x.clamp(0.0, 1.0)).unwrap_or(s.vol_ai),
                "vol_scenery" => s.vol_scenery = v.parse::<f32>().map(|x| x.clamp(0.0, 1.0)).unwrap_or(s.vol_scenery),
                "ambient" => s.ambient = b(v),
                "vol_ambient" => s.vol_ambient = v.parse::<f32>().map(|x| x.clamp(0.0, 1.0)).unwrap_or(s.vol_ambient),
                "radio_speaker" => s.radio_fx.speaker = v.parse::<f32>().map(|x| x.clamp(0.0, 1.0)).unwrap_or(s.radio_fx.speaker),
                "radio_hiss" => s.radio_fx.hiss = v.parse::<f32>().map(|x| x.clamp(0.0, 1.0)).unwrap_or(s.radio_fx.hiss),
                "radio_dropouts" => s.radio_fx.dropouts = v.parse::<f32>().map(|x| x.clamp(0.0, 1.0)).unwrap_or(s.radio_fx.dropouts),
                "doppler" | "sound_doppler" => s.doppler = b(v),
                "mirror_hud" => s.mirror_hud = v.parse::<u8>().map(|x| x.min(7)).unwrap_or(s.mirror_hud),
                "mirror_hud_every_frame" => s.mirror_hud_every_frame = b(v),
                "mirror_size" => s.mirror_size = v.parse::<u32>().map(|x| if x == 0 { 0 } else { x.clamp(64, 2048).next_power_of_two() }).unwrap_or(s.mirror_size),
                "mirror_refresh" | "performance_realreflexions" => s.mirror_refresh = match v.trim().to_ascii_lowercase().as_str() {
                    "off" | "none" => "off",
                    "eco" | "economy" => "eco",
                    "every" | "every_frame" => "every",
                    _ => "full",
                }
                .into(),
                "mirror_shadows" => s.mirror_shadows = b(v),
                "mirror_particles" => s.mirror_particles = b(v),
                "mirror_quality" => s.mirror_quality = if v.trim().eq_ignore_ascii_case("enhanced") { "enhanced" } else { "standard" }.into(),
                "video_memory" => s.video_memory = v.parse::<f32>().map(|x| x.max(0.0) as u32).unwrap_or(s.video_memory),
                "maintenance" | "wear_lifespan" => s.maintenance = v.parse::<u8>().map(|x| x.min(4)).unwrap_or(s.maintenance),
                "ai_unsched_factor" | "aiunschedfactor" => s.ai_unsched_factor = v.trim_end_matches('%').parse::<f32>().map(|x| (x / 100.0).clamp(0.0, 3.0)).unwrap_or(s.ai_unsched_factor),
                "ai_reaction" => s.ai_reaction = v.trim_end_matches('%').parse::<f32>().map(|x| (x / 100.0).clamp(0.25, 2.0)).unwrap_or(s.ai_reaction),
                "ai_max_scheduled" | "aimaxcountscheduled" => s.ai_max_scheduled = v.parse().unwrap_or(s.ai_max_scheduled),
                "ai_max_humans" | "aimaxhumans" => s.ai_max_humans = v.parse::<u32>().map(|x| x.max(1)).unwrap_or(s.ai_max_humans),
                "parked_buses_drawn" => s.parked_buses_drawn = v.parse::<i32>().map(|x| x.max(-1)).unwrap_or(s.parked_buses_drawn),
                "ai_wait_timed_stops_only" => s.ai_wait_timed_stops_only = b(v),
                "ai_max_parked" | "aimaxcountparked" => s.ai_max_parked = v.parse::<i32>().map(|x| x.max(-1)).unwrap_or(s.ai_max_parked),
                "collision_vehicles" => s.collision_vehicles = b(v),
                "collision_objects" => s.collision_objects = b(v),
                "collision_pedestrians" => s.collision_pedestrians = b(v),
                "realistic_road_physics" => s.realistic_road_physics = b(v),
                "head_movement" | "driverview_moving" => s.head_movement = b(v),
                "driverview_smooth" => s.driverview_smooth = b(v),
                "hands_in_cab" => s.hands_in_cab = b(v),
                "driver_like_omsi" => s.driver_like_omsi = b(v),
                "alt_view" => s.alt_view = b(v),
                "precision_zoom" => s.precision_zoom = b(v),
                "time_speed" => s.time_speed = v.trim_start_matches(['x', 'X']).parse::<f64>().ok().filter(|x| x.is_finite()).map(|x| x.clamp(1.0, 30.0)).unwrap_or(s.time_speed),
                "time_sync" | "real_time_sync" => s.time_sync = b(v),
                "metar_sync" => s.metar_sync = b(v),
                "metar_station" => s.metar_station = v.trim().chars().filter(|c| c.is_ascii_alphabetic()).take(4).collect::<String>().to_ascii_uppercase(),
                "machine_translation" => s.machine_translation = b(v),
                "ctrl_deadzone" => s.ctrl_deadzone = v.parse::<f32>().ok().filter(|x| x.is_finite()).map(|x| x.clamp(0.0, 0.3)).unwrap_or(s.ctrl_deadzone),
                "right_stick_look" => s.right_stick_look = b(v),
                "ctrl_background" => s.ctrl_background = b(v),
                "pad_steer_linear" => s.pad_steer_linear = b(v),
                "pad_steer_speed" => s.pad_steer_speed = v.parse::<f32>().ok().filter(|x| x.is_finite()).map(|x| x.clamp(0.8, 5.0)).unwrap_or(s.pad_steer_speed),
                "pad_deadzone" => s.pad_deadzone = v.parse::<f32>().ok().filter(|x| x.is_finite()).map(|x| x.clamp(0.0, 0.4)).unwrap_or(s.pad_deadzone),
                "pad_type" => s.pad_type = pad_type(v).into(),
                "pad_buttons" => s.pad_buttons = b(v),
                "arrows_switch_cams" => s.arrows_switch_cams = b(v),
                "pad_steer_smooth" => s.pad_steer_smooth = v.parse::<f32>().ok().filter(|x| x.is_finite()).map(|x| x.clamp(0.0, 300.0)).unwrap_or(s.pad_steer_smooth),
                "reflections" | "envmap" => s.reflections = v.trim().parse::<f32>().ok().filter(|x| x.is_finite()).map_or_else(|| if b(v) { 1.0 } else { 0.0 }, |x| x.clamp(0.0, 1.0)),
                "road_glare" => s.road_glare = v.parse::<f32>().ok().filter(|x| x.is_finite()).map(|x| x.clamp(0.0, 2.0)).unwrap_or(1.0),
                "traffic_headlights" => s.traffic_headlights = v.parse::<f32>().ok().filter(|x| x.is_finite()).map(|x| x.clamp(0.0, 2.0)).unwrap_or(1.0),
                "led_glow" | "night_brightness" | "led_mips" | "graphics_api" | "mx_graphics" => s.read_graphics(&k, v),
                "ctrl_off" => s.ctrl_off = v.trim().to_string(),
                "steering_linear" => s.steering_linear = b(v),
                "old_steering" => s.old_steering = b(v),
                "red_steer_spd" => s.red_steer_spd = b(v),
                "ff_invert" => s.ff_invert = b(v),
                "ff_enabled" => s.ff_enabled = b(v),
                "ff_road_vib" => s.ff_road_vib = v.parse::<f32>().ok().filter(|x| x.is_finite()).map(|x| x.clamp(0.0, 4.0)).unwrap_or(s.ff_road_vib),
                "ff_engine_vib" => s.ff_engine_vib = v.parse::<f32>().ok().filter(|x| x.is_finite()).map(|x| x.clamp(0.0, 4.0)).unwrap_or(s.ff_engine_vib),
                "ff_fade" => s.ff_fade = v.parse::<f32>().ok().filter(|x| x.is_finite()).map(|x| x.clamp(0.0, 1.5)).unwrap_or(s.ff_fade),
                "brake_hold" => s.brake_hold = b(v),
                "mouse_steering" => s.mouse_steering = b(v),
                "mouse_right_off" => s.mouse_right_off = b(v),
                "mouse_smooth" => s.mouse_smooth = b(v),
                "mouse_hold" => s.mouse_hold = b(v),
                "mouse_pedals" => s.mouse_pedals = b(v),
                "key_pedal_speed" => s.key_pedal_speed = v.parse::<f32>().ok().filter(|x| x.is_finite()).map(|x| x.clamp(0.25, 2.0)).unwrap_or(s.key_pedal_speed),
                "mouse_pedal_strength" => {
                    s.mouse_pedal_strength = v
                        .parse::<f32>()
                        .ok()
                        .filter(|x| x.is_finite())
                        .map(|x| x.clamp(0.25, 4.0))
                        .unwrap_or(s.mouse_pedal_strength)
                }
                "blinker_cancel" => s.blinker_cancel = b(v),
                "look_sens" => s.look_sens = v.parse::<f32>().ok().filter(|x| x.is_finite()).map(|x| x.clamp(0.1, 2.0)).unwrap_or(s.look_sens),
                "look_smoothing_ms" => s.look_smoothing_ms = v.parse::<f32>().ok().filter(|x| x.is_finite()).map(|x| x.clamp(0.0, 200.0)).unwrap_or(s.look_smoothing_ms),
                "wheel_range" => s.wheel_range = v.parse::<f32>().ok().filter(|x| x.is_finite()).map(|x| x.clamp(90.0, 2880.0)).unwrap_or(s.wheel_range),
                "cab_wheel_rotation" => s.cab_wheel_rotation = cab_wheel_rotation(v.parse::<f32>().unwrap_or(0.0)),
                "wheel_lock" => s.wheel_lock = v.parse::<f32>().ok().filter(|x| x.is_finite()).map(|x| if x < 45.0 { 0.0 } else { x.min(2880.0) }).unwrap_or(s.wheel_lock),
                "camera_collision" => s.camera_collision = b(v),
                "steer_look" => s.steer_look = b(v),
                "steer_look_angle" => s.steer_look_angle = v.parse::<f32>().ok().filter(|x| x.is_finite()).map(|x| x.clamp(0.0, 60.0)).unwrap_or(s.steer_look_angle),
                "steer_look_response" => s.steer_look_response = v.parse::<f32>().ok().filter(|x| x.is_finite()).map(|x| x.clamp(0.05, 1.0)).unwrap_or(s.steer_look_response),
                "head_idle" => s.head_idle = v.parse::<f32>().ok().filter(|x| x.is_finite()).map(|x| x.clamp(0.0, 1.0)).unwrap_or(s.head_idle),
                "head_idle_pace" => s.head_idle_pace = v.parse::<f32>().ok().filter(|x| x.is_finite()).map(|x| x.clamp(0.5, 2.0)).unwrap_or(s.head_idle_pace),
                "head_tracking" => s.head_tracking = b(v),
                "head_tracking_invert" => s.head_tracking_invert = v.to_ascii_lowercase(),
                "head_tracking_yaw_sens" => s.head_tracking_yaw_sens = v.parse::<f32>().ok().filter(|x| x.is_finite()).map(|x| if x <= 2.0 { x * 100.0 } else { x.clamp(0.0, 100.0) }).unwrap_or(s.head_tracking_yaw_sens),
                "head_tracking_pitch_sens" => s.head_tracking_pitch_sens = v.parse::<f32>().ok().filter(|x| x.is_finite()).map(|x| if x <= 2.0 { x * 100.0 } else { x.clamp(0.0, 100.0) }).unwrap_or(s.head_tracking_pitch_sens),
                "head_tracking_roll_sens" => s.head_tracking_roll_sens = v.parse::<f32>().ok().filter(|x| x.is_finite()).map(|x| if x <= 2.0 { x * 100.0 } else { x.clamp(0.0, 100.0) }).unwrap_or(s.head_tracking_roll_sens),
                "head_tracking_x_sens" => s.head_tracking_x_sens = v.parse::<f32>().ok().filter(|x| x.is_finite()).map(|x| if x <= 2.0 { x * 100.0 } else { x.clamp(0.0, 100.0) }).unwrap_or(s.head_tracking_x_sens),
                "head_tracking_y_sens" => s.head_tracking_y_sens = v.parse::<f32>().ok().filter(|x| x.is_finite()).map(|x| if x <= 2.0 { x * 100.0 } else { x.clamp(0.0, 100.0) }).unwrap_or(s.head_tracking_y_sens),
                "head_tracking_z_sens" => s.head_tracking_z_sens = v.parse::<f32>().ok().filter(|x| x.is_finite()).map(|x| if x <= 2.0 { x * 100.0 } else { x.clamp(0.0, 100.0) }).unwrap_or(s.head_tracking_z_sens),
                "head_tracking_invert_yaw" => s.head_tracking_invert_yaw = b(v),
                "head_tracking_invert_pitch" => s.head_tracking_invert_pitch = b(v),
                "head_tracking_invert_roll" => s.head_tracking_invert_roll = b(v),
                "head_tracking_invert_x" => s.head_tracking_invert_x = b(v),
                "head_tracking_invert_y" => s.head_tracking_invert_y = b(v),
                "head_tracking_invert_z" => s.head_tracking_invert_z = b(v),
                "head_tracking_source" | "tobii_edges" | "head_tracking_smoothing" | "head_tracking_dead_zone" | "pause_quick_actions" | "ui_theme_pack" | "zoom_hold_amount" | "zoom_hold_latch" | "flashlight_cursor" => s.read_extra(&k, v),
                "discord_status" => s.discord_status = b(v),
                "discord_app_id" => s.discord_app_id = v.trim().to_string(),
                k if crate::discord::Show::KEYS.contains(&k) => s.discord_show.set(k, b(v)),
                "voice_enabled" | "voice_mode" | "voice_mic_gain" | "voice_threshold_db" | "voice_input_device" | "voice_volume" | "voice_volume_nearby" | "voice_volume_radio" | "voice_range" | "voice_talker_list" | "voice_all_off" => s.read_voice(&k, v),
                "remote_cockpit" => s.remote_cockpit = b(v),
                "remote_cockpit_port" => s.remote_cockpit_port = v.parse::<u16>().ok().filter(|p| *p > 0).unwrap_or(s.remote_cockpit_port),
                "head_tracking_port" => s.head_tracking_port = v.parse::<u16>().ok().filter(|p| *p > 0).unwrap_or(s.head_tracking_port),
                "pedal_throttle" => s.pedal_throttle = v.parse::<f32>().ok().filter(|x| x.is_finite()).map(|x| x.clamp(0.25, 4.0)).unwrap_or(s.pedal_throttle),
                "pedal_brake" => s.pedal_brake = v.parse::<f32>().ok().filter(|x| x.is_finite()).map(|x| x.clamp(0.25, 4.0)).unwrap_or(s.pedal_brake),
                "seat_x" | "seat_y" | "seat_z" => {
                    let k = (k.as_bytes()[5] - b'x') as usize;
                    s.seat[k] = v.parse::<f32>().ok().filter(|x| x.is_finite()).map(|x| x.clamp(-1.5, 1.5)).unwrap_or(0.0);
                }
                "seat_pitch_deg" => s.seat_pitch_deg = v.parse::<f32>().ok().filter(|x| x.is_finite()).map(|x| x.clamp(-45.0, 45.0)).unwrap_or(s.seat_pitch_deg),
                "fov" => s.fov = v.parse::<f32>().ok().filter(|x| x.is_finite()).map(|x| if x < 20.0 { 0.0 } else { x.min(120.0) }).unwrap_or(s.fov),
                "mouse_sens" => s.mouse_sens = v.parse::<f32>().ok().filter(|x| x.is_finite()).map(|x| x.clamp(0.1, 3.0)).unwrap_or(s.mouse_sens),
                "ui_scale_window" => s.ui_scale_window = b(v),
                "notes" => s.notes = b(v),
                "notes_driving" => s.notes_driving = b(v),
                "notes_script" => s.notes_script = b(v),
                "notes_trip" => s.notes_trip = b(v),
                "notes_tickets" => s.notes_tickets = b(v),
                "info_bar" => s.info_bar = b(v),
                k if let Some(at) = crate::ui::SIZE_KEYS.iter().position(|key| *key == k) => s.hud_sizes[at] = v.parse::<f32>().ok().filter(|x| x.is_finite()).map(crate::ui::window_size).unwrap_or(s.hud_sizes[at]),
                "chat_size" => s.chat_size = v.parse::<f32>().ok().filter(|x| x.is_finite()).map(|x| x.clamp(0.5, 3.0)).unwrap_or(s.chat_size),
                "ui_scale" => s.ui_scale = v.parse::<f32>().ok().filter(|x| x.is_finite()).map(|x| x.clamp(0.5, 2.0)).unwrap_or(s.ui_scale),
                "shadow_casters" => s.shadow_casters = if v.eq_ignore_ascii_case("omsi") { "omsi".into() } else { "all".into() },
                "post_aa" => s.post_aa = if matches!(v.to_ascii_lowercase().as_str(), "off" | "0" | "none" | "false") { "off".into() } else { "fxaa".into() },
                "drive_keys" => s.drive_keys = match v.to_ascii_lowercase().as_str() { "wasd" | "arrows" | "omsi" | "simple" => v.to_ascii_lowercase(), _ => s.drive_keys },
                "touch_pedal_length" => s.touch_pedal_length = v.parse::<f32>().ok().filter(|x| x.is_finite()).map(|x| x.clamp(0.8, 1.6)).unwrap_or(s.touch_pedal_length),
                "touch_pedal_deadzone" => s.touch_pedal_deadzone = v.parse::<f32>().ok().filter(|x| x.is_finite()).map(|x| x.clamp(0.0, 0.4)).unwrap_or(s.touch_pedal_deadzone),
                "touch_door_mode" => s.touch_door_mode = if v.eq_ignore_ascii_case("direct") { "direct" } else { "standard" }.into(),
                _ => {}
            }
        }
        if !theme.0 && theme.1 == Some(true) { s.ui_theme = "light".into(); }
        (s.nav_dynamic_arrows, s.nav_map_arrows) = omsi_launcher_lib::route_arrows_from_text(text);
        s.settle_after_reading(graphics, version);
        s
    }

    /// One of Enhanced's light options as a settings file says it (`ray_tracing`, `light_shadows`,
    /// `cloud_shadows`, `light_glow`, `volumetric_fog`).
    fn set_light_option(&mut self, key: &str, v: &str) {
        let on = matches!(v.to_ascii_lowercase().as_str(), "1" | "true" | "on" | "yes");
        match key {
            "ray_tracing" | "rt" => self.ray_tracing_on = on,
            "light_shadows" => self.light_shadows = light_shadows(v).into(),
            "cloud_shadows" => self.cloud_shadows = on,
            "volumetric_fog" => self.volumetric_fog = on,
            _ => self.light_glow = on,
        }
    }

    fn settle_after_reading(&mut self, graphics: Option<String>, version: u32) {
        // `graphics` decides; a file without it (older builds) says only `enhanced`, and
        // its vanilla renderer is what is now called Vanilla+
        self.graphics = graphics.unwrap_or_else(|| if self.enhanced { "enhanced" } else { "vanilla_plus" }.to_string());
        // (a file of the days of Enhanced+ names it as a mode: it is Enhanced with ray tracing on)
        if self.graphics == "enhanced_plus" {
            self.graphics = "enhanced".to_string();
            self.ray_tracing_on = true;
        }
        self.enhanced = self.graphics == "enhanced";
        // Ray tracing traces the sun's shadows, the ambient occlusion and the reflections: they
        // belong to it and cannot be switched off apart
        if self.ray_tracing() {
            self.shadows = true;
            self.ssao = true;
            self.reflections = 1.0;
        }
        if self.classic() {
            self.shadows = false;
            self.ssao = false;
            self.detail_textures = false;
        }
        // Files older than version 2 say `boarding=pay` because that was the launcher's
        // default, not because anybody chose it: passengers then stood at the cash desk
        // waiting for a driver who did not know he had to sell them a ticket.
        if version < 2 && self.boarding == "pay" {
            log::info!("settings: boarding=pay from an old settings file taken as auto (choose pay again in the launcher to keep it)");
            self.boarding = "auto".into();
        }
        if version == 3 && self.passenger_animation == "enhanced" {
            log::info!("settings: passenger_animation=enhanced from a version 3 settings file taken as Original OMSI (choose Natural again to keep it)");
            self.passenger_animation = "original".into();
        }
    }

    /// The settings as the file holds them. The game only ever reads the file - the
    /// launcher's settings page writes it - so this is here for the round-trip test that
    /// every key read is written back.
    #[cfg(test)]
    pub fn to_text(&self) -> String {
        let mut text = format!(
            "# openOMSI settings\nversion={}\nmsaa={}\nanisotropy={}\nssao={}\nshadows={}\nshadow_size={}\nshadow_blobs={}\nlamp_shadows={}\nnavigator={}\nui_opacity={}\nnavigator_corner={}\nboarding={}\ndetail_textures={}\nexact_fare={}\nenhanced={}\ngraphics={}\nvr={}\nvr_scale={}\nfullscreen={}\nvsync={}\nvolume={}\ndrive_keys={}\npost_aa={}\nrender_scale={}\nlanguage={}\ntexture_compression={}\nvideo_memory={}\nauto_clutch={}\nmomentary_gears={}\nmin_obj_size={}\nmax_obj_dist={}\nmax_fps={}\nchat={}\ntooltips={}\nname_tags={}\nshow_fps={}\nclouds={}\npax_density={}\nvol_ai={}\nvol_scenery={}\nmirror_size={}\nmirror_hud={}\nmirror_refresh={}\ndoppler={}\ndriver={}\ndriverview_smooth={}\n",
            SETTINGS_VERSION, self.msaa, self.anisotropy, self.ssao as u8, self.shadows as u8, self.shadow_size, self.shadow_blobs as u8, self.lamp_shadows as u8, self.navigator as u8, self.ui_opacity, self.navigator_corner, self.boarding, self.detail_textures as u8, self.exact_fare as u8, self.enhanced as u8, self.graphics, self.vr as u8, self.vr_scale, self.fullscreen as u8, self.vsync as u8, self.volume, self.drive_keys, self.post_aa, self.render_scale_text(), self.language, self.texture_compression as u8, self.video_memory, self.auto_clutch as u8, self.momentary_gears as u8, self.min_obj_size, if self.max_obj_dist < 0.0 { "auto".to_string() } else { self.max_obj_dist.to_string() }, self.max_fps, self.chat as u8, self.tooltips as u8, self.name_tags as u8, self.show_fps as u8, self.clouds as u8, self.pax_density, self.vol_ai, self.vol_scenery, self.mirror_size, self.mirror_hud, self.mirror_refresh, self.doppler as u8, self.driver as u8, self.driverview_smooth as u8
        );
        text.push_str(&format!(
            "nav_dynamic_arrows={}\nnav_map_arrows={}\n",
            self.nav_dynamic_arrows as u8, self.nav_map_arrows as u8
        ));
        text.push_str(&format!("ui_theme={}\n", self.ui_theme));
        text.push_str(&format!("notes_driving={}\nnotes_script={}\nnotes_trip={}\nnotes_tickets={}\n", self.notes_driving as u8, self.notes_script as u8, self.notes_trip as u8, self.notes_tickets as u8));
        text.push_str(&format!(
            "vr_head_smoothing_ms={}\nvr_mirror_rate={}\nvr_desktop_mirror={}\nled_glow={}\nled_mips={}\nnight_brightness={}\nui_scale={}\nui_scale_window={}\nchat_size={}\nnotes={}\nff_road_vib={}\nff_engine_vib={}\nff_fade={}\nrealistic_road_physics={}\n",
            self.vr_head_smoothing_ms, self.vr_mirror_rate, self.vr_desktop_mirror as u8, self.led_glow, self.led_mips, self.night_brightness, self.ui_scale, self.ui_scale_window as u8, self.chat_size, self.notes as u8, self.ff_road_vib, self.ff_engine_vib, self.ff_fade, self.realistic_road_physics as u8,
        ));
        text.push_str(&format!("pause_quick_actions={}\nnav_classic_2d={}\nui_theme_pack={}\n", self.pause_quick_actions, self.nav_classic_2d as u8, if self.ui_theme_pack.is_empty() { crate::themes::OWN } else { &self.ui_theme_pack }));
        text.push_str(&format!("upscaler={}\nupscale_quality={}\nframe_generation={}\nfsr_quality={}\nfsr_sharpness={}\n", self.upscaler, self.upscale_quality, self.frame_generation, self.fsr_quality, self.fsr_sharpness));
        text.push_str(&format!("road_glare={}\ntraffic_headlights={}\n", self.road_glare, self.traffic_headlights));
        text.push_str(&format!("mouse_pedal_strength={}\n", self.mouse_pedal_strength));
        text.push_str(&format!("pax_bad_driving={}\n", self.pax_bad_driving as u8));
        text.push_str(&format!("pax_board_when_stopped={}\n", self.pax_board_when_stopped as u8));
        text.push_str(&format!("auto_announce={}\n", self.auto_announce as u8));
        text.push_str(&format!(
            "triple_hud_center={}\ntriple_fov_deg={}\nfov={}\n",
            self.triple_hud_center as u8, self.triple.fov_deg, self.fov
        ));
        text.push_str(&format!("triple_screen={}\ntriple_span={}\ntriple_width_mm={}\ntriple_distance_mm={}\ntriple_bezel_mm={}\ntriple_left_angle_deg={}\ntriple_right_angle_deg={}\ntriple_eye_height_mm={}\n", self.triple.enabled as u8, self.triple_span as u8, self.triple.width_mm, self.triple.distance_mm, self.triple.bezel_mm, self.triple.left_angle_deg, self.triple.right_angle_deg, self.triple.eye_height_mm));
        text.push_str(&format!("steer_look={}\nsteer_look_angle={}\nsteer_look_response={}\nhead_idle={}\nhead_idle_pace={}\nlook_sens={}\nlook_smoothing_ms={}\nblinker_cancel={}\nzoom_hold_amount={}\nzoom_hold_latch={}\nflashlight_cursor={}\n", self.steer_look as u8, self.steer_look_angle, self.steer_look_response, self.head_idle, self.head_idle_pace, self.look_sens, self.look_smoothing_ms, self.blinker_cancel as u8, self.zoom_hold_amount, self.zoom_hold_latch as u8, self.flashlight_cursor as u8));
        text.push_str(&format!("seat_pitch_deg={}\n", self.seat_pitch_deg));
        text.push_str(&format!("cab_wheel_rotation={}\n", self.cab_wheel_rotation));
        text.push_str(&format!("head_tracking_yaw_sens={}\nhead_tracking_pitch_sens={}\nhead_tracking_roll_sens={}\nhead_tracking_x_sens={}\nhead_tracking_y_sens={}\nhead_tracking_z_sens={}\nhead_tracking_invert_yaw={}\nhead_tracking_invert_pitch={}\nhead_tracking_invert_roll={}\nhead_tracking_invert_x={}\nhead_tracking_invert_y={}\nhead_tracking_invert_z={}\n", self.head_tracking_yaw_sens, self.head_tracking_pitch_sens, self.head_tracking_roll_sens, self.head_tracking_x_sens, self.head_tracking_y_sens, self.head_tracking_z_sens, self.head_tracking_invert_yaw as u8, self.head_tracking_invert_pitch as u8, self.head_tracking_invert_roll as u8, self.head_tracking_invert_x as u8, self.head_tracking_invert_y as u8, self.head_tracking_invert_z as u8));
        text.push_str(&format!("head_tracking_source={}\ntobii_edges={}\nhead_tracking_smoothing={}\nhead_tracking_dead_zone={}\n", self.head_tracking_source, self.tobii_edges as u8, self.head_tracking_smoothing, self.head_tracking_dead_zone));
        text.push_str(&format!("discord_status={}\ndiscord_app_id={}\n", self.discord_status as u8, self.discord_app_id));
        text.push_str(&self.discord_show.to_text());
        text.push_str(&format!("auto_shift={}\n", self.auto_shift as u8));
        text.push_str(&format!("sim_thread={}\n", self.sim_thread as u8));
        text.push_str(&format!("mx_graphics={}\n", self.mx_graphics as u8));
        text.push_str(&format!("vehicle_smoke={}\n", self.vehicle_smoke));
        text.push_str(&format!("touch_door_mode={}\n", self.touch_door_mode));
        text.push_str(&format!("touch_pedal_length={}\ntouch_pedal_deadzone={}\n", self.touch_pedal_length, self.touch_pedal_deadzone));
        text.push_str(&format!("right_stick_look={}\n", self.right_stick_look as u8));
        text.push_str(&format!("ctrl_background={}\n", self.ctrl_background as u8));
        text.push_str(&format!("pad_steer_smooth={}\n", self.pad_steer_smooth));
        text.push_str(&format!("pad_steer_linear={}\n", self.pad_steer_linear as u8));
        text.push_str(&format!("pad_steer_speed={}\n", self.pad_steer_speed));
        text.push_str(&format!("pad_deadzone={}\n", self.pad_deadzone));
        text.push_str(&format!("pad_type={}\n", self.pad_type));
        text.push_str(&format!("pad_buttons={}\n", self.pad_buttons as u8));
        text.push_str(&format!("arrows_switch_cams={}\n", self.arrows_switch_cams as u8));
        text.push_str(&format!("voice_enabled={}\nvoice_mode={}\nvoice_mic_gain={}\nvoice_threshold_db={}\nvoice_input_device={}\n", self.voice_enabled as u8, self.voice_mode, self.voice_mic_gain, self.voice_threshold_db, self.voice_input_device));
        text.push_str(&format!("voice_volume={}\nvoice_volume_nearby={}\nvoice_volume_radio={}\nvoice_range={}\nvoice_talker_list={}\nvoice_all_off={}\n", self.voice_volume, self.voice_volume_nearby, self.voice_volume_radio, self.voice_range, self.voice_talker_list as u8, self.voice_all_off as u8));
        text.push_str(&format!("remote_cockpit={}\nremote_cockpit_port={}\n", self.remote_cockpit as u8, self.remote_cockpit_port));
        text.push_str(&format!("windy_trees={}\n", self.windy_trees as u8));
        text.push_str(&format!("rain_lights={}\n", self.rain_lights as u8));
        text.push_str(&format!("detailed_trees={}\n", self.detailed_trees as u8));
        text.push_str(&format!("road_snow={}\n", self.road_snow as u8));
        text.push_str(&format!("mirror_hud_every_frame={}\n", self.mirror_hud_every_frame as u8));
        text.push_str(&format!("mirror_quality={}\n", self.mirror_quality));
        text.push_str(&format!("mirror_shadows={}\nmirror_particles={}\n", self.mirror_shadows as u8, self.mirror_particles as u8));
        text.push_str(&format!("perf_overlay={}\n", self.perf_overlay));
        text.push_str(&format!("standing_chance={}\n", (self.standing_chance * 100.0).round() as i32));
        text.push_str(&format!("ambient={}\nvol_ambient={}\n", self.ambient as u8, self.vol_ambient));
        text.push_str(&format!("radio_speaker={}\nradio_hiss={}\nradio_dropouts={}\n", self.radio_fx.speaker, self.radio_fx.hiss, self.radio_fx.dropouts));
        text.push_str(&format!("cloud_quality={}\n", self.cloud_quality));
        text.push_str(&format!("street_light={}\n", self.street_light));
        text.push_str(&format!("ray_tracing={}\nlight_shadows={}\ncloud_shadows={}\nlight_glow={}\nvolumetric_fog={}\n", self.ray_tracing_on as u8, self.light_shadows, self.cloud_shadows as u8, self.light_glow as u8, self.volumetric_fog as u8));
        text.push_str(&format!("rain_quality={}\n", self.rain_quality));
        text.push_str(&format!("puddles={}\n", self.puddles));
        text.push_str(&format!("gpu_texture_compression={}\n", self.gpu_texture_compression as u8));
        text.push_str(&format!("passenger_animation={}\n", self.passenger_animation));
        text.push_str(&format!("passenger_connections={}\npassenger_transfer_percent={}\n", self.passenger_connections as u8, self.passenger_transfer_percent));
        text.push_str(&format!("passenger_hailing={}\n", self.passenger_hailing as u8));
        text.push_str(&format!("passenger_full_bus_reaction={}\n", self.passenger_full_bus_reaction as u8));
        text.push_str(&format!("pax_short_rides_stand={}\n", self.pax_short_rides_stand as u8));
        text.push_str(&format!("photo_mode={}\n", self.photo_mode));
        text.push_str(&format!("character_models={}\n", self.character_models));
        text.push_str(&format!("units={}\n", self.units));
        text
    }

    /// Real-Time Ray Tracing, with Enhanced graphics: ray-traced sun shadows, ambient occlusion
    /// and reflections (and the graded look that goes with them).
    pub fn ray_tracing(&self) -> bool {
        self.graphics == "enhanced" && self.ray_tracing_on
    }

    /// The graphics mode the renderer runs in, ray tracing counted as a mode of its own: `vanilla`,
    /// `vanilla_plus`, `enhanced` or `enhanced_plus` (Enhanced with Real-Time Ray Tracing).
    pub fn mode(&self) -> &'static str {
        if self.ray_tracing() { "enhanced_plus" } else { graphics_mode(&self.graphics) }
    }

    /// Windy trees, unless `OMSI_WINDY_TREES=0`/`1` says otherwise (A/B renders).
    pub fn windy_trees(&self) -> bool {
        match omsi_cfg::flags::OMSI_WINDY_TREES.var() {
            Some(v) => v.trim() != "0",
            None => self.windy_trees,
        }
    }

    /// Vanilla graphics: the picture as OMSI 2 draws it.
    pub fn classic(&self) -> bool {
        self.graphics == "vanilla"
    }

    /// How far objects are drawn (m, 0 = no limit): `max_obj_dist`, or when that is `auto`
    /// the visible distance the launcher sets, else the original's 900 m.
    pub fn object_distance(&self) -> f32 {
        if self.max_obj_dist >= 0.0 {
            self.max_obj_dist
        } else {
            view_distance().map(|v| v as f32).unwrap_or(900.0)
        }
    }

    /// `auto` or the fraction, as the file and the log write it.
    pub fn render_scale_text(&self) -> String {
        if self.render_scale > 0.0 { format!("{}", self.render_scale) } else { "auto".into() }
    }

    /// Lighter graphics after the graphics device was lost `n` times this session: no
    /// multisampling, no SSAO, smaller shadow and mirror maps, fewer textures kept; a second
    /// loss also a smaller picture and no shadows.
    pub fn apply_safe_gpu(&mut self, n: u32) {
        self.msaa = 1;
        self.ssao = false;
        if omsi_render::TemporalUpscaler::parse(&self.upscaler).is_some() {
            self.upscaler = "default".into();
        }
        self.frame_generation = "off".into();
        self.shadow_size = self.shadow_size.min(2048);
        self.mirror_size = self.mirror_size.min(256);
        // (the Enhanced extras are what the driver gave up on in the reports of 0.3.42: they
        // go at once, the mode itself after a second loss)
        self.ray_tracing_on = false;
        self.cloud_shadows = false;
        self.light_glow = false;
        self.volumetric_fog = false;
        self.lamp_shadows = false;
        if self.light_shadows == "all" {
            self.light_shadows = "street".into();
        }
        if n >= 2 {
            if graphics_mode(&self.graphics) == "enhanced" {
                self.graphics = "vanilla_plus".into();
            }
            self.light_shadows = "off".into();
            self.shadows = false;
            self.shadow_size = 1024;
            self.render_scale = if self.render_scale > 0.0 { self.render_scale.min(0.75) } else { 0.75 };
            self.mirror_size = self.mirror_size.min(128);
        }
        log::warn!("safer graphics after a lost graphics device ({n}): msaa 1, SSAO off, shadows {} ({}), video memory {} of its limit, render scale {}", self.shadows, self.shadow_size, if n >= 2 { "half" } else { "two thirds" }, self.render_scale_text());
    }

    /// The render scale the picture is drawn at: FSR 1's quality's, or the render scale's (0:
    /// automatic, the frame-rate governor's).
    pub fn scene_render_scale(&self) -> f32 {
        if self.upscaler != "fsr1" {
            return self.render_scale;
        }
        let preset: f32 = match self.fsr_quality.as_str() {
            "ultra" => 0.77,
            "balanced" => 0.59,
            "performance" => 0.5,
            "custom" => return self.render_scale,
            // (the frame-rate governor picks the size, FSR 1 scales it up)
            "auto" => return 0.0,
            _ => 0.67,
        };
        // (a render scale set below the preset's - by the optimiser, or the safer graphics
        // after a lost device - still caps it)
        if self.render_scale > 0.0 { preset.min(self.render_scale) } else { preset }
    }

    pub fn temporal_upscaling(&self) -> Option<omsi_render::Temporal> {
        let upscaler = omsi_render::TemporalUpscaler::parse(&self.upscaler).filter(|_| !self.vr_requested() && !self.triple.enabled)?;
        let files = omsi_cfg::upscaler_files::available(&omsi_cfg::upscaler_files::program_dir());
        files.contains(&upscaler.as_str()).then(|| omsi_render::Temporal { upscaler, quality: omsi_render::TemporalQuality::parse(&self.upscale_quality) })
    }

    /// Frame generation as asked for, with the upscaler it works with chosen (asked every frame:
    /// no file is looked at; whether the Mac can run it is found when it starts).
    pub fn frame_generation(&self) -> bool {
        self.frame_generation_kind().is_some()
    }

    /// The frame generation asked for, where its upscaler is the one chosen.
    pub fn frame_generation_kind(&self) -> Option<omsi_render::FrameGenerationKind> {
        let upscaler = omsi_render::TemporalUpscaler::parse(&self.upscaler)
            .filter(|_| !self.vr_requested() && !self.triple.enabled);
        omsi_render::FrameGenerationKind::parse(&self.frame_generation)
            .filter(|k| upscaler == Some(k.upscaler()))
    }

    pub fn render_options(&self) -> omsi_render::RenderOptions {
        let fsr1 = self.upscaler == "fsr1";
        let render_scale = self.scene_render_scale();
        omsi_render::RenderOptions { msaa: self.msaa, msaa_fallback: 0, anisotropy: self.anisotropy, shadow_size: self.shadow_size, ssao: self.ssao, render_scale, fsr1, temporal: self.temporal_upscaling(), fsr_sharpness: self.fsr_sharpness, xr_scale: 1.0, compress_textures: self.texture_compression, gpu_texture_compression: self.gpu_texture_compression, fxaa: self.post_aa != "off", min_obj_size: self.min_obj_size, max_obj_dist: self.object_distance(), mirror_enhanced: self.mirror_quality == "enhanced", mirror_shadows: self.mirror_shadows, mirror_particles: self.mirror_particles, omsi_shadow_casters: self.shadow_casters == "omsi", shadow_blobs: self.shadow_blobs, reflections: self.reflections > 0.0, preview_only: false, no_enhanced: !matches!(graphics_mode(&self.graphics), "enhanced" | "enhanced_plus"), ray_tracing: self.ray_tracing(), light_shadows: match self.light_shadows.as_str() { "off" => 0, "all" => 2, _ => 1 }, cloud_shadows: self.cloud_shadows, light_glow: self.light_glow, volumetric_fog: self.volumetric_fog, street_light: match self.street_light.as_str() { "on" => Some(true), "off" => Some(false), _ => None }, puddle_reflections: true, max_scene: None, detailed_trees: self.detailed_trees }
    }
}

/// `vanilla`, `vanilla_plus`, `enhanced` or `enhanced_plus` from the ways a file may spell them.
#[rustfmt::skip]
pub fn graphics_mode(v: &str) -> &'static str {
    match v.trim().to_ascii_lowercase().replace(['-', ' '], "_").as_str() {
        "enhanced_plus" | "enhanced+" | "enhancedplus" | "enhanced_+" | "2" => "enhanced_plus",
        "enhanced" | "1" => "enhanced",
        "vanilla" | "classic" | "original" | "omsi" | "omsi2" | "omsi_2" => "vanilla",
        _ => "vanilla_plus",
    }
}

/// `gpu_texture_compression` from a settings file: on unless it says off (`0`, `off`, `no`,
/// `false`, or a test build's `disabled`).
#[rustfmt::skip]
pub fn gpu_texture_compression(v: &str) -> bool {
    !matches!(v.trim().to_ascii_lowercase().as_str(), "0" | "off" | "no" | "false" | "disabled")
}

/// The setting `cab_wheel_rotation` from a value (degrees lock to lock), as the launcher
/// reads it: under 90 (or not a number) 0, the bus's own animation; else rounded and kept
/// within 180..=1800.
#[rustfmt::skip]
pub fn cab_wheel_rotation(v: f32) -> u32 {
    if !v.is_finite() || v < 90.0 {
        0
    } else {
        v.round().clamp(180.0, 1800.0) as u32
    }
}

/// The setting `pad_type`: `xbox`, `ps4`, `ps5`, else `auto`.
#[rustfmt::skip]
pub fn pad_type(v: &str) -> &'static str {
    match v.trim().to_ascii_lowercase().as_str() {
        "xbox" => "xbox",
        "ps4" => "ps4",
        "ps5" => "ps5",
        _ => "auto",
    }
}

/// The enhanced clouds' quality from a settings file: `low`, else `high` (an `auto` written by
/// a test build reads as the default too).
#[rustfmt::skip]
pub fn cloud_quality(v: &str) -> &'static str {
    if v.trim().eq_ignore_ascii_case("low") { "low" } else { "high" }
}

/// Which lights cast shadows, from a settings file: `off` or `all`, else `street`.
#[rustfmt::skip]
pub fn light_shadows(v: &str) -> &'static str {
    match v.trim().to_ascii_lowercase().as_str() {
        "off" | "0" | "none" | "false" => "off",
        "all" | "2" | "every" | "max" => "all",
        _ => "street",
    }
}

/// The street-scale light from a settings file: `on` or `off`, else `auto`.
#[rustfmt::skip]
pub fn street_light(v: &str) -> &'static str {
    match v.trim().to_ascii_lowercase().as_str() {
        "on" | "1" | "true" => "on",
        "off" | "0" | "false" => "off",
        _ => "auto",
    }
}

/// The rain's quality from a settings file: `medium` or `low`, else `high`.
#[rustfmt::skip]
pub fn rain_quality(v: &str) -> &'static str {
    match v.trim().to_ascii_lowercase().as_str() {
        "medium" => "medium",
        "low" => "low",
        _ => "high",
    }
}

/// `view_distance=<metres>` of the settings file: how far around the camera the map's tiles
/// are kept loaded (OMSI's "visible distance"). None when the file does not say.
#[rustfmt::skip]
pub fn view_distance() -> Option<f64> {
    let text = std::fs::read_to_string(Settings::path()?).ok()?;
    text.lines().filter_map(|l| l.trim().split_once('=')).find(|(k, _)| k.trim().eq_ignore_ascii_case("view_distance")).and_then(|(_, v)| v.trim().parse::<f64>().ok()).filter(|v| *v > 0.0)
}

#[cfg(test)]
#[rustfmt::skip]
mod tests;

#[rustfmt::skip]
impl Settings {
    /// The player's bus's `wearlifespan` for the maintenance condition (OMSI's table).
    pub fn wear_lifespan(&self) -> f32 {
        [1.5e6, 0.01, 0.1, 1.0, 10.0][self.maintenance.min(4) as usize]
    }
}

/// The player's own turn of a bus's mirrors (degrees yaw, pitch per `[add_camera_reflexion]`),
/// kept per `.bus` file in `~/.openomsi/mirrors.cfg` as `<bus file>|<mirror>=<yaw>,<pitch>`.
#[rustfmt::skip]
pub fn mirror_offsets(bus: &std::path::Path) -> Vec<[f32; 2]> {
    let key = bus.to_string_lossy().to_ascii_lowercase();
    let Some(p) = Settings::path().map(|p| p.with_file_name("mirrors.cfg")) else { return Vec::new() };
    let text = std::fs::read_to_string(p).unwrap_or_default();
    let mut out: Vec<[f32; 2]> = Vec::new();
    for line in text.lines() {
        let Some((k, v)) = line.rsplit_once('=') else { continue };
        let Some((file, i)) = k.rsplit_once('|') else { continue };
        let (Ok(i), Some((y, p))) = (i.trim().parse::<usize>(), v.split_once(',')) else { continue };
        if file.trim().to_ascii_lowercase() != key || i > 64 {
            continue;
        }
        if out.len() <= i {
            out.resize(i + 1, [0.0; 2]);
        }
        out[i] = [y.trim().parse().unwrap_or(0.0), p.trim().parse().unwrap_or(0.0)];
    }
    out
}

/// A bus's mirror shifts (bus frame, m: across, along, up), kept in the same file as the
/// turns on lines `<bus>|s<n>=x,y,z` (a build that knows only turns skips them).
#[rustfmt::skip]
pub fn mirror_shifts(bus: &std::path::Path) -> Vec<[f32; 3]> {
    let key = bus.to_string_lossy().to_ascii_lowercase();
    let Some(p) = Settings::path().map(|p| p.with_file_name("mirrors.cfg")) else { return Vec::new() };
    let text = std::fs::read_to_string(p).unwrap_or_default();
    let mut out: Vec<[f32; 3]> = Vec::new();
    for line in text.lines() {
        let Some((k, v)) = line.rsplit_once('=') else { continue };
        let Some((file, i)) = k.rsplit_once('|') else { continue };
        let Some(i) = i.trim().strip_prefix('s').and_then(|n| n.parse::<usize>().ok()) else { continue };
        let xyz: Vec<f32> = v.split(',').filter_map(|s| s.trim().parse().ok()).collect();
        if file.trim().to_ascii_lowercase() != key || i > 64 || xyz.len() != 3 {
            continue;
        }
        if out.len() <= i {
            out.resize(i + 1, [0.0; 3]);
        }
        out[i] = [xyz[0], xyz[1], xyz[2]];
    }
    out
}

/// A bus's mirror field-of-view changes (degrees added to the mirror camera's), on lines
/// `<bus>|f<n>=degrees` of the same file.
#[rustfmt::skip]
pub fn mirror_fovs(bus: &std::path::Path) -> Vec<f32> {
    let key = bus.to_string_lossy().to_ascii_lowercase();
    let Some(p) = Settings::path().map(|p| p.with_file_name("mirrors.cfg")) else { return Vec::new() };
    let text = std::fs::read_to_string(p).unwrap_or_default();
    let mut out: Vec<f32> = Vec::new();
    for line in text.lines() {
        let Some((k, v)) = line.rsplit_once('=') else { continue };
        let Some((file, i)) = k.rsplit_once('|') else { continue };
        let Some(i) = i.trim().strip_prefix('f').and_then(|n| n.parse::<usize>().ok()) else { continue };
        let Ok(d) = v.trim().parse::<f32>() else { continue };
        if file.trim().to_ascii_lowercase() != key || i > 64 {
            continue;
        }
        if out.len() <= i {
            out.resize(i + 1, 0.0);
        }
        out[i] = d.clamp(-60.0, 60.0);
    }
    out
}

/// Keep a bus's mirror turns, shifts and field-of-view changes (see [`mirror_offsets`],
/// [`mirror_shifts`], [`mirror_fovs`]).
#[rustfmt::skip]
pub fn save_mirror_state(bus: &std::path::Path, offsets: &[[f32; 2]], shifts: &[[f32; 3]], fovs: &[f32]) {
    let key = bus.to_string_lossy().to_ascii_lowercase();
    let Some(p) = Settings::path().map(|p| p.with_file_name("mirrors.cfg")) else { return };
    let text = std::fs::read_to_string(&p).unwrap_or_default();
    let mut lines: Vec<String> = text
        .lines()
        .filter(|l| l.rsplit_once('=').and_then(|(k, _)| k.rsplit_once('|')).is_none_or(|(f, _)| f.trim().to_ascii_lowercase() != key))
        .map(str::to_string)
        .collect();
    for (i, o) in offsets.iter().enumerate() {
        if o[0].abs() > 0.01 || o[1].abs() > 0.01 {
            lines.push(format!("{}|{i}={:.1},{:.1}", bus.to_string_lossy(), o[0], o[1]));
        }
    }
    for (i, s) in shifts.iter().enumerate() {
        if s.iter().any(|v| v.abs() > 0.002) {
            lines.push(format!("{}|s{i}={:.3},{:.3},{:.3}", bus.to_string_lossy(), s[0], s[1], s[2]));
        }
    }
    for (i, d) in fovs.iter().enumerate() {
        if d.abs() > 0.05 {
            lines.push(format!("{}|f{i}={:.1}", bus.to_string_lossy(), d));
        }
    }
    if let Some(d) = p.parent() {
        let _ = std::fs::create_dir_all(d);
    }
    let _ = std::fs::write(&p, lines.join("\n") + "\n");
}
/// `resolution=` (or `window_size=`) of a settings text, the last one written.
#[rustfmt::skip]
pub fn resolution_of(text: &str) -> Option<(u32, u32)> {
    let v = text.lines().filter_map(|l| l.split_once('=')).filter(|(k, _)| matches!(k.trim().to_ascii_lowercase().as_str(), "resolution" | "window_size")).last()?.1;
    let (w, h) = omsi_launcher_lib::resolution_text(v).split_once('x').map(|(w, h)| (w.parse().ok(), h.parse().ok()))?;
    Some((w?, h?))
}

#[rustfmt::skip]
pub fn fullscreen_scene_cap(fullscreen: bool, spanned: bool, resolution: Option<(u32, u32)>) -> Option<(u32, u32)> {
    resolution.filter(|_| fullscreen && !spanned)
}

#[cfg(test)]
#[rustfmt::skip]
mod resolution_tests {
    #[test]
    fn the_window_size_is_read_from_the_settings() {
        assert_eq!(super::resolution_of("msaa=4\nresolution=1280x800\n"), Some((1280, 800)));
        assert_eq!(super::resolution_of("resolution=auto\n"), None);
        assert_eq!(super::resolution_of("window_size=1920*1080\n"), Some((1920, 1080)));
        assert_eq!(super::resolution_of("vsync=1\n"), None);
    }

    #[test]
    fn the_scene_cap_follows_fullscreen_both_ways() {
        let set = Some((1280, 720));
        assert_eq!(super::fullscreen_scene_cap(true, false, set), set);
        assert_eq!(super::fullscreen_scene_cap(false, false, set), None);
        assert_eq!(super::fullscreen_scene_cap(true, true, set), None);
        assert_eq!(super::fullscreen_scene_cap(true, false, None), None);
    }
}

#[cfg(test)]
#[rustfmt::skip]
mod right_stick_look_tests;
#[cfg(test)]
#[rustfmt::skip]
mod sim_thread_tests;
#[cfg(test)]
#[rustfmt::skip]
mod full_tank_tests;
#[cfg(test)]
#[rustfmt::skip]
mod road_snow_tests;

/// The driver's seat per bus (`~/.openomsi/seats.cfg`, a line `bus|x|y|z|pitch` each, the
/// bus by its `.bus` file relative to the installation, lower case). The seat set in the
/// menu was one for every bus: fitted to a Solaris, every other bus put the driver
/// somewhere else than its `.bus` file does (#1355). A bus that has none takes the
/// settings' own seat, which is where a seat set before this lives on.
#[path = "settings/bus_seats.rs"]
#[rustfmt::skip]
pub mod bus_seats;

#[cfg(test)]
#[path = "settings/passenger_connections_tests.rs"]
#[rustfmt::skip]
mod passenger_connections_tests;
