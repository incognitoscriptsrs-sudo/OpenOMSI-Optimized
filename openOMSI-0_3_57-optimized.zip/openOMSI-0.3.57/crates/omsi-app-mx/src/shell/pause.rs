//! The pause menu as a page of the launcher: the launcher's rail on the left with the
//! menu's lines as its pages, the picture of the game beside it, and a list or settings
//! window opened from the rail shown as a launcher page right of it - a title, the tabs as
//! the launcher's segmented bar, the rows in panels of two columns with the launcher's
//! fields, switches and sliders.
//!
//! What a row is comes from `game_lists` as before (`name\u{1f}kind\u{1f}value\u{1f}
//! description\u{1f}fraction`, see `ui::MenuKind::Options`); what a click does goes back to
//! the game as an [`Action`].

pub(crate) mod navigation;
mod navigation_ui;
pub(crate) mod online_ui;
pub(crate) mod quick_actions;
mod quick_actions_ui;
pub(crate) mod search;
mod vehicles;

use glam::Vec2;
use omsi_settings_ui::parse_row;
use omsi_ui::paint::Align;
use omsi_ui::{Color, Rect, Weight};
use std::borrow::Cow;

use super::{Action, Shell};
use crate::ui::{DropdownView, MenuKind, Preview};
use omsi_ui::kit::{ButtonKind, Ui, id_of};
use omsi_ui::theme::*;

/// The paused game, dimmed, behind a category page; a list or a settings window has the
/// background solid behind it. In a glass theme the picture is dimmed only a little behind the
/// rail alone, and blurred under some of the background behind a page.
const PAGE_VEIL: f32 = 0.72;
const HOME_VEIL: f32 = 0.85;
const GLASS_HOME_VEIL: f32 = 0.3;
const GLASS_PAGE_VEIL: f32 = 0.5;
/// Compact margins for the existing settings and list pages.
const NARROW: f32 = 560.0;
/// A list's row.
const LIST_ROW: f32 = 40.0;

/// An open list or settings window, as the game has it.
pub(crate) struct ListView<'a> {
    pub kind: MenuKind,
    pub head: Option<(String, String)>,
    pub badge: Option<usize>,
    pub tabs: Option<(Vec<String>, usize)>,
    /// (what it does, what it shows)
    pub items: Vec<(&'a str, &'a str)>,
    pub sel: usize,
    pub preview: Option<&'a Preview>,
    pub pane_first: Option<usize>,
    pub dropdown: Option<DropdownView<'a>>,
    /// Names the list for its scroll position (its kind and page).
    pub key: String,
}

/// What the pause menu shows.
pub(crate) struct PauseView<'a> {
    pub paused: bool,
    pub quick_actions: &'a str,
    /// The game menu's lines.
    pub rail: &'a [crate::app_impl::MenuLine],
    /// The line the keyboard is on (the game menu's, while no list is open).
    pub rail_sel: Option<usize>,
    pub disabled: &'a [&'a str],
    pub list: Option<ListView<'a>>,
    /// The keyboard chose last: its line is shown lit.
    pub kbd: bool,
    /// Key hints (a keyboard is there).
    pub keys: bool,
    /// What the home page sums up of the session.
    pub summary: Summary,
    pub online: online_ui::View,
}

/// The session as the pause menu's sidebar shows it: the bus and the driver.
#[derive(Default)]
pub(crate) struct Summary {
    pub bus: String,
    pub driver: String,
}

/// The Material icon of a line of the game menu (the launcher's icon set).
pub(crate) fn rail_icon(id: &str) -> &'static str {
    match id {
        "resume" => "play_arrow",
        "tobus" => "directions_bus",
        "options" => "settings",
        "controls" => "sports_esports",
        "camera" => "videocam",
        "photo" | "shot" => "photo_camera",
        "vehicle" => "airport_shuttle",
        "world" => "partly_cloudy_day",
        "map" => "map",
        "streets" => "search",
        "duty" => "departure_board",
        "skipstop" => "near_me",
        "endduty" => "sports_score",
        "save" => "save",
        "saveslot" => "add",
        "load" => "history",
        "copycode" => "content_copy",
        "admin" => "key",
        "players" | "multiplayer" => "group",
        "plugin" => "extension",
        "quit" => "logout",
        _ => "chevron_right",
    }
}

/// A label without the "..." that says it opens more.
fn plain(label: &str) -> (&str, bool) {
    let t = label.trim_end();
    match t.strip_suffix("...").or_else(|| t.strip_suffix('…')) {
        Some(x) => (x.trim_end(), true),
        None => (t, false),
    }
}

fn count_badge_rect(
    title_width: f32,
    badge_width: f32,
    title_x: f32,
    right: f32,
    y: f32,
) -> Option<Rect> {
    let x = title_x + title_width + 12.0;
    (x + badge_width <= right).then(|| Rect::new(x, y + 9.0, badge_width, 22.0))
}

pub(crate) fn draw(sh: &mut Shell, v: &PauseView) {
    if sh.pause_category != navigation::Category::Online {
        sh.pause_online.confirm = None;
        sh.pause_online.management = None;
    }
    let saved_click = (sh.ui.input.pressed, sh.ui.input.released);
    let management_open = sh.pause_online.management.is_some();
    let saved_wheel = sh.ui.input.wheel;
    if management_open {
        sh.ui.input.wheel = Vec2::ZERO;
    }
    if sh.pause_online.confirm.is_some() || management_open {
        sh.ui.input.pressed = false;
        sh.ui.input.released = false;
    }

    if !v
        .list
        .as_ref()
        .is_some_and(|list| list.kind == MenuKind::Options)
    {
        if sh.ui.focus == Some(id_of("pause-settings-search")) {
            sh.ui.focus = None;
        }
        sh.settings_search = Default::default();
    }
    let size = sh.ui.size;
    // Drawing a submenu must not change the category that opened it.
    let sidebar = size.x >= if v.list.is_some() { NARROW } else { 700.0 };
    let left = if sidebar { RAIL_W } else { 0.0 };
    let page = Rect::new(left, 0.0, (size.x - left).max(0.0), size.y);
    sh.ui.solid(page);
    let bg = th().bg;
    let solid = !(sh.pause_hidden && v.list.is_none());
    match (th().glass, sh.ui.backdrop) {
        (Some(_), Some(tex)) if solid => {
            let all = Rect::new(0.0, 0.0, size.x, size.y);
            sh.ui.image(all, tex, 0.0);
            sh.ui.p().rect(all, bg.alpha(GLASS_PAGE_VEIL));
        }
        // (the blurred picture not there yet: as good as solid)
        (Some(_), _) => sh.ui.p().rect(
            page,
            bg.alpha(if solid { HOME_VEIL } else { GLASS_HOME_VEIL }),
        ),
        (None, _) => sh.ui.p().rect(
            page,
            if v.list.is_some() {
                bg
            } else {
                bg.alpha(PAGE_VEIL)
            },
        ),
    }
    if let Some(list) = v.list.as_ref() {
        list_page(sh, v, list, page);
    } else {
        navigation_ui::page(sh, v, page, !sidebar);
    }
    if sidebar {
        navigation_ui::rail(sh, v);
    }
    (sh.ui.input.pressed, sh.ui.input.released) = saved_click;
    if management_open {
        sh.ui.input.wheel = saved_wheel;
        online_ui::management_modal(sh, &v.online);
    }
    online_ui::confirmation(sh);
}

/// The launcher's tabs: the titles in a row, the chosen one in the text colour over an amber
/// line, the others muted. Returns the one clicked, and how many rows they took (a narrow
/// screen has them on a second row: the last ones were cut off and could not be reached).
fn tabs(
    ui: &mut Ui,
    at: Vec2,
    titles: &[String],
    chosen: usize,
    max_w: f32,
) -> (Option<usize>, usize) {
    let mut x = at.x;
    let mut row = 0;
    let mut out = None;
    for (i, t) in titles.iter().enumerate() {
        let w = ui.width(&omsi_ui::tr(t), 14.0, Weight::Medium) + 4.0;
        if x + w > at.x + max_w && x > at.x {
            x = at.x;
            row += 1;
        }
        let r = Rect::new(x, at.y + row as f32 * 38.0, w, 38.0);
        let (h, _, clicked) = ui.interact(id_of(&format!("pause-tab-{i}")), r);
        let on = i == chosen;
        ui.text_in(
            t,
            r,
            14.0,
            Weight::Medium,
            if on || h { th().ink } else { th().ink_muted },
            Align::Center,
        );
        if on {
            ui.p()
                .rect(Rect::new(r.x, r.bottom() - 2.0, r.w, 2.0), th().accent);
        }
        if clicked && !on {
            out = Some(i);
        }
        x += w + 22.0;
    }
    (out, row + 1)
}

/// An open list or settings window as a launcher page right of the rail.
fn list_page(sh: &mut Shell, v: &PauseView, list: &ListView, page: Rect) {
    let margin = if page.w < NARROW { 14.0 } else { 32.0 };
    let w = (page.w - margin * 2.0).min(1400.0);
    let area = Rect::new(
        page.x + margin + ((page.w - margin * 2.0) - w).max(0.0) * 0.5,
        28.0,
        w,
        page.h - 28.0 - 24.0,
    );
    // the title, with the way back before it
    let (title, sub) = list
        .head
        .clone()
        .unwrap_or_else(|| (omsi_ui::tr("Options").into_owned(), String::new()));
    let back_k = list
        .items
        .iter()
        .position(|(id, label)| *id == "back" && plain(label).0 == omsi_ui::tr("Back").as_ref());
    let back = Rect::new(area.x, area.y, 36.0, 36.0);
    if sh
        .ui
        .icon_button("pause-back", back.center(), 18.0, "arrow_back", "Back")
    {
        sh.actions.push(match (&list.tabs, back_k) {
            (Some((t, _)), _) => Action::Side(t.len()),
            (None, Some(k)) => Action::Choose(k),
            (None, None) => Action::Rail(usize::MAX),
        });
    }
    let tx = area.x + 46.0;
    let title_width = if list.kind == MenuKind::Options && area.w >= 760.0 {
        (area.w - 46.0 - (area.w * 0.34).clamp(220.0, 360.0) - 58.0).max(100.0)
    } else {
        area.w - 46.0
    };
    sh.ui.text_in(
        &title,
        Rect::new(tx, area.y + 4.0, title_width, 34.0),
        26.0,
        Weight::Bold,
        th().ink,
        Align::Left,
    );
    if let Some(count) = list.badge {
        let text = count.to_string();
        let badge_width = (sh.ui.width(&text, 12.0, Weight::Medium) + 16.0).max(24.0);
        let title_width = sh.ui.width(&title, 26.0, Weight::Bold);
        if let Some(badge) = count_badge_rect(title_width, badge_width, tx, area.right(), area.y) {
            sh.ui.p().rounded(badge, 6.0, th().accent.alpha(0.16));
            sh.ui.text_in(
                &text,
                badge,
                12.0,
                Weight::Medium,
                th().accent,
                Align::Center,
            );
        }
    }
    let sub = if sub.is_empty() {
        list_hint(list.kind)
    } else {
        sub
    };
    if !sub.is_empty() {
        sh.ui.text_in(
            &sub,
            Rect::new(tx, area.y + 36.0, title_width, 20.0),
            13.0,
            Weight::Regular,
            th().ink_muted,
            Align::Left,
        );
    }
    let mut body = Rect::new(area.x, area.y + 70.0, area.w, (area.h - 70.0).max(40.0));
    if list.kind == MenuKind::Options {
        search::toolbar(sh, list, area, &mut body);
    }
    // the pages of a settings window: the launcher's tabs
    if let Some((titles, at)) = list.tabs.as_ref().filter(|(t, _)| t.len() > 1) {
        let (picked, rows) = tabs(
            &mut sh.ui,
            Vec2::new(body.x, body.y - 6.0),
            titles,
            *at,
            body.w,
        );
        if let Some(tab) = picked {
            sh.actions.push(Action::Side(tab));
        }
        let below = body.y - 6.0 + 38.0 * rows as f32 + 20.0;
        body = Rect::new(body.x, below, body.w, (body.bottom() - below).max(40.0));
    }
    // an open drop-down takes the mouse where it lies (the rows under it do not answer)
    let dd_rect = list.dropdown.as_ref().and_then(|d| {
        sh.dd_anchor
            .map(|a| dropdown_rect(a, d.items.len(), sh.ui.size))
    });
    let mouse = sh.ui.input.mouse;
    let saved = (sh.ui.input.pressed, sh.ui.input.released);
    // Reserve the wheel for the popup before drawing controls underneath it.
    let wheel = sh.ui.input.wheel;
    if list.dropdown.is_some() {
        sh.ui.input.wheel = Vec2::ZERO;
    }
    if let Some(r) = dd_rect {
        if r.contains(mouse) || sh.ui.input.pressed {
            sh.ui.input.pressed = false;
            sh.ui.input.released = false;
        }
    }
    let mut anchor: Option<Rect> = None;
    match list.kind {
        MenuKind::Options | MenuKind::Sections => settings_rows(sh, v, list, body, &mut anchor),
        MenuKind::Lines | MenuKind::Tours => timetable_lists(sh, v, list, body),
        MenuKind::Vehicles => vehicles::draw(sh, v, list, body),
        _ => plain_list(sh, v, list, body),
    }
    (sh.ui.input.pressed, sh.ui.input.released) = saved;
    if list.dropdown.is_some() {
        sh.ui.input.wheel = wheel;
    }
    sh.dd_anchor = anchor;
    if let (Some(d), Some(a)) = (list.dropdown.as_ref(), anchor) {
        dropdown(sh, d, a, v.kbd);
    }
}

/// What a list is for, under its title, when the game gives no line of its own.
fn list_hint(kind: MenuKind) -> String {
    let t = match kind {
        MenuKind::Options => "Every change takes effect at once.",
        MenuKind::Lines => "Choose a line of the map's timetable.",
        MenuKind::Tours => "Choose a tour and the stop to start from.",
        _ => "",
    };
    omsi_ui::tr(t).into_owned()
}

/// How high a row of a settings window is: two lines when it has a description.
fn row_h(id: &str, label: &str) -> f32 {
    if id == crate::game_lists::HEADING {
        return 34.0;
    }
    if parse_row(label).desc.is_empty() {
        ROW + 4.0
    } else {
        52.0
    }
}

/// The rows of a settings window in the launcher's panels: two columns side by side where
/// the page is wide enough, the headings of the list as the panels' section titles.
fn settings_rows(
    sh: &mut Shell,
    v: &PauseView,
    list: &ListView,
    body: Rect,
    anchor: &mut Option<Rect>,
) {
    let items = &list.items;
    let hide_back = list.tabs.is_none();
    let back = hide_back
        .then(|| {
            items.iter().position(|&(id, label)| {
                id == "back" && plain(parse_row(label).name).0 == omsi_ui::tr("Back").as_ref()
            })
        })
        .flatten();
    let groups = omsi_settings_ui::filter_groups(
        items,
        crate::game_lists::HEADING,
        back,
        &sh.settings_search.query,
    );
    sh.settings_search.visible = groups
        .iter()
        .flatten()
        .copied()
        .filter(|&k| items[k].0 != crate::game_lists::HEADING)
        .collect();
    if groups.is_empty() {
        sh.ui.text_in(
            &omsi_ui::tr("No matching settings"),
            body,
            14.0,
            Weight::Regular,
            th().ink_muted,
            Align::Center,
        );
    }
    let two = body.w >= 900.0 && groups.iter().flatten().count() > 6;
    let cols = settings_columns(groups, two, items);
    let any_hover = sh.ui.hover(body);
    let key = format!("pause-list-{}", list.key);
    let mut acts: Vec<Action> = Vec::new();
    let mut sel_y: Option<(f32, f32)> = None;
    let mut dd_anchor: Option<Rect> = None;
    let dd_row = list.dropdown.as_ref().map(|d| d.row);
    sh.ui.scroll_area(&key, body, &mut |ui, view| {
        let gap = GAP * 2.0;
        let cw = if cols.len() == 2 {
            (view.w - 8.0 - gap) / 2.0
        } else {
            (view.w - 8.0).min(760.0)
        };
        let mut tallest = 0.0f32;
        for (c, groups) in cols.iter().enumerate() {
            let x = view.x + c as f32 * (cw + gap);
            let mut y = view.y;
            for rows in groups {
                let h = rows
                    .iter()
                    .map(|&k| row_h(items[k].0, items[k].1))
                    .sum::<f32>()
                    + 28.0;
                ui.panel(Rect::new(x, y, cw, h.max(60.0)));
                let inner = Rect::new(x + 18.0, y + 14.0, cw - 36.0, h - 28.0);
                let mut row_y = inner.y;
                for (n, &k) in rows.iter().enumerate() {
                    let (id, label) = items[k];
                    let rh = row_h(id, label);
                    if id == crate::game_lists::HEADING {
                        let t = omsi_ui::tr(parse_row(label).name);
                        ui.p().rounded(
                            Rect::new(inner.x, row_y + 7.0, 3.0, 20.0),
                            1.5,
                            th().accent,
                        );
                        ui.text_in(
                            &t,
                            Rect::new(inner.x + 12.0, row_y + 4.0, inner.w - 12.0, 28.0),
                            15.0,
                            Weight::Bold,
                            th().ink,
                            Align::Left,
                        );
                        row_y += rh;
                        continue;
                    }
                    if n > 0
                        && items
                            .get(rows[n - 1])
                            .is_some_and(|(pid, _)| *pid != crate::game_lists::HEADING)
                    {
                        ui.p().rect(
                            Rect::new(inner.x, row_y - 2.0, inner.w, 1.0),
                            Color::rgba(255, 255, 255, 0.045),
                        );
                    }
                    let r = Rect::new(inner.x - 8.0, row_y, inner.w + 16.0, rh - 4.0);
                    let kbd = v.kbd && !any_hover && k == list.sel;
                    if kbd {
                        sel_y = Some((row_y - view.y, rh));
                    }
                    if let Some(a) =
                        settings_row(ui, k, label, r, kbd, dd_row == Some(k), &mut dd_anchor)
                    {
                        acts.push(a);
                    }
                    row_y += rh;
                }
                y += h + 12.0;
            }
            tallest = tallest.max(y - view.y);
        }
        tallest + 8.0
    });
    if let Some((y, h)) = sel_y {
        if sh.last_sel != Some((id_of(&key), list.sel)) {
            sh.ui.scroll_to(&key, y, h, body.h);
        }
    }
    sh.last_sel = Some((id_of(&key), list.sel));
    *anchor = dd_anchor;
    sh.actions.extend(acts);
}

fn settings_columns(
    groups: Vec<Vec<usize>>,
    two: bool,
    items: &[(&str, &str)],
) -> Vec<Vec<Vec<usize>>> {
    omsi_settings_ui::settings_columns(groups, two, |k| row_h(items[k].0, items[k].1))
}

#[cfg(test)]
fn settings_groups(items: &[(&str, &str)], hide_back: bool) -> Vec<Vec<usize>> {
    let back = hide_back
        .then(|| {
            items.iter().position(|&(id, label)| {
                id == "back" && plain(parse_row(label).name).0 == omsi_ui::tr("Back").as_ref()
            })
        })
        .flatten();
    omsi_settings_ui::settings_groups(items, crate::game_lists::HEADING, back)
}

/// One row of a settings window: its name (and description) on the left, its control on
/// the right as the launcher draws that control.
fn settings_row(
    ui: &mut Ui,
    k: usize,
    label: &str,
    r: Rect,
    kbd: bool,
    dd_open: bool,
    dd_anchor: &mut Option<Rect>,
) -> Option<Action> {
    let row = parse_row(label);
    let id = id_of(&format!("pause-row-{k}-{}", row.name));
    let hov = ui.hover(r);
    let t = ui.anim(id ^ 0x51, if hov || kbd { 1.0 } else { 0.0 }, 0.06);
    if t > 0.01 {
        // (half a step lighter than the panel: the fields in the row stay apart from it)
        ui.p()
            .rounded(r, 6.0, th().surface.mix(th().surface_2, 0.5).alpha(t));
    }
    if kbd {
        ui.p()
            .rounded(Rect::new(r.x, r.y + 8.0, 2.0, r.h - 16.0), 1.0, th().accent);
    }
    let lx = r.x + 8.0;
    let ctl_w = (r.w * 0.5).min(300.0);
    let ctl = Rect::new(r.right() - 8.0 - ctl_w, r.center().y - 17.0, ctl_w, 34.0);
    let name_w = match row.kind {
        "s" | "i" => r.w - 80.0,
        _ => ctl.x - lx - 12.0,
    };
    let name: Cow<'_, str> = omsi_ui::tr(row.name);
    let desc: Cow<'_, str> = omsi_ui::tr(row.desc);
    let ink = th().text_soft.mix(th().text, t);
    if row.desc.is_empty() {
        ui.text_in(
            name.as_ref(),
            Rect::new(lx, r.y, name_w, r.h),
            13.0,
            Weight::Regular,
            ink,
            Align::Left,
        );
    } else {
        ui.text_in(
            name.as_ref(),
            Rect::new(lx, r.y + 6.0, name_w, 20.0),
            13.0,
            Weight::Medium,
            ink,
            Align::Left,
        );
        ui.text_in(
            desc.as_ref(),
            Rect::new(lx, r.y + 25.0, name_w, 17.0),
            11.5,
            Weight::Regular,
            th().text_dim,
            Align::Left,
        );
        // (cut short by a narrow column: the whole of it under the mouse)
        if ui.width(desc.as_ref(), 11.5, Weight::Regular) > name_w {
            ui.tooltip(Rect::new(lx, r.y, name_w, r.h), desc.as_ref());
        }
    }
    match row.kind {
        // a switch: the whole row flips it, as the launcher's
        "s" => {
            let mut on = row.value == "on";
            let sw = Rect::new(r.right() - 8.0 - 60.0, r.y, 60.0, r.h);
            let flipped = ui.toggle(&format!("pause-sw-{k}-{}", row.name), sw, &mut on, "");
            let (_, _, clicked) = ui.interact(id, Rect::new(r.x, r.y, r.w - 68.0, r.h));
            (flipped || clicked).then_some(Action::Choose(k))
        }
        // a slider, the row's value text beside it
        "v" => {
            let mut f = row.frac.unwrap_or(0.0).clamp(0.0, 1.0);
            let value = row.value.to_string();
            let changed = ui.slider_without_wheel(
                &format!("pause-sl-{k}-{}", row.name),
                ctl,
                &mut f,
                0.0,
                1.0,
                0.0,
                "",
                &|_| value.clone(),
            );
            changed.then_some(Action::Control(k, f))
        }
        // A calendar field commits only after a day is selected.
        "d" => {
            let mut date = row.value.to_string();
            ui.date_field(&format!("pause-date-{k}-{}", row.name), ctl, &mut date)
                .then_some(Action::Date(date))
        }
        // a stepper: the value between the two arrows of a field
        "c" => {
            ui.p().rounded(ctl, 6.0, th().surface_2);
            ui.text_in(
                row.value,
                ctl.pad(36.0, 0.0),
                13.0,
                Weight::Regular,
                th().ink,
                Align::Center,
            );
            let left = Rect::new(ctl.x, ctl.y, 34.0, ctl.h);
            let right = Rect::new(ctl.right() - 34.0, ctl.y, 34.0, ctl.h);
            let mut out = None;
            for (half, icon, fx) in [(left, "chevron_left", 0.0), (right, "chevron_right", 1.0)] {
                let (h, _, clicked) = ui.interact(id_of(&format!("pause-st-{k}-{icon}")), half);
                if h {
                    ui.p().rounded(half.inset(3.0), 5.0, th().surface_3);
                }
                ui.icon(
                    icon,
                    half.center(),
                    18.0,
                    if h { th().accent } else { th().text_dim },
                );
                if clicked {
                    out = Some(Action::Control(k, fx));
                }
            }
            out
        }
        // opens a list or a drop-down: the launcher's select, closed
        "o" => {
            let (h, _, clicked) = ui.interact(id, r);
            let a = ui.anim(id ^ 0x77, if h || dd_open { 1.0 } else { 0.0 }, 0.08);
            // (open: a step lighter, as under the mouse; no ring round it)
            ui.p()
                .rounded(ctl, 6.0, th().surface_2.mix(th().surface_3, a));
            // (without a value it opens a list of its own: a way on, not a drop-down)
            let text = if row.value.is_empty() {
                omsi_ui::tr("Change").into_owned()
            } else {
                row.value.to_string()
            };
            ui.text_in(
                &text,
                Rect::new(ctl.x + 12.0, ctl.y, ctl.w - 40.0, ctl.h),
                13.0,
                Weight::Regular,
                if row.value.is_empty() {
                    th().text_soft.mix(th().text, a)
                } else {
                    th().text
                },
                Align::Left,
            );
            let icon = match (row.value.is_empty(), dd_open) {
                (true, _) => "chevron_right",
                (false, true) => "expand_less",
                (false, false) => "expand_more",
            };
            ui.icon(
                icon,
                Vec2::new(ctl.right() - 18.0, ctl.center().y),
                18.0,
                if row.value.is_empty() {
                    th().text_dim.mix(th().accent, a)
                } else {
                    th().text_dim
                },
            );
            if dd_open {
                *dd_anchor = Some(ctl);
            }
            clicked.then_some(Action::Choose(k))
        }
        // information only
        "i" => {
            ui.text_in(
                row.value,
                Rect::new(r.x + r.w * 0.4, r.y, r.w * 0.6 - 8.0, r.h),
                13.0,
                Weight::Medium,
                th().text,
                Align::Right,
            );
            None
        }
        // a value being typed
        "E" => {
            ui.p().rounded(ctl, 6.0, th().surface_3);
            let caret = if (ui.time * 2.0) as i64 % 2 == 0 {
                "|"
            } else {
                ""
            };
            ui.text_in(
                &format!("{}{caret}", row.value),
                Rect::new(ctl.x + 12.0, ctl.y, ctl.w - 24.0, ctl.h),
                13.0,
                Weight::Medium,
                th().text,
                Align::Left,
            );
            None
        }
        // a button with its text as the value
        _ => {
            let text = if row.value.is_empty() {
                omsi_ui::tr("Open").into_owned()
            } else {
                row.value.to_string()
            };
            let bw = (ui.width(&text, 13.0, Weight::Medium) + 36.0)
                .max(96.0)
                .min(ctl_w);
            let b = Rect::new(r.right() - 8.0 - bw, ctl.y, bw, ctl.h);
            let pressed = ui.button(
                &format!("pause-bt-{k}-{}", row.name),
                b,
                &text,
                None,
                ButtonKind::Normal,
            );
            let (_, _, clicked) = ui.interact(id, Rect::new(r.x, r.y, b.x - r.x - 6.0, r.h));
            (pressed || clicked).then_some(Action::Choose(k))
        }
    }
}

/// Where the open drop-down's list lies under (or over) its field `a`.
fn dropdown_rect(a: Rect, n: usize, size: Vec2) -> Rect {
    let h = (n as f32 * 34.0 + 8.0).min(300.0);
    let below = size.y - a.bottom() - 12.0;
    let y = if below >= h || below >= a.y - 12.0 {
        a.bottom() + 4.0
    } else {
        a.y - 4.0 - h
    };
    Rect::new(a.x, y, a.w, h.min(below.max(a.y - 12.0)))
}

/// The open drop-down as the launcher's: a list over everything, the value in force ticked.
fn dropdown(sh: &mut Shell, d: &DropdownView, a: Rect, kbd: bool) {
    let rr = dropdown_rect(a, d.items.len(), sh.ui.size);
    let ui = &mut sh.ui;
    // (over the scroll area's clip: a layer of its own over the whole window)
    ui.push_clip(Rect::new(0.0, 0.0, ui.size.x, ui.size.y), 0.0);
    ui.p()
        .rounded(rr.inset(-2.0), 10.0, Color::rgba(0, 0, 0, 0.35));
    ui.p().rounded(rr, 8.0, th().surface_2);
    let row = 34.0;
    let id = id_of("pause-dropdown");
    let content = d.items.len() as f32 * row + 8.0;
    let max = (content - rr.h).max(0.0);
    let mut scroll = ui
        .scroll
        .get(&id)
        .copied()
        .unwrap_or(d.top as f32 * row)
        .clamp(0.0, max);
    if ui.hover(rr) && ui.input.wheel.y.abs() > 0.0 {
        scroll = (scroll - ui.input.wheel.y * 40.0).clamp(0.0, max);
        ui.input.wheel = Vec2::ZERO;
    }
    if kbd {
        let y = d.sel as f32 * row;
        if y < scroll {
            scroll = y;
        } else if y + row > scroll + rr.h - 8.0 {
            scroll = y + row - rr.h + 8.0;
        }
    }
    ui.scroll.insert(id, scroll);
    ui.push_clip(rr.inset(4.0), 8.0);
    let mut picked = None;
    for (i, item) in d.items.iter().enumerate() {
        let y = rr.y + 4.0 + i as f32 * row - scroll;
        if y + row < rr.y || y > rr.bottom() {
            continue;
        }
        let cell = Rect::new(rr.x + 4.0, y, rr.w - 8.0, row);
        let (h, _, clicked) = ui.interact(id_of(&format!("pause-dd-{i}")), cell);
        if d.current == Some(i) {
            ui.p().rounded(cell, 5.0, th().surface_3);
            ui.icon(
                "check",
                Vec2::new(cell.right() - 16.0, cell.center().y),
                15.0,
                th().accent,
            );
        } else if h || (kbd && d.sel == i) {
            ui.p().rounded(cell, 5.0, th().surface_3.alpha(0.6));
        }
        ui.text_in(
            item,
            Rect::new(cell.x + 10.0, cell.y, cell.w - 36.0, cell.h),
            13.0,
            Weight::Regular,
            th().text,
            Align::Left,
        );
        if clicked {
            picked = Some(i);
        }
    }
    ui.pop_clip();
    if max > 0.0 {
        let bar_h = (rr.h * rr.h / content).max(24.0);
        let y = rr.y + (rr.h - bar_h) * (scroll / max);
        ui.p().rounded(
            Rect::new(rr.right() - 5.0, y, 3.0, bar_h),
            1.5,
            Color::WHITE.alpha(0.3),
        );
    }
    ui.pop_clip();
    if rr.contains(ui.input.mouse) {
        ui.over_ui = true;
    }
    match picked {
        Some(i) => sh.actions.push(Action::Dropdown(i)),
        // (a click anywhere else closes it, and does nothing else)
        None if ui.input.pressed && !rr.contains(ui.input.mouse) && !a.contains(ui.input.mouse) => {
            sh.actions.push(Action::CloseDropdown)
        }
        None => {}
    }
}

/// The lines of a list (drivers, fleet numbers, destinations, buttons, events ...): the
/// launcher's list rows in one panel.
fn plain_list(sh: &mut Shell, v: &PauseView, list: &ListView, body: Rect) {
    let w = body.w.min(720.0);
    let panel = Rect::new(body.x, body.y, w, body.h);
    sh.ui.panel(panel);
    let inner = Rect::new(
        panel.x + 10.0,
        panel.y + 10.0,
        panel.w - 20.0,
        panel.h - 20.0,
    );
    list_rows(sh, v, list, inner, false);
}

/// The rows of a list in `r`, scrolled; `tours`: the chosen one stays marked.
fn list_rows(sh: &mut Shell, v: &PauseView, list: &ListView, r: Rect, keep_marked: bool) {
    let items = &list.items;
    let back_txt = omsi_ui::tr("Back").into_owned();
    let shown: Vec<usize> = (0..items.len())
        .filter(|&k| !(items[k].0 == "back" && plain(items[k].1).0 == back_txt))
        .collect();
    // (a list of codes and names - the destinations - in two columns)
    let code_w = shown
        .iter()
        .filter_map(|&k| code_and_name(items[k].1))
        .map(|(c, _)| sh.ui.width(c, 13.0, Weight::Medium))
        .fold(0.0f32, f32::max);
    let any_hover = sh.ui.hover(r);
    let key = format!("pause-list-{}", list.key);
    let mut acts = Vec::new();
    let mut sel_y = None;
    let line_pre = format!("{} ", omsi_ui::tr("Line"));
    sh.ui.scroll_area(&key, r, &mut |ui, view| {
        let mut y = view.y;
        for &k in &shown {
            let (id, label) = items[k];
            if id == crate::game_lists::HEADING {
                ui.heading(
                    Rect::new(view.x + 10.0, y + 6.0, view.w - 20.0, 28.0),
                    label,
                    None,
                );
                y += 34.0;
                continue;
            }
            let row = Rect::new(view.x, y, view.w - 8.0, LIST_ROW - 4.0);
            let kbd = v.kbd && !any_hover && k == list.sel;
            if kbd {
                sel_y = Some(y - view.y);
            }
            let marked = (keep_marked && k == list.sel) || kbd;
            if ui.row(&format!("pause-lr-{}-{k}", list.key), row, marked) {
                acts.push(
                    if list.kind == MenuKind::Vehicles
                        && crate::game_lists::bus_preview::selectable(id)
                    {
                        Action::BusSelect(k)
                    } else {
                        Action::Choose(k)
                    },
                );
            }
            let h = ui.hover(row);
            let ink = if marked || h {
                th().text
            } else {
                th().text_soft
            };
            let cy = row.center().y;
            if id == "search" {
                let field = row.inset(2.0);
                ui.p().rounded(field, 6.0, th().surface_2);
                ui.icon("search", Vec2::new(field.x + 16.0, cy), 16.0, th().text_dim);
                ui.text_in(
                    label,
                    Rect::new(field.x + 34.0, field.y, field.w - 44.0, field.h),
                    13.0,
                    Weight::Regular,
                    th().text_soft,
                    Align::Left,
                );
            } else if let Some((name, info)) = label
                .strip_prefix(line_pre.as_str())
                .and_then(|rest| rest.rsplit_once("  ("))
                .map(|(n, t)| (n, t.trim_end_matches(')')))
            {
                // a line of the timetable: its number on a sign, as a line sign on a bus
                let sw = (ui.width(name, 14.0, Weight::Bold) + 22.0).max(48.0);
                let sign = Rect::new(row.x + 10.0, cy - 13.0, sw, 26.0);
                ui.p().rounded(
                    sign,
                    6.0,
                    th().accent.mix(
                        Color::rgba(150, 104, 30, 1.0),
                        if marked || h { 0.0 } else { 0.3 },
                    ),
                );
                ui.text_in(
                    name,
                    sign,
                    14.0,
                    Weight::Bold,
                    Color::rgba(18, 14, 8, 1.0),
                    Align::Center,
                );
                ui.text_in(
                    info,
                    Rect::new(
                        sign.right() + 12.0,
                        row.y,
                        row.right() - sign.right() - 40.0,
                        row.h,
                    ),
                    13.0,
                    Weight::Regular,
                    ink,
                    Align::Left,
                );
                ui.icon(
                    "chevron_right",
                    Vec2::new(row.right() - 16.0, cy),
                    16.0,
                    th().text_dim,
                );
            } else if let Some((code, name)) = code_and_name(label).filter(|_| code_w > 0.0) {
                ui.text_in(
                    code,
                    Rect::new(row.x + 12.0, row.y, code_w, row.h),
                    13.0,
                    Weight::Medium,
                    th().accent,
                    Align::Right,
                );
                ui.text_in(
                    name,
                    Rect::new(row.x + 24.0 + code_w, row.y, row.w - code_w - 36.0, row.h),
                    13.0,
                    Weight::Regular,
                    ink,
                    Align::Left,
                );
            } else {
                let (text, more) = plain(label);
                // (a row of a settings list kind without its own window: its value at the right)
                let row_parts = parse_row(text);
                ui.text_in(
                    row_parts.name,
                    Rect::new(row.x + 12.0, row.y, row.w - 60.0, row.h),
                    13.0,
                    Weight::Regular,
                    ink,
                    Align::Left,
                );
                if !row_parts.value.is_empty() && row_parts.kind != "a" {
                    ui.text_in(
                        row_parts.value,
                        Rect::new(row.x + row.w * 0.5, row.y, row.w * 0.5 - 36.0, row.h),
                        12.5,
                        Weight::Medium,
                        th().text_dim,
                        Align::Right,
                    );
                }
                if more {
                    ui.icon(
                        "chevron_right",
                        Vec2::new(row.right() - 16.0, cy),
                        16.0,
                        th().text_dim,
                    );
                }
            }
            y += LIST_ROW;
        }
        y - view.y + 4.0
    });
    if let Some(y) = sel_y {
        if sh.last_sel != Some((id_of(&key), list.sel)) {
            sh.ui.scroll_to(&key, y, LIST_ROW, r.h);
        }
    }
    sh.last_sel = Some((id_of(&key), list.sel));
    sh.actions.extend(acts);
}

/// "{code:>3}  {name}": a destination's code and name.
fn code_and_name(label: &str) -> Option<(&str, &str)> {
    let (c, n) = label.trim_start().split_once("  ")?;
    (!c.is_empty() && c.len() <= 5 && c.chars().all(|ch| ch.is_ascii_digit()))
        .then_some((c, n.trim_start()))
}

/// The lines or a line's tours, with the timetable of the chosen one beside them.
fn timetable_lists(sh: &mut Shell, v: &PauseView, list: &ListView, body: Rect) {
    // (narrow - a phone: the timetable with its Start under the list instead of beside it;
    // without it a tour could be marked but not started)
    if let (Some(p), true) = (list.preview, body.w < 760.0) {
        let lh = (body.h * 0.38).max(120.0);
        let top = Rect::new(body.x, body.y, body.w, lh);
        sh.ui.panel(top);
        list_rows(
            sh,
            v,
            list,
            Rect::new(top.x + 10.0, top.y + 10.0, top.w - 20.0, top.h - 20.0),
            list.kind == MenuKind::Tours,
        );
        preview(
            sh,
            p,
            list,
            Rect::new(body.x, top.bottom() + GAP, body.w, body.h - lh - GAP),
        );
        return;
    }
    let pane_w = if list.preview.is_some() {
        (body.w * 0.46).min(440.0)
    } else {
        0.0
    };
    let lw = (body.w - pane_w - if pane_w > 0.0 { GAP * 2.0 } else { 0.0 }).min(620.0);
    let left = Rect::new(body.x, body.y, lw, body.h);
    sh.ui.panel(left);
    list_rows(
        sh,
        v,
        list,
        Rect::new(left.x + 10.0, left.y + 10.0, left.w - 20.0, left.h - 20.0),
        list.kind == MenuKind::Tours,
    );
    if let Some(p) = list.preview {
        preview(
            sh,
            p,
            list,
            Rect::new(left.right() + GAP * 2.0, body.y, pane_w, body.h),
        );
    }
}

/// The timetable beside the lines or tours: its title, the facts, the time with arrows,
/// the stops (one chosen to start from) and the button that starts the trip.
fn preview(sh: &mut Shell, p: &Preview, list: &ListView, r: Rect) {
    let mut acts = Vec::new();
    let ui = &mut sh.ui;
    ui.panel(r);
    let inner = Rect::new(r.x + 18.0, r.y + 16.0, r.w - 36.0, r.h - 32.0);
    ui.text_in(
        &p.title,
        Rect::new(inner.x, inner.y, inner.w, 24.0),
        16.0,
        Weight::Bold,
        th().text,
        Align::Left,
    );
    ui.text_in(
        &p.meta,
        Rect::new(inner.x, inner.y + 26.0, inner.w, 18.0),
        12.0,
        Weight::Regular,
        th().text_dim,
        Align::Left,
    );
    let mut top = inner.y + 54.0;
    top += 6.0;
    if let Some(time) = p.time.as_ref() {
        let bh = 34.0;
        let prev = Rect::new(inner.x, top, 44.0, bh);
        let next = Rect::new(inner.right() - 44.0, top, 44.0, bh);
        // (the trip before: usize::MAX - 1, the next: usize::MAX - 2)
        for (b, icon, code) in [
            (prev, "arrow_back", usize::MAX - 1),
            (next, "arrow_forward", usize::MAX - 2),
        ] {
            if ui.button(
                &format!("pause-trip-{icon}"),
                b,
                "",
                Some(icon),
                ButtonKind::Normal,
            ) {
                acts.push(Action::Pane(code));
            }
        }
        ui.text_in(
            time,
            Rect::new(prev.right() + 8.0, top, next.x - prev.right() - 16.0, bh),
            18.0,
            Weight::Bold,
            th().accent,
            Align::Center,
        );
        top += bh + 10.0;
    }
    let lh = 28.0;
    match (p.chosen, p.button.as_ref()) {
        (Some(chosen), Some(button)) => {
            let go = Rect::new(inner.x, inner.bottom() - 44.0, inner.w, 44.0);
            let rows_r = Rect::new(
                inner.x - 8.0,
                top,
                inner.w + 16.0,
                (go.y - 10.0 - top).max(lh),
            );
            let key = format!("pause-pane-{}", list.key);
            let mut first_view: Option<f32> = None;
            ui.scroll_area(&key, rows_r, &mut |ui, view| {
                for (i, (what, when)) in p.rows.iter().enumerate() {
                    let row = Rect::new(view.x, view.y + i as f32 * lh, view.w - 8.0, lh - 2.0);
                    if ui.row(&format!("pause-stop-{i}"), row, i == chosen) {
                        acts.push(Action::Pane(i));
                    }
                    if i == chosen {
                        first_view = Some(i as f32 * lh);
                    }
                    ui.text_in(
                        when,
                        Rect::new(row.right() - 70.0, row.y, 60.0, row.h),
                        12.5,
                        Weight::Medium,
                        th().accent,
                        Align::Right,
                    );
                    ui.text_in(
                        what,
                        Rect::new(row.x + 10.0, row.y, row.w - 90.0, row.h),
                        12.5,
                        Weight::Regular,
                        if i == chosen {
                            th().text
                        } else {
                            th().text_soft
                        },
                        Align::Left,
                    );
                }
                p.rows.len() as f32 * lh
            });
            if let (Some(y), None) = (first_view, list.pane_first) {
                if sh.last_sel.map(|s| s.1) != Some(chosen) {
                    sh.ui.scroll_to(&key, y, lh, rows_r.h);
                }
            }
            if sh.ui.button(
                "pause-go",
                go,
                button,
                Some("play_arrow"),
                ButtonKind::Primary,
            ) {
                acts.push(Action::Pane(usize::MAX));
            }
        }
        _ => {
            let rows_r = Rect::new(inner.x, top, inner.w, inner.bottom() - top);
            let tp = format!("{} ", omsi_ui::tr("Tour"));
            let key = format!("pause-pane-{}", list.key);
            ui.scroll_area(&key, rows_r, &mut |ui, view| {
                for (i, (what, when)) in p.rows.iter().enumerate() {
                    let y = view.y + i as f32 * lh;
                    ui.text_in(
                        when,
                        Rect::new(view.right() - 78.0, y, 70.0, lh),
                        12.5,
                        Weight::Medium,
                        th().accent,
                        Align::Right,
                    );
                    match what.strip_prefix(tp.as_str()) {
                        Some(rest) => {
                            let (num, dest) = rest.split_once("  ›  ").unwrap_or((rest, ""));
                            let tw = (ui.width(num.trim(), 12.5, Weight::Bold) + 16.0).max(34.0);
                            let tile = Rect::new(view.x, y + 3.0, tw, lh - 6.0);
                            ui.p().rounded(tile, 5.0, th().accent.alpha(0.16));
                            ui.text_in(
                                num.trim(),
                                tile,
                                12.5,
                                Weight::Bold,
                                th().accent,
                                Align::Center,
                            );
                            ui.text_in(
                                dest,
                                Rect::new(tile.right() + 10.0, y, view.w - tw - 100.0, lh),
                                12.5,
                                Weight::Regular,
                                th().text_soft,
                                Align::Left,
                            );
                        }
                        None => {
                            ui.text_in(
                                what,
                                Rect::new(view.x, y, view.w - 90.0, lh),
                                12.5,
                                Weight::Regular,
                                th().text_soft,
                                Align::Left,
                            );
                        }
                    }
                }
                p.rows.len() as f32 * lh
            });
        }
    }
    sh.actions.extend(acts);
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn player_count_badge_follows_the_title_without_overflowing() {
        let badge = count_badge_rect(120.0, 28.0, 100.0, 400.0, 10.0).unwrap();
        assert_eq!(badge, Rect::new(232.0, 19.0, 28.0, 22.0));
        assert!(count_badge_rect(250.0, 28.0, 100.0, 370.0, 10.0).is_none());
    }

    #[test]
    fn a_label_that_opens_more_loses_its_dots() {
        assert_eq!(plain("Options..."), ("Options", true));
        assert_eq!(plain("Resume"), ("Resume", false));
        assert_eq!(plain("Fleet number..."), ("Fleet number", true));
    }

    #[test]
    fn a_settings_row_is_taken_apart() {
        let r = parse_row("Clouds\u{1f}s\u{1f}on\u{1f}Draws the clouds\u{1f}0.5");
        assert_eq!(
            (r.name, r.kind, r.value, r.desc, r.frac),
            ("Clouds", "s", "on", "Draws the clouds", Some(0.5))
        );
        let r = parse_row("Plain");
        assert_eq!((r.name, r.kind, r.value), ("Plain", "a", ""));
    }

    #[test]
    fn destinations_are_codes_and_names() {
        assert_eq!(
            code_and_name(" 12  Hauptbahnhof"),
            Some(("12", "Hauptbahnhof"))
        );
        assert_eq!(code_and_name("Line 5  (3 tours)"), None);
    }

    #[test]
    fn a_dropdown_opens_upwards_where_there_is_no_room_below() {
        let size = Vec2::new(1440.0, 880.0);
        let low = dropdown_rect(Rect::new(500.0, 800.0, 300.0, 34.0), 6, size);
        assert!(low.bottom() <= 800.0, "{low:?}");
        let high = dropdown_rect(Rect::new(500.0, 100.0, 300.0, 34.0), 6, size);
        assert!(high.y >= 134.0, "{high:?}");
    }
}

#[cfg(test)]
#[path = "pause/settings_ui_tests.rs"]
mod settings_ui_tests;
